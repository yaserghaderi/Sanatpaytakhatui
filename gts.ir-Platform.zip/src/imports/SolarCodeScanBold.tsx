import svgPaths from "./svg-ds6le09lnu";

export default function SolarCodeScanBold() {
  return (
    <div className="relative size-full" data-name="solar:code-scan-bold">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 22 22">
        <g id="solar:code-scan-bold">
          <path d={svgPaths.p250cd500} fill="var(--fill-0, #3C4354)" id="Vector" />
          <path d={svgPaths.p197e2100} fill="var(--fill-0, #3C4354)" id="Vector_2" />
          <path d={svgPaths.p8a12400} fill="var(--fill-0, #3C4354)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}