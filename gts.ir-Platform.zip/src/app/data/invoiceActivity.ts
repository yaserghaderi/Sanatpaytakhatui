import { currentStaff, salesExperts } from './staff';
import type { Invoice, InvoiceLine } from '../pages/dashboard/DashboardOrders';
import { activeEntries, parseAmount, paymentLabels } from './invoiceFinance';

export type InvoiceActivity = {
  id: string;
  actor: string;
  at: string;
  action: string;
  changes: { field: string; before: string; after: string }[];
};

const display = (value: unknown) => value == null || value === '' ? '—' : typeof value === 'number' ? value.toLocaleString('fa-IR') : String(value);
const stageNames = { sales: 'فروش', finance: 'مالی', warehouse: 'انبار', supply: 'تأمین' };
const stageStatuses = { done: 'تأیید شده', pending: 'در انتظار اقدام', waiting: 'در انتظار' };
const lineFields: Partial<Record<keyof InvoiceLine, string>> = {
  name: 'نام کالا', code: 'کد کالا', specs: 'مشخصات', qty: 'تعداد', unit: 'واحد',
  price: 'قیمت واحد', cost: 'قیمت خرید', discount: 'درصد تخفیف', note: 'توضیحات', aiText: 'متن استخراج‌شده',
};

export function recordInvoiceActivity(before: Invoice, after: Invoice): Invoice {
  const changes: InvoiceActivity['changes'] = [];
  const compare = (field: string, previous: unknown, next: unknown) => {
    if (display(previous) !== display(next)) changes.push({ field, before: display(previous), after: display(next) });
  };
  compare('نام خریدار', before.buyer, after.buyer);
  compare('شماره تماس', before.phone, after.phone);
  compare('نوع مشتری', before.customerType, after.customerType);
  compare('نوع درخواست', before.official ? 'رسمی' : 'غیررسمی', after.official ? 'رسمی' : 'غیررسمی');
  const settlementDetails = (invoice: Invoice) => invoice.settlement ? activeEntries(invoice.settlement).map(entry => [
    paymentLabels[entry.method], `${display(parseAmount(entry.amount) || 0)} ریال`,
    entry.date && `سررسید: ${entry.date}`, entry.description, entry.attachment?.name,
  ].filter(Boolean).join(' · ')).join('\n') : '';
  compare('روش‌ها و جزئیات تسویه', settlementDetails(before), settlementDetails(after));
  for (const [role, label] of [['sales', 'عامل فروش'], ['finance', 'واحد مالی']] as const) {
    const previous = before.settlementApprovals?.[role];
    const next = after.settlementApprovals?.[role];
    compare(`تأیید تسویه ${label}`, previous ? `${previous.by} · ${new Date(previous.at).toLocaleString('fa-IR')}` : 'تأیید نشده', next ? `${next.by} · ${new Date(next.at).toLocaleString('fa-IR')}` : 'تأیید نشده');
  }
  for (const [key, label] of Object.entries({ province: 'استان', city: 'شهر', street: 'نشانی', postal: 'کد پستی' })) {
    compare(label, before.address?.[key as keyof NonNullable<Invoice['address']>], after.address?.[key as keyof NonNullable<Invoice['address']>]);
  }
  const commissions = (invoice: Invoice) => (invoice.salesCommissions ?? []).map(entry => `${salesExperts.find(expert => expert.id === entry.staffId)?.name ?? entry.staffId}: ${display(entry.rate)}٪`).sort().join('، ');
  compare('کارشناسان فروش و کمیسیون از سود', commissions(before), commissions(after));
  compare('درصد تخفیف', before.discount ?? 0, after.discount ?? 0);
  const categories: Record<string, string> = { manual: 'دستی', 'cash-colleague': 'نقدی همکار', 'cash-customer': 'نقدی مشتری', 'credit-colleague': 'اعتباری همکار', 'credit-customer': 'اعتباری مشتری' };
  compare('دسته تخفیف', categories[before.discountCategory ?? 'manual'], categories[after.discountCategory ?? 'manual']);
  compare('ستاره‌دار', before.starred ? 'بله' : 'خیر', after.starred ? 'بله' : 'خیر');
  for (const key of Object.keys(stageNames) as (keyof typeof stageNames)[]) {
    compare(`مرحله ${stageNames[key]}`, stageStatuses[before.stages[key]], stageStatuses[after.stages[key]]);
  }
  // Existing invoices materialize their rows on first edit; that is not a user-added product.
  const previousLines = before.lines ?? before.products.map((name, index, products) => ({
    id: `${before.id}-${index}`, name, code: `SP-${before.id}${index}`, specs: 'واحد: عدد', qty: 1,
    price: Math.floor(before.amount / products.length) + (index === 0 ? before.amount % products.length : 0),
    cost: 0, note: '', aiText: name, unit: 'عدد', discount: before.discount ?? 0,
  }));
  if (after.lines) {
    for (const line of after.lines) {
      const previous = previousLines.find(item => item.id === line.id);
      if (!previous) { changes.push({ field: 'افزودن کالا', before: '—', after: line.name }); continue; }
      for (const [key, label] of Object.entries(lineFields)) {
        compare(`${line.name} · ${label}`, previous[key as keyof InvoiceLine], line[key as keyof InvoiceLine]);
      }
    }
    for (const line of previousLines) {
      if (!after.lines.some(item => item.id === line.id)) changes.push({ field: 'حذف کالا', before: line.name, after: '—' });
    }
  }
  compare('مبلغ فاکتور', before.amount, after.amount);
  compare('وضعیت لغو', before.cancelled ? 'لغوشده' : 'فعال', after.cancelled ? 'لغوشده' : 'فعال');
  if (after.cancellation && !before.cancelled) {
    compare('دلیل لغو', '', after.cancellation.reason);
    compare('توضیح لغو', '', after.cancellation.explanation);
  }
  const deliveryNames = { none: 'ارسال نشده', sent: 'ارسال شده', delivered: 'تحویل شده' };
  compare('وضعیت تحویل', deliveryNames[before.delivery], deliveryNames[after.delivery]);
  if ((after.messages?.length ?? 0) > (before.messages?.length ?? 0)) {
    changes.push({ field: 'گفت‌وگو', before: '—', after: 'پیام جدید ثبت شد' });
  }
  if (!before.analysis && after.analysis) changes.push({ field: 'تحلیل فایل', before: '—', after: 'بازتولید تحلیل آغاز شد' });
  if (!changes.length) return { ...after, activities: before.activities };
  const activity: InvoiceActivity = {
    id: crypto.randomUUID(), actor: currentStaff.name, at: new Date().toISOString(),
    action: changes.length === 1 ? changes[0].field : 'ویرایش فاکتور', changes,
  };
  return { ...after, activities: [...(before.activities ?? []), activity] };
}
