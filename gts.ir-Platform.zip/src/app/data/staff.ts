// Demo portraits. Replace avatar URLs with the authenticated staff API records.
const portrait = (shirt: string, hair: string) => `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 80 80"><rect width="80" height="80" fill="#e9eff4"/><path d="M9 80c0-27 62-27 62 0" fill="${shirt}"/><rect x="33" y="47" width="14" height="15" rx="6" fill="#dca783"/><ellipse cx="40" cy="32" rx="17" ry="21" fill="#edc09e"/><path d="M23 30V20c2-21 36-17 34 8-8-2-12-7-16-12-4 8-10 11-18 14" fill="${hair}"/><circle cx="34" cy="33" r="1.5"/><circle cx="47" cy="33" r="1.5"/><path d="M34 44q6 4 12 0" fill="none" stroke="#945f49" stroke-width="2"/></svg>`)}`;
export const currentStaff = { name: 'مدیریت سایت', avatar: portrait('#156394', '#30343b') };
export const demoEditor = { name: 'داوود محمدنژاد', avatar: portrait('#526579', '#4d352b') };
export const salesExperts = [
  { id: 'yousef', name: 'یوسف اسکندرزاده' },
  { id: 'davood', name: demoEditor.name },
  { id: 'yaser', name: 'یاسر قادری' },
  { id: 'sara', name: 'سارا احمدی' },
  { id: 'ali', name: 'علی رضایی' },
  { id: 'maryam', name: 'مریم کریمی' },
];
