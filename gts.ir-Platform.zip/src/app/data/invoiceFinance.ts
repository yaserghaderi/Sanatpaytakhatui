export type PaymentMethod = 'bank' | 'cheque' | 'credit' | 'other';
export type PaymentEntry = { id: string; method: PaymentMethod; amount: string; date: string; description: string; attachment?: File };
export type InvoiceSettlement = { enabled: PaymentMethod[]; entries: PaymentEntry[] };
export type SettlementApprovals = {
  sales?: { by: string; at: string; fingerprint: string };
  finance?: { by: string; at: string; fingerprint: string };
};
export type AccountTransaction = { id: string; date: string; description: string; debit: number; credit: number; reference: string };
export type CustomerAccount = { creditLimit: number; transactions: AccountTransaction[] };
export const paymentLabels: Record<PaymentMethod, string> = { bank: 'واریز بانکی', cheque: 'چک', credit: 'اعتبار مشتری', other: 'سایر' };
export const emptySettlement = (): InvoiceSettlement => ({ enabled: [], entries: [] });
export const parseAmount = (value: string) => {
  const normalized = normalizeDigits(value).replace(/[,٬\s]/g, '');
  return normalized === '' ? 0 : /^\d+$/.test(normalized) ? Number(normalized) : NaN;
};
export const activeEntries = (settlement: InvoiceSettlement) => settlement.entries.filter(entry => settlement.enabled.includes(entry.method));
export const allocatedAmount = (settlement: InvoiceSettlement) => activeEntries(settlement).reduce((sum, entry) => {
  const value = parseAmount(entry.amount);
  return sum + (Number.isFinite(value) ? value : 0);
}, 0);
export const accountBalance = (account: CustomerAccount) => account.transactions.reduce((sum, entry) => sum + entry.debit - entry.credit, 0);
export const availableCredit = (account: CustomerAccount) => Math.max(0, account.creditLimit - accountBalance(account));
export const newPaymentEntry = (method: PaymentMethod): PaymentEntry => ({ id: crypto.randomUUID(), method, amount: '', date: '', description: '' });

export function validJalaliDate(value: string): boolean {
  const match = normalizeDigits(value).match(/^(\d{4})[/-](\d{1,2})[/-](\d{1,2})$/);
  if (!match) return false;
  const [, y, m, d] = match.map(Number);
  if (y < 1200 || y > 1600 || m < 1 || m > 12 || d < 1 || d > (m <= 6 ? 31 : m <= 11 ? 30 : 30)) return false;
  if (m !== 12 || d !== 30) return true;
  const formatter = new Intl.DateTimeFormat('en-US-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC' });
  return [18, 19, 20, 21, 22].some(day => {
    const parts = formatter.formatToParts(new Date(Date.UTC(y + 622, 2, day)));
    const part = (type: string) => Number(parts.find(entry => entry.type === type)?.value);
    return part('year') === y && part('month') === 12 && part('day') === 30;
  });
}

export const jalaliMonthDays = (year: number, month: number) => month <= 6 ? 31 : month <= 11 ? 30 : validJalaliDate(`${year}/12/30`) ? 30 : 29;
export const settlementFingerprint = (settlement: InvoiceSettlement, total: number) => JSON.stringify({
  total,
  entries: activeEntries(settlement).map(entry => ({
    ...entry,
    amount: parseAmount(entry.amount),
    attachment: entry.attachment ? [entry.attachment.name, entry.attachment.size, entry.attachment.lastModified] : null,
  })),
});
type InvoiceStages = Record<'sales' | 'finance' | 'warehouse' | 'supply', 'done' | 'pending' | 'waiting'>;
export function approveInvoiceStage(stages: InvoiceStages, stage: keyof InvoiceStages): InvoiceStages {
  const next = { ...stages, [stage]: 'done' as const };
  const keys = ['sales', 'finance', 'warehouse', 'supply'] as const;
  const first = keys.find(key => next[key] !== 'done');
  for (const key of keys) if (next[key] !== 'done') next[key] = key === first ? 'pending' : 'waiting';
  return next;
}

export function validateSettlement(settlement: InvoiceSettlement, total: number, account?: CustomerAccount): string | null {
  const entries = activeEntries(settlement);
  if (!entries.length) return 'حداقل یک روش تسویه انتخاب و تکمیل کنید.';
  if (!Number.isSafeInteger(total) || total <= 0) return 'مبلغ فاکتور باید بیشتر از صفر باشد.';
  for (const entry of entries) {
    const amount = parseAmount(entry.amount);
    if (!Number.isSafeInteger(amount) || amount <= 0) return `مبلغ «${paymentLabels[entry.method]}» باید یک عدد صحیح و بیشتر از صفر باشد.`;
    if (entry.method === 'bank' && !entry.attachment) return 'برای هر واریز بانکی، فیش پرداخت را پیوست کنید.';
    if (entry.method === 'cheque' && !validJalaliDate(entry.date)) return 'تاریخ سررسید هر چک را به‌صورت شمسی معتبر وارد کنید.';
    if (entry.method === 'cheque' && !entry.attachment) return 'تصویر هر چک را پیوست کنید.';
    if (entry.method === 'other' && !entry.description.trim()) return 'توضیحات روش تسویه «سایر» را وارد کنید.';
  }
  const credit = entries.filter(entry => entry.method === 'credit').reduce((sum, entry) => sum + parseAmount(entry.amount), 0);
  if (credit > 0 && !account) return 'اطلاعات اعتبار این مشتری در دسترس نیست.';
  if (account && credit > availableCredit(account)) return 'مبلغ تسویه اعتباری از اعتبار قابل استفاده مشتری بیشتر است.';
  const allocated = allocatedAmount(settlement);
  if (allocated < total) return 'هنوز بخشی از مبلغ فاکتور تعیین تکلیف نشده است.';
  if (allocated > total) return 'جمع روش‌های تسویه از مبلغ فاکتور بیشتر است.';
  return null;
}

// Account fixtures belong only to the existing sample invoices, not new customers.
export function sampleCustomerAccount(id: number): CustomerAccount {
  return { creditLimit: 200000000, transactions: [
    { id: `${id}-opening`, date: '۱۴۰۵/۰۶/۰۱', description: 'مانده ابتدای دوره', debit: 30000000, credit: 0, reference: 'افتتاحیه' },
    { id: `${id}-sale`, date: '۱۴۰۵/۰۶/۱۲', description: 'فاکتور فروش تجهیزات', debit: 55000000, credit: 0, reference: `F-${id}-01` },
    { id: `${id}-receipt`, date: '۱۴۰۵/۰۶/۱۵', description: 'دریافت واریز بانکی', debit: 0, credit: 40000000, reference: `R-${id}-01` },
    { id: `${id}-return`, date: '۱۴۰۵/۰۶/۱۸', description: 'برگشت از فروش', debit: 0, credit: 5000000, reference: `B-${id}-01` },
    { id: `${id}-cheque`, date: '۱۴۰۵/۰۷/۰۱', description: 'وصول چک', debit: 0, credit: id % 2 ? 50000000 : 15000000, reference: `C-${id}-01` },
  ] };
}
import { normalizeDigits } from './numberFormatting';
export { normalizeDigits } from './numberFormatting';
