import type { Invoice } from '../pages/dashboard/DashboardOrders';
import type { InvoiceActivity } from './invoiceActivity';

// Seed only the existing fixture invoices, never newly submitted invoices.
export function sampleInvoiceActivities(invoice: Invoice): InvoiceActivity[] {
  const product = invoice.products[0] ?? 'کالا';
  const base = Date.now() - 2 * 60 * 60 * 1000;
  const events: Pick<InvoiceActivity, 'actor' | 'action' | 'changes'>[] = [
    { actor: invoice.creator, action: 'ایجاد فاکتور فروش', changes: [
      { field: 'خریدار', before: '—', after: invoice.buyer },
      { field: 'نوع فایل', before: '—', after: { pdf: 'PDF', image: 'تصویر', voice: 'صوت', manual: 'ثبت دستی' }[invoice.file] },
    ] },
    { actor: 'سارا احمدی', action: 'ویرایش اطلاعات خریدار', changes: [
      { field: 'شماره تماس', before: '—', after: invoice.phone },
      { field: 'نوع مشتری', before: 'تعیین نشده', after: 'همکار' },
    ] },
    { actor: 'یوسف اسکندرزاده', action: 'تخصیص کارشناسان فروش', changes: [
      { field: 'کارشناسان فروش و کمیسیون از سود', before: '—', after: 'سارا احمدی: ۲٪، علی رضایی: ۱۰٪' },
    ] },
    { actor: 'علی رضایی', action: 'ویرایش ردیف کالا', changes: [
      { field: `${product} · تعداد`, before: '۲', after: '۵' },
      { field: `${product} · قیمت واحد`, before: '۱٬۵۰۰٬۰۰۰', after: '۱٬۴۵۰٬۰۰۰' },
      { field: `${product} · توضیحات`, before: '—', after: 'بسته‌بندی مناسب حمل به محل پروژه' },
    ] },
    { actor: 'داوود محمدنژاد', action: 'اعمال تخفیف', changes: [
      { field: 'دسته تخفیف', before: 'دستی', after: 'نقدی همکار' },
      { field: 'درصد تخفیف', before: '۰', after: '۵' },
    ] },
    { actor: 'مریم کریمی', action: 'حذف ردیف کالا', changes: [
      { field: 'حذف کالا', before: 'واشر آب‌بندی DN80', after: '—' },
    ] },
    { actor: 'یوسف اسکندرزاده', action: 'ثبت پیام در گفت‌وگو', changes: [
      { field: 'گفت‌وگو', before: '—', after: 'پیام جدید ثبت شد' },
    ] },
  ];
  for (const [key, label] of Object.entries({ sales: 'فروش', finance: 'مالی', warehouse: 'انبار', supply: 'تأمین' })) {
    if (invoice.stages[key as keyof Invoice['stages']] === 'done') {
      events.push({ actor: key === 'finance' ? 'مریم کریمی' : 'داوود محمدنژاد', action: `تأیید مرحله ${label}`, changes: [
        { field: `مرحله ${label}`, before: 'در انتظار اقدام', after: 'تأیید شده' },
      ] });
    }
  }
  if (invoice.cancelled) events.push({ actor: invoice.creator, action: 'لغو فاکتور', changes: [
    { field: 'وضعیت فاکتور', before: 'فعال', after: 'لغوشده' },
    { field: 'دلیل لغو', before: '—', after: 'درخواست مشتری' },
    { field: 'توضیح لغو', before: '—', after: 'مشتری زمان اجرای پروژه را به تعویق انداخته است.' },
  ] });
  return events.map((event, index) => ({ ...event, id: `sample-${invoice.id}-${index}`, at: new Date(base + index * 6 * 60 * 1000).toISOString() }));
}
