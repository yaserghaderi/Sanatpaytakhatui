export const shortcutDefinitions = [
  { id: 'shortcuts', label: 'منوی شورتکات‌ها', description: 'باز کردن صفحه تنظیم و شخصی‌سازی میانبرها', group: 'دسترسی سریع', keys: 'Ctrl+K' },
  { id: 'smart', label: 'پیش‌فاکتور هوشمند', description: 'باز کردن پنجره ثبت پیش‌فاکتور هوشمند', group: 'ایجاد درخواست', keys: 'Ctrl+Alt+I' },
  { id: 'manual', label: 'پیش‌فاکتور دستی', description: 'ایجاد و باز کردن یک پیش‌فاکتور خالی', group: 'ایجاد درخواست', keys: 'Ctrl+Alt+M' },
  { id: 'save', label: 'ذخیره اطلاعات', description: 'ذخیره تغییرات درخواست در حال ویرایش', group: 'عملیات فاکتور', keys: 'Ctrl+S' },
  { id: 'navigate', label: 'جابه‌جایی بین درخواست‌ها', description: 'رفتن به درخواست بعدی در فهرست', group: 'عملیات فاکتور', keys: 'Alt+ArrowDown' },
  { id: 'convert', label: 'تبدیل پیش‌فاکتور', description: 'باز کردن پنجره تبدیل نوع سند', group: 'عملیات فاکتور', keys: 'Ctrl+Alt+C' },
  { id: 'star', label: 'ستاره‌دار کردن درخواست', description: 'افزودن یا حذف درخواست از ستاره‌دارها', group: 'عملیات فاکتور', keys: 'Ctrl+Alt+S' },
];
export const shortcutStorageKey = 'dashboard.shortcut-preferences.v1';
export function loadShortcuts(): Record<string, string> {
  const defaults = Object.fromEntries(shortcutDefinitions.map(item => [item.id, item.keys]));
  try {
    const saved = JSON.parse(localStorage.getItem(shortcutStorageKey) ?? '{}');
    const used = new Set<string>();
    for (const item of shortcutDefinitions) {
      const value = typeof saved?.[item.id] === 'string' && /^(?:(?:Ctrl|Meta|Alt|Shift)\+)*(?:[A-Z0-9]|Arrow(?:Down|Up|Left|Right)|F(?:[1-9]|1[0-2])|Space|Enter|Home|End|PageUp|PageDown|Delete|Backspace)$/.test(saved[item.id]) ? saved[item.id] : defaults[item.id];
      defaults[item.id] = used.has(value) ? '' : value;
      if (defaults[item.id]) used.add(value);
    }
  } catch { /* Keep defaults if browser storage is unavailable. */ }
  return defaults;
}

export function shortcutFromEvent(event: KeyboardEvent): string | null {
  if (['Control', 'Meta', 'Alt', 'Shift', 'CapsLock'].includes(event.key)) return null;
  const key = event.code.startsWith('Key') ? event.code.slice(3) : event.code.startsWith('Digit') ? event.code.slice(5) : event.code;
  if (!/^(?:[A-Z0-9]|Arrow(?:Down|Up|Left|Right)|F(?:[1-9]|1[0-2])|Space|Enter|Home|End|PageUp|PageDown|Delete|Backspace)$/.test(key)) return null;
  if (!event.ctrlKey && !event.metaKey && !event.altKey && !/^F\d+$/.test(key)) return null;
  return [event.ctrlKey && 'Ctrl', event.metaKey && 'Meta', event.altKey && 'Alt', event.shiftKey && 'Shift', key].filter(Boolean).join('+');
}
