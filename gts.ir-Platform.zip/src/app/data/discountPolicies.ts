// Demo defaults until panel-managed policies are available; requesters can override them.
export const discountPolicies: Record<string, { label: string; rate: number }> = {
  'cash-colleague': { label: 'نقدی همکار', rate: 10 },
  'cash-customer': { label: 'نقدی مشتری', rate: 5 },
  'credit-colleague': { label: 'اعتباری همکار', rate: 7 },
  'credit-customer': { label: 'اعتباری مشتری', rate: 3 },
};
