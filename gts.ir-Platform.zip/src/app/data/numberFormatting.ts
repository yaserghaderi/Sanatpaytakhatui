export const normalizeDigits = (value: string) => value.replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))).replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)));

export const numericText = (value: number | string) => normalizeDigits(String(value)).replace(/[,٬\s]/g, '').replace(/٫/g, '.');

// Format strings directly so typing, trailing decimal places and large pasted values do not lose precision.
export function groupedNumber(value: number | string): string {
  const normalized = numericText(value);
  if (!normalized || !/^-?\d*(?:\.\d*)?$/.test(normalized)) return String(value);
  const [whole, fraction] = normalized.split('.');
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
  return `${grouped}${fraction === undefined ? '' : `٫${fraction}`}`.replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
}
