import { motion, AnimatePresence } from 'motion/react';
import { FileText } from 'lucide-react';
import { useCart } from '../contexts/CartContext';

export function FloatingQuoteButton() {
  const { getTotalItems, openCart } = useCart();
  const itemCount = getTotalItems();

  return (
    <motion.button
      onClick={openCart}
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="fixed left-6 bottom-6 z-50 bg-gradient-to-br from-[#156394] to-[#0d4a6f] text-white rounded-full px-6 py-4 shadow-2xl hover:shadow-[#156394]/50 transition-all duration-300 group flex items-center gap-3"
    >
      <div className="relative">
        <FileText className="w-6 h-6" />
        
        {/* Badge - همیشه نمایش داده میشه */}
        <div className="absolute -top-2 -right-2 bg-[#F2B524] text-gray-900 rounded-full min-w-[24px] h-6 flex items-center justify-center px-2 shadow-lg">
          <span className="text-xs font-bold">{itemCount}</span>
        </div>
      </div>

      {/* Text Label */}
      <span className="font-bold text-lg">پیش‌فاکتور</span>
    </motion.button>
  );
}