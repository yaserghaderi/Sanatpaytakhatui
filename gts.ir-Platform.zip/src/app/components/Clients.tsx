import { motion } from 'motion/react';
import { Users } from 'lucide-react';

// لوگوهای مشتریان (شامل نام و رنگ برند)
const clients = [
  { name: 'هتل پارسیان', color: '#1a5490' },
  { name: 'مجموعه ورزشی آزادی', color: '#e63946' },
  { name: 'باشگاه پرسپولیس', color: '#d62828' },
  { name: 'هتل اسپیناس', color: '#2a9d8f' },
  { name: 'پارک آبی کوهسنگی', color: '#0077b6' },
  { name: 'مجتمع مسکونی سعادت‌آباد', color: '#6a4c93' },
  { name: 'هتل درویشی', color: '#f77f00' },
  { name: 'باشگاه استقلال', color: '#023e8a' },
  { name: 'مجموعه ورزشی انقلاب', color: '#d00000' },
  { name: 'هتل پارسیان آزادی', color: '#457b9d' },
  { name: 'شهرداری تهران', color: '#06d6a0' },
  { name: 'سازمان ورزش', color: '#fb8500' },
  { name: 'مجتمع تجاری ایران‌مال', color: '#8338ec' },
  { name: 'برج میلاد', color: '#ff006e' },
  { name: 'پارک ملت', color: '#3a86ff' },
  { name: 'مجموعه المپیک', color: '#ffbe0b' },
  { name: 'هتل هما', color: '#06d6a0' },
  { name: 'باشگاه نفت', color: '#118ab2' },
  { name: 'مجتمع تفریحی چیتگر', color: '#073b4c' },
  { name: 'سازمان زیباسازی', color: '#ef476f' },
  { name: 'هتل لاله', color: '#4361ee' },
  { name: 'باشگاه تراکتور', color: '#e63946' },
  { name: 'مجتمع سینمایی ایران', color: '#9d4edd' },
  { name: 'پارک آبی ارم', color: '#06d6a0' },
  { name: 'هتل شیراز', color: '#f72585' },
  { name: 'باشگاه ذوب‌آهن', color: '#e85d04' },
  { name: 'مجموعه ورزشی اکباتان', color: '#3f37c9' },
  { name: 'هتل کوثر', color: '#52b788' },
  { name: 'پارک جنگلی چیتگر', color: '#2d6a4f' },
  { name: 'باشگاه سپاهان', color: '#ffb703' },
  { name: 'مجتمع آبی درکه', color: '#0096c7' },
  { name: 'سازمان میراث فرهنگی', color: '#bc4749' },
  { name: 'هتل مارینا', color: '#4895ef' },
  { name: 'باشگاه فولاد', color: '#d62828' },
  { name: 'مجموعه ورزشی چمران', color: '#06d6a0' },
  { name: 'پارک لاله', color: '#e76f51' },
  { name: 'هتل پردیسان', color: '#7209b7' },
  { name: 'سازمان بنادر', color: '#0077b6' },
  { name: 'مجتمع پالادیوم', color: '#d00000' },
  { name: 'باشگاه ملوان', color: '#03045e' },
];

export function Clients() {
  return (
    <section className="py-16 bg-white relative overflow-hidden border-y border-gray-100">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: `repeating-linear-gradient(45deg, #156394 0px, #156394 1px, transparent 1px, transparent 10px)`,
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Section Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#156394]/10 to-[#F2B524]/10 border border-[#156394]/20 rounded-full px-6 py-3 mb-6"
          >
            <Users className="w-5 h-5 text-[#156394]" />
            <span className="text-gray-700">مشتریان ما</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl md:text-5xl mb-4"
          >
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              مورد اعتماد بزرگ‌ترین سازمان‌ها
            </span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-lg text-gray-600 max-w-2xl mx-auto"
          >
            افتخار همکاری با بیش از ۵۰۰۰ مشتری در سراسر کشور
          </motion.p>
        </div>

        {/* Grid of Clients - نمایش ثابت */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6"
        >
          {clients.map((client, index) => (
            <motion.div
              key={client.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.05 * index }}
              className="bg-white border-2 border-gray-100 rounded-2xl px-6 py-5 hover:border-[#156394]/30 hover:shadow-lg transition-all duration-300 group"
            >
              <div className="flex flex-col items-center justify-center gap-2">
                {/* Logo Circle */}
                <div 
                  className="w-14 h-14 rounded-full flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform duration-300"
                  style={{ backgroundColor: client.color }}
                >
                  <span className="text-xl font-bold">
                    {client.name.charAt(0)}
                  </span>
                </div>
                {/* Client Name */}
                <p className="text-gray-700 text-center text-xs font-medium group-hover:text-[#156394] transition-colors duration-300 line-clamp-2">
                  {client.name}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}