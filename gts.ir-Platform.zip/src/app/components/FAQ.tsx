import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: 'چگونه می‌توانم پیش‌فاکتور آنلاین دریافت کنم؟',
    answer: 'کافیست محصولات مورد نظر خود را به سبد خرید اضافه کنید و سپس درخواست پیش‌فاکتور را ثبت نمایید. کارشناسان ما در اسرع وقت قیمت نهایی را برای شما ارسال خواهند کرد.'
  },
  {
    question: 'آیا امکان خرید حضوری وجود دارد؟',
    answer: 'بله، شما می‌توانید با هماهنگی قبلی به دفتر مرکزی ما مراجعه کرده و محصولات را به صورت حضوری خریداری نمایید. برای هماهنگی با شماره تماس در بخش پایین سایت تماس بگیرید.'
  },
  {
    question: 'زمان ارسال سفارش چقدر است؟',
    answer: 'زمان ارسال بسته به موجودی محصول و مقصد متفاوت است. معمولاً برای شهر تهران بین ۱ تا ۳ روز کاری و برای شهرستان‌ها بین ۳ تا ۷ روز کاری طول می‌کشد.'
  },
  {
    question: 'آیا محصولات دارای گارانتی هستند؟',
    answer: 'تمامی محصولات ما اورجینال و دارای گارانتی معتبر از شرکت‌های تولیدکننده می‌باشند. مدت گارانتی بسته به نوع محصول متفاوت است که در صفحه محصول قید شده است.'
  },
  {
    question: 'آیا امکان خرید عمده با تخفیف وجود دارد؟',
    answer: 'بله، برای خرید عمده و پروژه‌های بزرگ، تخفیف‌های ویژه‌ای در نظر گرفته شده است. لطفاً با بخش فروش تماس بگیرید تا کارشناسان ما بهترین قیمت را برای شما ارائه دهند.'
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 via-white to-blue-50/30 relative overflow-hidden">
      {/* Floating Gradient Orbs */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#156394]/20 to-[#1a7bb3]/20 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-[#F2B524]/20 to-orange-300/20 rounded-full blur-3xl"
          animate={{
            x: [0, -80, 0],
            y: [0, 80, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl mb-4">
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              سوالات متداول
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            پاسخ سوالات رایج شما را در اینجا بیابید
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/80 backdrop-blur-xl rounded-2xl border border-gray-200/50 overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 md:px-8 py-6 flex items-center justify-between gap-4 text-right hover:bg-gray-50/50 transition-colors"
              >
                <span className="text-lg md:text-xl text-gray-900 flex-1">
                  {faq.question}
                </span>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0"
                >
                  <ChevronDown className="w-6 h-6 text-[#156394]" />
                </motion.div>
              </button>

              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-6 md:px-8 pb-6 text-gray-600 leading-relaxed text-lg">
                      {faq.answer}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
