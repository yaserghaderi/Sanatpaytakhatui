import { motion } from 'motion/react';
import { Sparkles } from 'lucide-react';

const brands = [
  {
    name: 'پلیمرتوس',
    description: 'پیشرو در تولید لوله و اتصالات پلیمری',
    products: '۱۲۰+',
    color: '#f58634',
  },
  {
    name: 'پیمتاش',
    description: 'تولیدکننده تجهیزات حرفه‌ای استخر',
    products: '۸۵+',
    color: '#00afef',
  },
  {
    name: 'فارآب',
    description: 'متخصص در سیستم‌های آب‌رسانی',
    products: '۱۵۰+',
    color: '#084e8b',
  },
  {
    name: 'اطلس پول',
    description: 'برترین برند جکوزی و استخر',
    products: '۲۰۰+',
    color: '#01afef',
  },
  {
    name: 'ارس پمپ',
    description: 'تولیدکننده پمپ‌های صنعتی',
    products: '۷۵+',
    color: '#ed3237',
  },
  {
    name: 'بنکن',
    description: 'شیرآلات و اتصالات حرفه‌ای',
    products: '۹۵+',
    color: '#000000',
  },
  {
    name: 'ترموپلاستیک',
    description: 'لوله و اتصالات ترموپلاستیک',
    products: '۱۱۰+',
    color: '#000000',
  },
  {
    name: 'ولدان',
    description: 'تجهیزات پیشرفته لوله‌کشی',
    products: '۱۳۰+',
    color: '#2b4681',
  },
  {
    name: 'مکس پول',
    description: 'سیستم‌های کامل استخر و جکوزی',
    products: '۱۸۰+',
    color: '#3898e9',
  },
  {
    name: 'ارا',
    description: 'ابزار و تجهیزات صنعتی',
    products: '۶۰+',
    color: '#284480',
  },
  {
    name: 'طلایه',
    description: 'چسب و مواد آب‌بندی',
    products: '۵۰+',
    color: '#f79731',
  },
  {
    name: 'فلکسور پارس',
    description: 'فلنج و اتصالات فلزی',
    products: '۱۰۰+',
    color: '#2a91d6',
  },
];

export function Brands() {
  return (
    <section className="py-12 bg-gradient-to-br from-gray-50 via-white to-blue-50/30 relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-10 w-96 h-96 bg-[#156394]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-10 w-96 h-96 bg-[#F2B524]/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        {/* Section Header */}
        <div className="text-center mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#156394]/10 to-[#F2B524]/10 border border-[#156394]/20 rounded-full px-6 py-3 mb-6"
          >
            <Sparkles className="w-5 h-5 text-[#156394]" />
            <span className="text-gray-700">برندهای برتر</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl mb-6"
          >
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              برندهای محبوب
            </span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
          >
            با بهترین برندهای داخلی و خارجی در زمینه تجهیزات استخر و لوله‌کشی همکاری داریم
          </motion.p>
        </div>

        {/* Brands Grid - Creative Layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {brands.map((brand, index) => (
            <motion.div
              key={brand.name}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ 
                delay: index * 0.05, 
                duration: 0.5,
                type: "spring",
                stiffness: 100 
              }}
              whileHover={{ 
                y: -12, 
                scale: 1.03,
                transition: { duration: 0.3 } 
              }}
              className="group relative"
            >
              {/* Card */}
              <div 
                className="relative bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100 hover:border-transparent overflow-hidden h-full"
                style={{
                  '--brand-color': brand.color,
                } as React.CSSProperties}
              >
                {/* Gradient Background - Always Visible */}
                <div 
                  className="absolute inset-0 opacity-5 group-hover:opacity-10 transition-opacity duration-500"
                  style={{ backgroundColor: brand.color }}
                />
                
                {/* Animated Corner Accent */}
                <div 
                  className="absolute top-0 right-0 w-32 h-32 opacity-0 group-hover:opacity-20 rounded-full blur-2xl transition-all duration-500 -translate-y-16 translate-x-16 group-hover:translate-y-0 group-hover:translate-x-0"
                  style={{ backgroundColor: brand.color }}
                />
                
                {/* Content */}
                <div className="relative">
                  {/* Products Count Badge */}
                  <motion.div 
                    className="inline-flex items-center gap-2 text-white rounded-full px-4 py-1.5 mb-5 text-sm font-medium shadow-md"
                    style={{ backgroundColor: brand.color }}
                    whileHover={{ scale: 1.05 }}
                  >
                    <span>{brand.products}</span>
                    <span className="text-xs opacity-90">محصول</span>
                  </motion.div>
                  
                  {/* Brand Name */}
                  <h3 
                    className="text-2xl mb-3 group-hover:scale-105 transition-transform duration-300 origin-right font-bold"
                    style={{ color: brand.color }}
                  >
                    {brand.name}
                  </h3>
                  
                  {/* Description */}
                  <p className="text-gray-600 group-hover:text-gray-700 transition-colors duration-300 leading-relaxed text-base">
                    {brand.description}
                  </p>
                  
                  {/* Hover Arrow */}
                  <div className="mt-6 flex items-center gap-2 text-gray-400 group-hover:gap-4 transition-all duration-300 group-hover:text-[var(--brand-color)]">
                    <span className="text-sm font-medium">مشاهده محصولات</span>
                    <svg className="w-5 h-5 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                  </div>
                </div>

                {/* Shine Effect on Hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
                  <div className="absolute inset-0 bg-gradient-to-l from-transparent via-white/20 to-transparent -skew-x-12 translate-x-full group-hover:-translate-x-full transition-transform duration-1000" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="mt-16 text-center"
        >
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 bg-white rounded-3xl p-8 shadow-xl border border-gray-100">
            <div className="flex-1 text-right">
              <h4 className="text-2xl mb-2 text-gray-900">برند خود را پیدا نکردید؟</h4>
              <p className="text-gray-600">با ما تماس بگیرید تا برندهای بیشتری را معرفی کنیم</p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white rounded-full hover:shadow-xl transition-all duration-300 whitespace-nowrap"
            >
              تماس با ما
            </motion.button>
          </div>
        </motion.div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-20px);
          }
        }
      `}</style>
    </section>
  );
}