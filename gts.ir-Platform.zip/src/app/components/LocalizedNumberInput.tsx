import { useEffect, useLayoutEffect, useRef, useState, type ComponentProps } from 'react';
import { Input } from './ui/input';
import { normalizeDigits } from '../data/invoiceFinance';

export const normalizeNumericInput = (value: string) => normalizeDigits(value)
  .replace(/[,٬\s\u200e\u200f\u061c]/g, '')
  .replace(/٫/g, '.')
  .replace(/−/g, '-');

export function formatNumericInput(value: string, grouped = true): string {
  const [integer, fraction] = value.split('.');
  const formatted = grouped ? integer.replace(/\B(?=(\d{3})+(?!\d))/g, '٬') : integer;
  return `${formatted}${fraction !== undefined ? `٫${fraction}` : ''}`.replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[Number(digit)]);
}

const caretPosition = (formatted: string, logicalPosition: number) => {
  if (!logicalPosition) return 0;
  let count = 0;
  for (let index = 0; index < formatted.length; index++) {
    count += normalizeNumericInput(formatted[index]).length;
    if (count >= logicalPosition) return index + 1;
  }
  return formatted.length;
};

type Props = Omit<ComponentProps<typeof Input>, 'type' | 'value' | 'onChange' | 'inputMode'> & {
  value: string | number;
  onValueChange: (value: string) => void;
  groupThousands?: boolean;
  allowDecimal?: boolean;
};

export default function LocalizedNumberInput({
  value, onValueChange, groupThousands = true, allowDecimal = false,
  onKeyDown, onCompositionStart, onCompositionEnd, ...props
}: Props) {
  const [draft, setDraft] = useState(() => normalizeNumericInput(String(value)));
  const [compositionText, setCompositionText] = useState<string | null>(null);
  const composing = useRef(false);
  const lastEmitted = useRef<string | null>(null);
  const selection = useRef<{ element: HTMLInputElement; position: number } | null>(null);
  useEffect(() => {
    const next = normalizeNumericInput(String(value));
    if (lastEmitted.current !== null && (next === lastEmitted.current || (typeof value === 'number' && Object.is(Number(lastEmitted.current), value)))) return;
    lastEmitted.current = null;
    setDraft(next);
  }, [value]);
  useLayoutEffect(() => {
    const pending = selection.current;
    if (!pending) return;
    selection.current = null;
    if (document.activeElement === pending.element) pending.element.setSelectionRange(pending.position, pending.position);
  });
  const commit = (element: HTMLInputElement, raw: string, caret: number) => {
    const normalized = normalizeNumericInput(raw);
    if (!(allowDecimal ? /^-?\d*(?:\.\d*)?$/ : /^-?\d*$/).test(normalized)) return;
    const logicalPosition = normalizeNumericInput(raw.slice(0, caret)).length;
    const formatted = formatNumericInput(normalized, groupThousands);
    const position = caretPosition(formatted, logicalPosition);
    lastEmitted.current = normalized;
    element.value = formatted;
    element.setSelectionRange(position, position);
    selection.current = { element, position };
    setDraft(normalized);
    onValueChange(normalized);
  };
  return <Input {...props} type="text" inputMode={allowDecimal ? 'decimal' : 'numeric'} dir={props.dir ?? 'ltr'}
    value={compositionText ?? formatNumericInput(draft, groupThousands)}
    onChange={event => {
      const element = event.currentTarget;
      if (composing.current) { setCompositionText(element.value); return; }
      commit(element, element.value, element.selectionStart ?? element.value.length);
    }}
    onCompositionStart={event => { composing.current = true; setCompositionText(event.currentTarget.value); onCompositionStart?.(event); }}
    onCompositionEnd={event => {
      composing.current = false; setCompositionText(null);
      commit(event.currentTarget, event.currentTarget.value, event.currentTarget.selectionStart ?? event.currentTarget.value.length);
      onCompositionEnd?.(event);
    }}
    onKeyDown={event => {
      if (composing.current || event.nativeEvent.isComposing) return;
      const element = event.currentTarget;
      const start = element.selectionStart ?? 0;
      const end = element.selectionEnd ?? start;
      const text = element.value;
      // Delete the neighboring digit, not just a separator that formatting would reinsert.
      if (start === end && event.key === 'Backspace' && text[start - 1] === '٬') {
        event.preventDefault();
        commit(element, text.slice(0, start - 2) + text.slice(start), Math.max(0, start - 2));
      } else if (start === end && event.key === 'Delete' && text[start] === '٬') {
        event.preventDefault();
        commit(element, text.slice(0, start) + text.slice(start + 2), start);
      }
      onKeyDown?.(event);
    }}
  />;
}
