import { motion } from 'motion/react';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from './ui/button';
import { useState, useEffect } from 'react';

// Convert numbers to Persian
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

export function Hero() {
  const [counts, setCounts] = useState([0, 0, 0, 0]);
  const stats = [
    { target: 30, label: 'سال تجربه', suffix: '+' },
    { target: 10000, label: 'تنوع کالا', suffix: '+', separator: '،' },
    { target: 1000, label: 'مشتری راضی', suffix: '+' },
    { target: 14, label: 'نمایندگی برند', suffix: '+' }
  ];

  useEffect(() => {
    const duration = 5000; // 5 seconds animation
    const steps = 60;
    const interval = duration / steps;

    const timer = setInterval(() => {
      setCounts(prevCounts => 
        prevCounts.map((count, index) => {
          const target = stats[index].target;
          const increment = target / steps;
          const newCount = count + increment;
          return newCount >= target ? target : newCount;
        })
      );
    }, interval);

    return () => clearInterval(timer);
  }, []);

  const formatNumber = (num: number, separator?: string) => {
    const rounded = Math.floor(num);
    if (separator && rounded >= 1000) {
      const thousands = Math.floor(rounded / 1000);
      const remainder = rounded % 1000;
      return `${toPersianNumber(thousands)}${separator}${toPersianNumber(remainder.toString().padStart(3, '0'))}`;
    }
    return toPersianNumber(rounded);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Video Background */}
      <div className="absolute inset-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
        >
          <source src="https://www.bluehaven.com/wp-content/uploads/2025/02/DJI-compressed.mp4" type="video/mp4" />
        </video>
        
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6 py-32 z-10">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}

          
          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl mb-8 leading-tight"
          >
            <span className="text-[rgb(249,187,48)] drop-shadow-2xl text-[64px] font-bold">
صنعت پایتخت جهان موج            </span>
          </motion.h1>
          
          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl md:text-2xl text-white/90 mb-12 max-w-3xl mx-auto leading-relaxed drop-shadow-lg"
          >
پیشرو در واردات و پخش لوله و اتصالات

          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap items-center justify-center gap-4 mb-20"
          >
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-white text-white hover:border-white hover:bg-white/20 hover:text-white bg-transparent backdrop-blur-md rounded-full px-8 py-6 text-lg"
            >
              ایجاد پیش فاکتور آنلاین
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, delay: 0.5 + index * 0.1 }}
                className="bg-white/10 backdrop-blur-xl rounded-3xl p-6 border border-white/20 hover:border-white/40 hover:bg-white/20 hover:shadow-xl transition-all"
              >
                <div className="text-3xl md:text-4xl text-white drop-shadow-lg mb-2 font-bold tracking-tight min-h-[3rem] flex items-center justify-center">
                  <span className="inline-block min-w-[7ch]">
                    {formatNumber(counts[index], stat.separator)}{stat.suffix}
                  </span>
                </div>
                <div className="text-white/80 text-sm font-bold">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 w-full text-white z-10">
        <svg viewBox="0 0 1440 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full">
          <path
            d="M0 100L60 95C120 90 240 80 360 75C480 70 600 70 720 75C840 80 960 90 1080 92C1200 95 1320 90 1380 87.5L1440 85V100H1380C1320 100 1200 100 1080 100C960 100 840 100 720 100C600 100 480 100 360 100C240 100 120 100 60 100H0Z"
            fill="currentColor"
          />
        </svg>
      </div>
    </section>
  );
}