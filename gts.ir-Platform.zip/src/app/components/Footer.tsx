import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin, ChevronDown } from 'lucide-react';
import logo from '../../assets/e2bf7b3e45975301863221e28611d21b5c7fdd37.png';
import { useState } from 'react';
import { motion } from 'motion/react';

export function Footer() {
  const currentYear = new Date().getFullYear();
  const [isExpanded, setIsExpanded] = useState(false);

  const fullText = `گروه بازرگانی صنعت پایتخت با سال‌ها تجربه، یکی از پیشروترین مجموعه‌ها در حوزه تأمین و واردات لوله و اتصالات تأسیساتی در ایران است. ما با بهره‌گیری از شبکه گسترده تأمین و ارتباط مستقیم با تولیدکنندگان معتبر داخلی و جهانی، محصولات باکیفیت را با قیمت رقابتی به صنایع مختلف ارائه می‌کنیم.

به‌عنوان واردکننده مستقیم لوله و اتصالات UPVC و CPVC و همچنین تأمین‌کننده اتصالات کربن استیل، محصولات ما از بهترین تولیدکنندگان کشورهای چین و ترکیه تأمین می‌شوند. این محصولات به دلیل دوام بالا و رعایت استانداردهای بین‌المللی، انتخابی ایده‌آل برای پروژه‌های صنعتی، ساختمانی و تأسیساتی هستند.

علاوه بر واردات، صنعت پایتخت نمایندگی رسمی چندین برند داخلی و بین‌المللی را نیز دارا است. ما با ارائه خدمات مشاوره فنی، تحویل به‌موقع و پشتیبانی تخصصی، همواره تلاش می‌کنیم تا انتخابی مطمئن برای پیمانکاران، مهندسان و فعالان حوزه تأسیسات باشیم.

گروه بازرگانی صنعت پایتخت آماده همکاری با شرکت‌های بزرگ صنعتی و ساختمانی در سراسر کشور است و با تأمین تجهیزات تأسیساتی مورد نیاز پروژه‌ها، شریک قابل اعتماد شما خواهد بود.`;

  const shortText = `گروه بازرگانی صنعت پایتخت با سال‌ها تجربه، یکی از پیشروترین مجموعه‌ها در حوزه تأمین و واردات لوله و اتصالات تأسیساتی در ایران است. ما با بهره‌گیری از شبکه گسترده تأمین و ارتباط مستقیم با تولیدکنندگان معتبر داخلی و جهانی، محصولات باکیفیت را با قیمت رقابتی به صنایع مختلف ارائه می‌کنیم.`;

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-[#156394] to-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 py-16">
        {/* About Section with Expand/Collapse */}
        <div className="mb-12 bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10">
          <div className="mb-4">
            <p className="text-gray-200 leading-relaxed text-lg whitespace-pre-line">
              {isExpanded ? fullText : shortText}
            </p>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="flex items-center gap-2 text-[#F2B524] hover:text-[#F2B524]/80 transition-colors group mb-8"
          >
            <span className="font-medium">{isExpanded ? 'بستن' : 'بیشتر '}</span>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <ChevronDown className="w-5 h-5 group-hover:translate-y-0.5 transition-transform" />
            </motion.div>
          </button>

          {/* Contact Numbers */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-6 border-t border-white/10">
            {/* Phone 1 */}
            <a 
              href="tel:02168496000" 
              className="flex items-center gap-3 bg-gradient-to-r from-[#156394]/20 to-[#156394]/10 hover:from-[#156394]/30 hover:to-[#156394]/20 border border-[#156394]/30 rounded-2xl p-4 transition-all hover:scale-105 group"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-xl flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-[#F2B524] text-sm font-medium mb-0.5">تلفن دفتر مرکزی</span>
                <span className="text-white group-hover:text-[#F2B524] transition-colors">۰۲۱-۶۸۴۹۶۰۰۰</span>
              </div>
            </a>

            {/* Phone 2 */}
            <a 
              href="tel:02166193972" 
              className="flex items-center gap-3 bg-gradient-to-r from-[#156394]/20 to-[#156394]/10 hover:from-[#156394]/30 hover:to-[#156394]/20 border border-[#156394]/30 rounded-2xl p-4 transition-all hover:scale-105 group"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-xl flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-[#F2B524] text-sm font-medium mb-0.5">تلفن فروش</span>
                <span className="text-white group-hover:text-[#F2B524] transition-colors">۰۲۱-۶۶۱۹۳۹۷۲</span>
              </div>
            </a>

            {/* Mobile */}
            <a 
              href="tel:09129368238" 
              className="flex items-center gap-3 bg-gradient-to-r from-[#156394]/20 to-[#156394]/10 hover:from-[#156394]/30 hover:to-[#156394]/20 border border-[#156394]/30 rounded-2xl p-4 transition-all hover:scale-105 group"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-xl flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-[#F2B524] text-sm font-medium mb-0.5">موبایل</span>
                <span className="text-white group-hover:text-[#F2B524] transition-colors">۰۹۱۲-۹۳۶-۸۲۳۸</span>
              </div>
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <img src={logo} alt="جهان موج" className="h-14 mb-6" />
            <div className="flex gap-3">
              {[
                { Icon: Facebook, href: '#' },
                { Icon: Twitter, href: '#' },
                { Icon: Linkedin, href: '#' }
              ].map(({ Icon, href }, index) => (
                <a
                  key={index}
                  href={href}
                  className="w-10 h-10 bg-white/10 backdrop-blur-sm hover:bg-gradient-to-r hover:from-[#156394] hover:to-[#1a7bb3] hover:scale-110 rounded-2xl flex items-center justify-center transition-all"
                >
                  <Icon className="w-5 h-5 text-white" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-1">
            <h3 className="text-xl mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">دسترسی سریع</h3>
            <ul className="space-y-3">
              {['درباره ما', 'محصولات', 'بلاگ', 'تماس با ما'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-gray-300 hover:text-[#F2B524] transition-colors flex items-center gap-2 group">
                    <span className="w-0 h-0.5 bg-[#F2B524] group-hover:w-3 transition-all" />
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info - Address Only */}
          <div className="lg:col-span-1">
            <h3 className="text-xl mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">تماس با ما</h3>
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-2xl flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-[#F2B524]" />
              </div>
              <div className="mt-2">
                <p className="text-[#F2B524] text-sm font-medium mb-1">آدرس:</p>
                <span className="text-gray-300 text-sm leading-relaxed">
                  تهران، بازار آهن غرب تهران،<br />
                  مجتمع تجاری پارسیان بلوک دی شمالی،<br />
                  پلاک ۱۱۶ و ۱۱۷
                </span>
              </div>
            </div>
          </div>

          {/* Instagram Special Section */}
          <div className="lg:col-span-1">
            <div className="bg-gradient-to-br from-purple-500/20 via-pink-500/20 to-orange-500/20 backdrop-blur-sm rounded-3xl p-6 border border-pink-500/30">
              <div className="flex flex-col items-center text-center gap-4">
                <a
                  href="#"
                  className="w-16 h-16 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 hover:scale-110 shadow-lg shadow-pink-500/50 rounded-3xl flex items-center justify-center transition-all"
                >
                  <Instagram className="w-8 h-8 text-white" />
                </a>
                <div>
                  <p className="text-white font-medium mb-1">اینستاگرام</p>
                  <p className="text-gray-300 text-sm">@sanatpaytakht</p>
                </div>
                <a 
                  href="#"
                  className="text-[#F2B524] hover:text-[#F2B524]/80 text-sm transition-colors"
                >
                  مشاهده صفحه ←
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 pb-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © {currentYear} جهان موج. تمامی حقوق محفوظ است.
            </p>
            <p className="text-gray-400 text-sm">
              طراحی و سئو توسط:{' '}
              <a 
                href="https://wpneat.ir" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#F2B524] hover:text-[#F2B524]/80 transition-colors"
              >
                WPNEAT.IR
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}