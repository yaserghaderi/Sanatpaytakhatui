import { motion, AnimatePresence } from 'motion/react';
import { X, Brain } from 'lucide-react';
import { useSmartOrder } from '../contexts/SmartOrderContext';
import { SmartOrderFlow } from './SmartOrderFlow';

export function FloatingAIButton() {
  const { isOpen, openSmartOrder, closeSmartOrder } = useSmartOrder();

  return (
    <>
      {/* Floating Button */}
      <motion.button
        onClick={openSmartOrder}
        initial={{ scale: 0, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        transition={{ delay: 0.3, type: 'spring', stiffness: 260, damping: 20 }}
        className="fixed left-6 bottom-24 z-50 bg-gradient-to-br from-[#F2B524] to-[#e09e10] text-gray-900 rounded-full shadow-2xl hover:shadow-[#F2B524]/50 transition-shadow duration-300 group flex items-center gap-0 overflow-hidden"
        style={{ paddingTop: '14px', paddingBottom: '14px', paddingLeft: '20px', paddingRight: '20px' }}
      >
        {/* Pulse ring */}
        <span className="absolute inset-0 rounded-full bg-[#F2B524] animate-ping opacity-20 group-hover:opacity-0" />

        <div className="relative flex items-center gap-3">
          <div className="w-7 h-7 rounded-full bg-gray-900/10 flex items-center justify-center">
            <Brain className="w-4 h-4" />
          </div>
          <div className="text-right leading-tight">
            <p className="font-bold text-sm leading-none mb-0.5">پیش‌فاکتور هوش مصنوعی</p>
            <p className="text-xs opacity-70 leading-none">در کمتر از ۱ دقیقه</p>
          </div>
        </div>
      </motion.button>

      {/* Modal */}
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeSmartOrder}
              className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[60]"
            />

            {/* Modal Panel */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed inset-x-4 bottom-0 top-12 md:inset-auto md:top-1/2 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:w-[560px] md:max-h-[90vh] z-[61] flex flex-col"
            >
              <div className="bg-white rounded-t-3xl md:rounded-3xl shadow-2xl flex flex-col overflow-hidden h-full md:max-h-[90vh]">
                {/* Modal Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gradient-to-l from-[#156394] to-[#1a7bb3] rounded-t-3xl md:rounded-t-3xl shrink-0">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                      <Brain className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h2 className="text-white leading-none mb-0.5">پیش‌فاکتور هوش مصنوعی</h2>
                      <p className="text-white/70 text-xs">عکس بگیر، در کمتر از ۱ دقیقه پیش‌فاکتور بگیر</p>
                    </div>
                  </div>
                  <button
                    onClick={closeSmartOrder}
                    className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center text-white transition-colors"
                  >
                    <X size={18} />
                  </button>
                </div>

                {/* Modal Body */}
                <div className="flex-1 overflow-y-auto p-6">
                  <SmartOrderFlow onClose={closeSmartOrder} />
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
