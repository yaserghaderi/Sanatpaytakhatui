import { motion } from 'motion/react';
import Slider from 'react-slick';
import { SliderStyles } from './SliderStyles';
import { ProductCard } from './ProductCard';
import { Button } from './ui/button';

// Import تصاویر
import img1 from '../../assets/7c5c739cd34e30bf8b766f02cf574cb8706d3e1e.png';
import img2 from '../../assets/5f92673b1304874f3a85849d81343dfdc1025b2a.png';
import img3 from '../../assets/7eeae581676e92671b8ee40714b2154b85c3a3f3.png';

// تبدیل اعداد به فارسی
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

// تولید سایزها برای محصولات
const generateSizes = (productId: number, basePrice: number) => {
  const sizes = ['۱۵', '۲۰', '۲۵', '۳۲', '۴۰', '۵۰', '۶۳', '۷۵', '۹۰', '۱۱۰', '۱۲۵', '۱۴۰', '۱۶۰', '۱۸۰', '۲۰۰', '۲۲۵', '۲۵۰', '۲۸۰', '۳۱۵', '۳۵۵', '۴۰۰', '۴۵۰', '۵۰۰', '۵۶۰', '۶۳۰', '۷۱۰', '۸۰۰', '۹۰۰', '۱۰۰۰', '۱۲۵۰'];
  
  const numSizes = Math.min(5 + (productId * 2), 30);
  const productSizes = sizes.slice(0, numSizes);
  
  return productSizes.map((size, index) => ({
    size,
    price: Math.round(basePrice * (1 + index * 0.15))
  }));
};

// دسته‌بندی محصولات
const categoryProducts = {
  'لوله و اتصالات': [
    {
      id: 101,
      name: 'لوله پلی‌اتیلن PE100',
      category: 'لوله و اتصالات',
      price: 850000,
      rating: 4.7,
      reviews: 89,
      image: img1,
      badge: 'پرفروش',
      sizes: generateSizes(1, 850000)
    },
    {
      id: 102,
      name: 'سه‌راه فشار قوی پلیمرتوس',
      category: 'لوله و اتصالات',
      price: 450000,
      rating: 4.8,
      reviews: 134,
      image: img2,
      discount: 10,
      sizes: generateSizes(2, 450000)
    },
    {
      id: 103,
      name: 'زانو ۹۰ درجه پیمتاش',
      category: 'لوله و اتصالات',
      price: 320000,
      rating: 4.6,
      reviews: 201,
      image: img3,
      badge: 'جدید',
      sizes: generateSizes(3, 320000)
    },
    {
      id: 104,
      name: 'تبدیل فلزی پلیمرتوس',
      category: 'لوله و اتصالات',
      price: 580000,
      rating: 4.9,
      reviews: 76,
      image: img1,
      discount: 15,
      sizes: generateSizes(4, 580000)
    },
    {
      id: 105,
      name: 'فلنچ لوله‌ای فارآب',
      category: 'لوله و اتصالات',
      price: 1250000,
      rating: 5.0,
      reviews: 43,
      image: img2,
      badge: 'ویژه',
      sizes: generateSizes(5, 1250000)
    },
    {
      id: 106,
      name: 'واشر لاستیکی پیمتاش',
      category: 'لوله و اتصالات',
      price: 95000,
      rating: 4.5,
      reviews: 312,
      image: img3,
      sizes: generateSizes(6, 95000)
    },
    {
      id: 107,
      name: 'کوپلینگ سریع بند ولدان',
      category: 'لوله و اتصالات',
      price: 680000,
      rating: 4.8,
      reviews: 158,
      image: img1,
      badge: 'محبوب',
      sizes: generateSizes(7, 680000)
    },
    {
      id: 108,
      name: 'سرلوله‌ای مخروطی',
      category: 'لوله و اتصالات',
      price: 420000,
      rating: 4.7,
      reviews: 99,
      image: img2,
      discount: 8,
      sizes: generateSizes(8, 420000)
    },
  ],
  'استخر و جکوزی': [
    {
      id: 201,
      name: 'فیلتر شنی اطلس پول',
      category: 'استخر و جکوزی',
      price: 18500000,
      rating: 4.9,
      reviews: 56,
      image: img1,
      badge: 'پرفروش',
      sizes: generateSizes(1, 18500000)
    },
    {
      id: 202,
      name: 'پمپ تصفیه مکس پول',
      category: 'استخر و جکوزی',
      price: 12300000,
      rating: 4.8,
      reviews: 87,
      image: img2,
      discount: 12,
      sizes: generateSizes(2, 12300000)
    },
    {
      id: 203,
      name: 'نازل هیدروژت اطلس پول',
      category: 'استخر و جکوزی',
      price: 850000,
      rating: 4.7,
      reviews: 143,
      image: img3,
      badge: 'جدید',
      sizes: generateSizes(3, 850000)
    },
    {
      id: 204,
      name: 'دستگاه کلرزن نمکی',
      category: 'استخر و جکوزی',
      price: 25000000,
      rating: 5.0,
      reviews: 34,
      image: img1,
      badge: 'ویژه',
      sizes: generateSizes(4, 25000000)
    },
    {
      id: 205,
      name: 'چراغ LED زیر آب',
      category: 'استخر و جکوزی',
      price: 2400000,
      rating: 4.6,
      reviews: 198,
      image: img2,
      discount: 18,
      sizes: generateSizes(5, 2400000)
    },
    {
      id: 206,
      name: 'اسکیمر دیواری مکس پول',
      category: 'استخر و جکوزی',
      price: 1650000,
      rating: 4.8,
      reviews: 112,
      image: img3,
      badge: 'محبوب',
      sizes: generateSizes(6, 1650000)
    },
    {
      id: 207,
      name: 'جت هیدروتراپی',
      category: 'استخر و جکوزی',
      price: 3200000,
      rating: 4.9,
      reviews: 67,
      image: img1,
      sizes: generateSizes(7, 3200000)
    },
    {
      id: 208,
      name: 'دریچه تخلیه کف استخر',
      category: 'استخر و جکوزی',
      price: 950000,
      rating: 4.7,
      reviews: 145,
      image: img2,
      discount: 10,
      sizes: generateSizes(8, 950000)
    },
  ],
};

interface CategoryProductsProps {
  category: keyof typeof categoryProducts;
  title: string;
  description: string;
  bgGradient?: string;
}

export function CategoryProducts({ category, title, description, bgGradient = 'from-gray-50 via-white to-blue-50/20' }: CategoryProductsProps) {
  const products = categoryProducts[category];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    rtl: true,
    autoplay: false,
    autoplaySpeed: 3500,
    responsive: [
      {
        breakpoint: 1536,
        settings: {
          slidesToShow: 4,
        }
      },
      {
        breakpoint: 1280,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  };

  return (
    <section className={`py-12 bg-gradient-to-br ${bgGradient}`}>
      <SliderStyles />
      <div className="max-w-[1800px] mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl mb-4"
          >
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              {title}
            </span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 max-w-2xl mx-auto"
          >
            {description}
          </motion.p>
        </div>

        {/* Products Slider */}
        <div className="px-4 pb-12">
          <Slider {...settings}>
            {products.map((product) => (
              <div key={product.id} className="px-3">
                <ProductCard product={product} />
              </div>
            ))}
          </Slider>
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white hover:shadow-xl hover:shadow-[#156394]/20 rounded-full px-10"
          >
            مشاهده همه محصولات {category}
          </Button>
        </motion.div>
      </div>
    </section>
  );
}