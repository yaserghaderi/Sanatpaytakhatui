import { motion } from 'motion/react';
import { Play, CheckCircle2, Award, Users, TrendingUp } from 'lucide-react';
import { useState } from 'react';

export function AboutUs() {
  const [isPlaying, setIsPlaying] = useState(false);

  const stats = [
    { icon: Award, label: 'سال تجربه', value: '۱۵+' },
    { icon: Users, label: 'مشتری راضی', value: '۵۰۰۰+' },
    { icon: TrendingUp, label: 'پروژه موفق', value: '۱۲۰۰+' },
  ];

  const features = [
    'تأمین بهترین برندهای داخلی و خارجی',
    'مشاوره رایگان توسط متخصصان مجرب',
    'تضمین اصالت و کیفیت تمام محصولات',
    'ارسال سریع به سراسر کشور',
    'خدمات پس از فروش حرفه‌ای',
    'قیمت‌های رقابتی و شرایط پرداخت انعطاف‌پذیر',
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-white via-blue-50/30 to-white relative overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-[#156394]/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-[#F2B524]/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content Section */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            {/* Badge */}
            

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="text-4xl md:text-5xl mb-6"
            >
              <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent text-[32px] font-bold">
                پیشرو در تأمین تجهیزات استخر و لوله‌کشی
              </span>
            </motion.h2>

            {/* Features List */}
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.3 + index * 0.05 }}
                  className="flex items-start gap-3 group"
                >
                  <div className="mt-1 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-full p-1 group-hover:scale-110 transition-transform duration-300">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <p className="text-gray-700 group-hover:text-gray-900 transition-colors duration-300">
                    {feature}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 }}
              className="flex flex-wrap gap-4"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white rounded-full hover:shadow-xl hover:shadow-[#156394]/30 transition-all duration-300"
              >
                تماس با ما
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-white border-2 border-[#156394] text-[#156394] rounded-full hover:bg-[#156394] hover:text-white transition-all duration-300"
              >
                مشاهده پروژه‌ها
              </motion.button>
            </motion.div>
          </motion.div>

          {/* Video Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative h-full flex items-center"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl group w-full">
              {/* Video Placeholder */}
              <div className="relative w-full bg-gradient-to-br from-[#156394] to-[#1a7bb3] flex items-center justify-center" style={{ aspectRatio: '4/3' }}>
                {/* Placeholder for actual video */}
                <div className="absolute inset-0 bg-gradient-to-br from-gray-900/50 to-gray-900/30" />
                
                {/* Play Button */}
                {!isPlaying && (
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setIsPlaying(true)}
                    className="relative z-10 w-24 h-24 bg-white rounded-full flex items-center justify-center shadow-2xl group-hover:shadow-white/50 transition-all duration-300"
                  >
                    <Play className="w-10 h-10 text-[#156394] mr-1" fill="currentColor" />
                  </motion.button>
                )}

                {/* Video element - placeholder */}
                {isPlaying && (
                  <div className="absolute inset-0 flex items-center justify-center text-white">
                    <p className="text-lg">قرار دادن ویدیو در اینجا</p>
                  </div>
                )}

                {/* Decorative Elements */}
                <div className="absolute top-6 right-6 bg-white/20 backdrop-blur-sm rounded-2xl px-4 py-2">
                  <p className="text-white text-sm">نمای کلی از مجموعه</p>
                </div>
              </div>

              {/* Stats Overlay */}
              <div className="absolute bottom-6 left-6 right-6 grid grid-cols-3 gap-4">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="bg-white/95 backdrop-blur-sm rounded-2xl p-4 text-center"
                  >
                    <stat.icon className="w-6 h-6 text-[#156394] mx-auto mb-2" />
                    <p className="text-2xl text-gray-900 mb-1">{stat.value}</p>
                    <p className="text-xs text-gray-600">{stat.label}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Floating Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="absolute top-6 left-6 bg-gradient-to-br from-[#F2B524] to-[#e5a615] text-white rounded-3xl px-6 py-4 shadow-xl transform -rotate-3 z-20"
            >
              <p className="text-sm">برترین تأمین‌کننده</p>
              <p className="text-xs opacity-90">در ایران</p>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}