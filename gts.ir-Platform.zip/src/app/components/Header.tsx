import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router';
import {
  Search, User, Menu, X, ChevronDown, FileText, Plus
} from 'lucide-react';
import { Button } from './ui/button';
import logo from '../../assets/e2bf7b3e45975301863221e28611d21b5c7fdd37.png';
import SolarCodeScanBold from '../../imports/SolarCodeScanBold';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';
import { megaTabs } from '../data/megaMenuData';

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

// ─── Products for search ──────────────────────────────────────────────────────

const searchProducts = [
  { id: 1, name: 'شیر توپی برنجی', category: 'شیرآلات', image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=200&q=80', sizes: [{ size: '1/2"', price: 165000 }, { size: '3/4"', price: 185000 }, { size: '1"', price: 220000 }] },
  { id: 2, name: 'فیلتر شنی استخر', category: 'استخر و جکوزی', image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?w=200&q=80', sizes: [{ size: '400mm', price: 14500000 }, { size: '500mm', price: 18500000 }] },
  { id: 3, name: 'لوله PE100 صنعتی', category: 'اتصالات پلیمری', image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=200&q=80', sizes: [{ size: '25mm', price: 95000 }, { size: '50mm', price: 185000 }] },
  { id: 4, name: 'آچار لوله ۱۴ اینچ', category: 'ابزار و تجهیزات', image: 'https://images.unsplash.com/photo-1761074342668-c38fc2e62e67?w=200&q=80', sizes: [{ size: '10"', price: 2800000 }, { size: '14"', price: 3800000 }] },
  { id: 5, name: 'فلنج گلودار DN100', category: 'لرزه‌گیر و فلنج', image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?w=200&q=80', sizes: [{ size: 'DN80', price: 320000 }, { size: 'DN100', price: 420000 }] },
  { id: 6, name: 'پمپ استخر ۱HP', category: 'استخر و جکوزی', image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?w=200&q=80', sizes: [{ size: '0.5HP', price: 6200000 }, { size: '1HP', price: 8500000 }] },
];

const popularSearches = ['شیر توپی', 'پمپ استخر', 'فیلتر شنی', 'فلنج', 'لرزه‌گیر', 'چسب PVC'];

// ─── Mega Menu ────────────────────────────────────────────────────────────────

function MegaMenu({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState(megaTabs[0].id);
  const activeData = megaTabs.find(t => t.id === activeTab)!;
  const menuRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isOpen, onClose]);

  const goToCategory = (tabId?: string) => {
    onClose();
    navigate(tabId ? `/category/${tabId}` : '/category');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={menuRef}
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.15 }}
          className="absolute right-0 left-0 z-50"
        >
          <div className="max-w-7xl mx-auto px-6">
          <div className="bg-white border border-gray-100 border-t-0 rounded-b-2xl overflow-hidden" style={{ boxShadow: '0 24px 64px -12px rgba(0,0,0,0.16)' }}>
            <div className="flex" style={{ minHeight: 400 }}>

              {/* Sidebar tabs */}
              <div className="w-52 border-l border-gray-100 py-3 shrink-0 flex flex-col gap-0.5 overflow-y-auto">
                <p className="text-[11px] text-gray-400 px-4 pb-2 pt-1">دسته‌بندی‌ها</p>
                {megaTabs.map(tab => {
                  const Icon = tab.icon;
                  const active = tab.id === activeTab;
                  return (
                    <button
                      key={tab.id}
                      onMouseEnter={() => setActiveTab(tab.id)}
                      onClick={() => goToCategory(tab.id)}
                      className={`flex items-center gap-2.5 px-3 py-2 mx-2 rounded-xl transition-all duration-100 group text-right
                        ${active ? 'bg-[#156394] text-white shadow-sm' : 'text-gray-700 hover:bg-gray-50'}`}
                    >
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0
                        ${active ? 'bg-white/20' : tab.iconBg}`}>
                        <Icon size={14} className={active ? 'text-white' : tab.iconColor} />
                      </div>
                      <span className="text-xs flex-1">{tab.label}</span>
                      {active && <ChevronDown size={11} className="rotate-[-90deg] opacity-50 shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Content: columns = main items */}
              <div className="flex-1 py-5 px-5 overflow-y-auto">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.1 }}
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <div className={`w-7 h-7 rounded-lg ${activeData.iconBg} flex items-center justify-center`}>
                          <activeData.icon size={15} className={activeData.iconColor} />
                        </div>
                        <h3 className="text-gray-800 text-sm">{activeData.label}</h3>
                      </div>
                      <button onClick={() => goToCategory(activeTab)}
                        className="text-xs text-[#156394] hover:underline flex items-center gap-1">
                        مشاهده همه <ChevronDown size={11} className="rotate-[-90deg]" />
                      </button>
                    </div>

                    {/* 4-column grid — each column = one main item */}
                    <div className="grid gap-4" style={{ gridTemplateColumns: `repeat(${Math.min(activeData.columns.length, 4)}, 1fr)` }}>
                      {activeData.columns.map((col) => (
                        <div key={col.title}>
                          {/* Main item title */}
                          <button
                            onClick={() => goToCategory(activeTab)}
                            className="flex items-center gap-1.5 mb-2 pb-2 border-b border-gray-100 w-full text-right group"
                          >
                            <span className="w-1.5 h-1.5 rounded-full bg-[#156394] shrink-0" />
                            <span className="text-sm text-gray-800 group-hover:text-[#156394] transition-colors">{col.title}</span>
                          </button>
                          {/* Sub-items */}
                          <ul className="space-y-1">
                            {col.subs.map(sub => (
                              <li key={sub}>
                                <button
                                  onClick={() => goToCategory(activeTab)}
                                  className="flex items-center gap-2 w-full text-right py-1 px-1.5 rounded-lg hover:bg-gray-50 transition-colors group"
                                >
                                  <span className="w-1 h-1 rounded-full bg-gray-300 group-hover:bg-[#156394] shrink-0 transition-colors" />
                                  <span className="text-xs text-gray-500 group-hover:text-[#156394] transition-colors">{sub}</span>
                                </button>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>

                    {/* Bottom bar */}
                    <div className="mt-5 pt-4 border-t border-gray-100 flex items-center justify-between">
                      <p className="text-xs text-gray-400">برای مشاوره تخصصی با کارشناسان ما تماس بگیرید</p>
                      <a href="tel:" className="px-4 py-2 bg-[#156394] text-white rounded-full text-xs hover:bg-[#0d4a6f] transition-colors shrink-0">
                        تماس با ما
                      </a>
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────

export function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const isHomePage = location.pathname === '/';
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isScrolled, setIsScrolled] = useState(!isHomePage);
  const [selectedSizes, setSelectedSizes] = useState<Record<string, number>>({});

  const { getTotalItems, toggleCart, addToCart } = useCart();

  useEffect(() => {
    if (!isHomePage) {
      setIsScrolled(true);
      return;
    }
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isHomePage]);

  const filteredProducts = searchQuery.trim()
    ? searchProducts.filter(p => p.name.includes(searchQuery) || p.category.includes(searchQuery))
    : [];
  const showResults = isSearchFocused && searchQuery.trim().length > 0;

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-white/96 backdrop-blur-xl border-b border-gray-200/60 shadow-sm'
          : 'backdrop-blur-md bg-white/80 md:bg-white/20 border-b border-white/10'
      }`}>
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-3.5">
          <div className="flex items-center gap-4 md:gap-6">
            {/* Logo */}
            <a href="/" onClick={e => { e.preventDefault(); navigate('/'); }} className="shrink-0">
              <img src={logo} alt="جهان موج" className="h-10 md:h-11 w-auto" />
            </a>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-2 flex-1">
              {/* Categories button — icon always white */}
              <button
                onClick={() => setIsMegaMenuOpen(v => !v)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-full transition-all duration-200 shrink-0
                  ${isMegaMenuOpen
                    ? 'bg-[#156394] text-white shadow-md'
                    : isScrolled
                      ? 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
              >
                {/* Icon always white when scrolled by using a white-tinted wrapper */}
                <div className="w-5 h-5 shrink-0" style={{ '--fill-0': (isScrolled && !isMegaMenuOpen) ? '#374151' : '#ffffff' } as React.CSSProperties}>
                  <SolarCodeScanBold />
                </div>
                <span className="text-sm">دسته‌بندی محصولات</span>
                <ChevronDown size={13} className={`transition-transform duration-200 ${isMegaMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <input
                  type="text"
                  placeholder="جستجو در محصولات..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  onBlur={() => setTimeout(() => setIsSearchFocused(false), 150)}
                  className={`w-full pr-10 pl-8 py-2.5 rounded-full text-sm focus:outline-none transition-all
                    ${isScrolled
                      ? 'bg-gray-100 text-gray-800 placeholder:text-gray-400 focus:bg-white focus:ring-2 focus:ring-[#156394]/20'
                      : 'bg-white/20 text-white placeholder:text-white/60 focus:bg-white focus:text-gray-800 focus:placeholder:text-gray-400'
                    }`}
                />
                <Search size={15} className={`absolute right-3.5 top-1/2 -translate-y-1/2 ${isScrolled ? 'text-gray-400' : 'text-white/60'}`} />
                {searchQuery && <button onClick={() => setSearchQuery('')} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"><X size={13} /></button>}

                <AnimatePresence>
                  {showResults && filteredProducts.length > 0 && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                      className="absolute top-full right-0 left-0 mt-2 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-50"
                    >
                      <div className="p-3 space-y-1">
                        <p className="text-xs text-gray-400 px-2 pb-1">نتایج جستجو</p>
                        {filteredProducts.map(product => {
                          const key = `p-${product.id}`;
                          const sIdx = selectedSizes[key] || 0;
                          const size = product.sizes[sIdx];
                          return (
                            <div key={product.id} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-xl">
                              <img src={product.image} alt={product.name} className="w-11 h-11 rounded-xl object-cover shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-gray-800 truncate">{product.name}</p>
                                <p className="text-xs text-[#156394]">{toPersianNumber(size.price.toLocaleString())} تومان</p>
                              </div>
                              <button onClick={() => { addToCart({ productId: product.id, productName: product.name, productCategory: product.category, productImage: product.image, size: size.size, price: size.price }); toast.success(`${product.name} اضافه شد`); }}
                                className="p-1.5 bg-[#156394] text-white rounded-full hover:bg-[#0d4a6f] transition-colors shrink-0">
                                <Plus size={13} />
                              </button>
                            </div>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}
                  {isSearchFocused && !searchQuery && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                      className="absolute top-full right-0 left-0 mt-2 bg-white rounded-2xl shadow-2xl border border-gray-100 p-4 z-50"
                    >
                      <p className="text-xs text-gray-400 mb-2">جستجوهای محبوب</p>
                      <div className="flex flex-wrap gap-2">
                        {popularSearches.map(s => (
                          <button key={s} onMouseDown={() => setSearchQuery(s)}
                            className="px-3 py-1.5 bg-gray-50 border border-gray-200 text-gray-600 hover:text-[#156394] hover:border-[#156394]/30 rounded-full text-xs transition-colors">
                            {s}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2 mr-auto lg:mr-0">
              <Button variant="ghost" size="icon" className="md:hidden rounded-full text-gray-700"
                onClick={() => setIsMobileSearchOpen(v => !v)}>
                <Search size={20} />
              </Button>
              <Button variant="ghost" size="icon" className="lg:hidden rounded-full"
                onClick={() => setIsMenuOpen(v => !v)}>
                {isMenuOpen ? <X size={22} /> : <Menu size={22} />}
              </Button>
              <button onClick={() => navigate('/account')}
                className={`hidden md:flex items-center gap-1.5 px-3 py-2 rounded-full transition-colors
                  ${isScrolled ? 'text-gray-600 hover:bg-gray-100' : 'text-white hover:bg-white/20'}`}>
                <User size={18} />
                <span className="text-xs hidden lg:inline">حساب من</span>
              </button>
              <button onClick={() => navigate('/dashboard')}
                className={`hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-full text-xs transition-colors
                  ${isScrolled ? 'text-gray-600 hover:bg-gray-100 border border-gray-200' : 'text-white border border-white/20 hover:bg-white/20'}`}>
                پنل مدیریت
              </button>
              <button
                onClick={toggleCart}
                className={`relative flex items-center gap-2 px-4 py-2.5 rounded-full transition-all
                  ${isScrolled
                    ? 'bg-gray-100 text-gray-700 hover:bg-[#156394] hover:text-white'
                    : 'bg-white/20 text-white hover:bg-white/30'
                  }`}
              >
                <FileText size={18} />
                <span className="hidden sm:inline text-sm">پیش‌فاکتور</span>
                <span className="absolute -top-1.5 -right-1.5 bg-[#F2B524] text-gray-900 text-xs rounded-full w-5 h-5 flex items-center justify-center shadow-md font-bold">
                  {toPersianNumber(getTotalItems())}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Mega Menu */}
        <div className="hidden lg:block relative">
          <MegaMenu isOpen={isMegaMenuOpen} onClose={() => setIsMegaMenuOpen(false)} />
        </div>

        {/* Mobile Search */}
        <AnimatePresence>
          {isMobileSearchOpen && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="lg:hidden bg-white border-t border-gray-100 overflow-hidden">
              <div className="p-4">
                <div className="relative">
                  <input type="text" placeholder="جستجو..." value={searchQuery}
                    onChange={e => setSearchQuery(e.target.value)}
                    className="w-full pr-9 pl-8 py-2.5 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20 focus:bg-white" />
                  <Search size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
                  <button onClick={() => setIsMobileSearchOpen(false)} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"><X size={13} /></button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {popularSearches.map(s => (
                    <button key={s} onClick={() => setSearchQuery(s)}
                      className="px-3 py-1.5 bg-gray-50 border border-gray-200 text-gray-600 rounded-full text-xs">{s}</button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="lg:hidden bg-white border-t border-gray-100 overflow-hidden max-h-[70vh] overflow-y-auto">
              <nav className="p-3 space-y-0.5">
                {megaTabs.map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button key={tab.id}
                      onClick={() => { navigate(`/category/${tab.id}`); setIsMenuOpen(false); }}
                      className="w-full flex items-center gap-3 px-3 py-2.5 text-gray-700 hover:bg-gray-50 rounded-xl transition-colors text-right">
                      <div className={`w-7 h-7 rounded-lg ${tab.iconBg} flex items-center justify-center shrink-0`}>
                        <Icon size={14} className={tab.iconColor} />
                      </div>
                      <span className="flex-1 text-sm">{tab.label}</span>
                    </button>
                  );
                })}
                <div className="pt-2 border-t border-gray-100">
                  <button onClick={() => { toggleCart(); setIsMenuOpen(false); }}
                    className="w-full flex items-center gap-3 px-3 py-2.5 text-[#156394] hover:bg-blue-50 rounded-xl transition-colors">
                    <FileText size={16} />
                    <span className="text-sm">پیش‌فاکتور ({toPersianNumber(getTotalItems())} مورد)</span>
                  </button>
                </div>
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}
