import { X, Trash2, Plus, Minus, Download, FileText } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { Button } from './ui/button';
import { motion, AnimatePresence } from 'motion/react';
import { useState, useRef } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// تبدیل اعداد به فارسی
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

// فرمت کردن قیمت به تومان
const formatPrice = (price: number) => {
  return toPersianNumber(price.toLocaleString('fa-IR'));
};

// تبدیل تاریخ میلادی به شمسی
const toJalali = (date: Date) => {
  const gregorianYear = date.getFullYear();
  const gregorianMonth = date.getMonth() + 1;
  const gregorianDay = date.getDate();

  const gy = gregorianYear - 1600;
  const gm = gregorianMonth - 1;
  const gd = gregorianDay - 1;

  let g_day_no = 365 * gy + Math.floor((gy + 3) / 4) - Math.floor((gy + 99) / 100) + Math.floor((gy + 399) / 400);

  for (let i = 0; i < gm; ++i) {
    g_day_no += [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][i];
  }

  if (gm > 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0)) {
    g_day_no++;
  }

  g_day_no += gd;

  let j_day_no = g_day_no - 79;

  const j_np = Math.floor(j_day_no / 12053);
  j_day_no %= 12053;

  let jy = 979 + 33 * j_np + 4 * Math.floor(j_day_no / 1461);
  j_day_no %= 1461;

  if (j_day_no >= 366) {
    jy += Math.floor((j_day_no - 1) / 365);
    j_day_no = (j_day_no - 1) % 365;
  }

  let jm, jd;
  if (j_day_no < 186) {
    jm = 1 + Math.floor(j_day_no / 31);
    jd = 1 + (j_day_no % 31);
  } else {
    jm = 7 + Math.floor((j_day_no - 186) / 30);
    jd = 1 + ((j_day_no - 186) % 30);
  }

  return { year: jy, month: jm, day: jd };
};

// نام ماه‌های شمسی
const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CartDrawer({ isOpen, onClose }: CartDrawerProps) {
  const { cartItems, removeFromCart, updateQuantity, getTotalPrice, getTotalItems } = useCart();
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);

  // تیرهای تخفیف
  const MAX_DISCOUNT_AMOUNT = 125000000; // سقف تخفیف: 125 میلیون تومان
  
  const discountTiers = [
    { minPrice: 0, maxPrice: 20000000, discount: 0, label: 'شروع' },
    { minPrice: 20000000, maxPrice: 50000000, discount: 5, label: '۲۰ میلیون' },
    { minPrice: 50000000, maxPrice: 100000000, discount: 10, label: '۵۰ میلیون' },
    { minPrice: 100000000, maxPrice: 200000000, discount: 15, label: '۱۰۰ میلیون' },
    { minPrice: 200000000, maxPrice: 500000000, discount: 20, label: '۲۰۰ میلیون' },
    { minPrice: 500000000, maxPrice: Infinity, discount: 25, label: '۵۰۰ میلیون' },
  ];

  // محاسبه تخفیف بر اساس مبلغ کل
  const getDiscountInfo = () => {
    const total = getTotalPrice();
    const currentTier = discountTiers.find(tier => total >= tier.minPrice && total < tier.maxPrice);
    const nextTier = discountTiers.find(tier => tier.minPrice > total);
    
    // محاسبه مبلغ تخفیف با سقف 125 میلیون
    const calculatedDiscount = (total * (currentTier?.discount || 0)) / 100;
    const actualDiscountAmount = Math.min(calculatedDiscount, MAX_DISCOUNT_AMOUNT);
    
    return {
      total,
      currentDiscount: currentTier?.discount || 0,
      currentTier,
      nextTier,
      allTiers: discountTiers,
      discountAmount: actualDiscountAmount,
      isCapped: calculatedDiscount > MAX_DISCOUNT_AMOUNT
    };
  };

  // محاسبه قیمت نهایی با تخفیف
  const getTotalPriceWithDiscount = () => {
    const discountInfo = getDiscountInfo();
    return discountInfo.total - discountInfo.discountAmount;
  };

  // تابع دانلود PDF با html2canvas
  const downloadPDF = async () => {
    if (!invoiceRef.current || cartItems.length === 0) return;

    setIsGeneratingPDF(true);

    try {
      // ایجاد canvas از محتوای HTML
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        logging: false,
        backgroundColor: '#ffffff',
        onclone: (clonedDoc) => {
          // تبدیل تمام oklch به hex
          const allElements = clonedDoc.querySelectorAll('*');
          allElements.forEach((element) => {
            const el = element as HTMLElement;
            const computedStyle = window.getComputedStyle(el);
            
            // تبدیل background-color
            if (computedStyle.backgroundColor && computedStyle.backgroundColor.includes('oklch')) {
              el.style.backgroundColor = 'rgb(255, 255, 255)';
            }
            
            // تبدیل color
            if (computedStyle.color && computedStyle.color.includes('oklch')) {
              el.style.color = 'rgb(0, 0, 0)';
            }
            
            // تبدیل border-color
            if (computedStyle.borderColor && computedStyle.borderColor.includes('oklch')) {
              el.style.borderColor = 'rgb(229, 231, 235)';
            }
          });
        }
      });

      // ایجاد PDF
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pdfWidth = 210; // A4 width in mm
      const pdfHeight = 297; // A4 height in mm
      const imgWidth = pdfWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      // اگر ارتفاع تصویر بیشتر از یک صفحه است، آن را به صفحات متعدد تقسیم کن
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;

      while (heightLeft > 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pdfHeight;
      }

      // دانلود فایل
      const jalaliDate = toJalali(new Date());
      const fileName = `Pish-Factor-${toPersianNumber(jalaliDate.year)}-${toPersianNumber(jalaliDate.month)}-${toPersianNumber(jalaliDate.day)}.pdf`;
      pdf.save(fileName);

    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('خطا در تولید پیش‌فاکتور. لطفا دوباره تلاش کنید.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  // محاسبه تاریخ شمسی
  const currentDate = new Date();
  const jalaliDate = toJalali(currentDate);
  const persianDate = `${toPersianNumber(jalaliDate.day)} ${persianMonths[jalaliDate.month - 1]} ${toPersianNumber(jalaliDate.year)}`;
  const invoiceNumber = `INV-${Date.now().toString().slice(-8)}`;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="fixed top-0 right-0 h-full w-full max-w-md bg-white shadow-2xl z-50 flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center gap-3">
                <h2 className="text-2xl text-gray-900">پیش‌فاکتور</h2>
                <span className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white px-3 py-1 rounded-full text-sm">
                  {toPersianNumber(getTotalItems())} محصول
                </span>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>

            {/* Cart Items */}
            <div className="flex-1 overflow-y-auto p-6">
              {cartItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-gray-500">
                  <div className="w-32 h-32 mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <motion.div
                      animate={{ scale: [1, 1.1, 1] }}
                      transition={{ repeat: Infinity, duration: 2 }}
                    >
                      <FileText className="w-16 h-16 text-gray-400" />
                    </motion.div>
                  </div>
                  <p className="text-lg mb-2 font-semibold">پیش‌فاکتور شما خالی است</p>
                  <p className="text-sm text-gray-400 text-center px-6">
                    محصولات مرد نظر خود را اضافه کنید
                  </p>
                  <p className="text-xs text-gray-400 text-center px-6 mt-2">
                    پس از افزودن محصولات، می‌توانید پیش‌فاکتور را دانلود کنید
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cartItems.map((item) => {
                    const finalPrice = item.discount
                      ? Math.round(item.price * (1 - item.discount / 100))
                      : item.price;

                    return (
                      <motion.div
                        key={`${item.productId}-${item.size}`}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, x: 100 }}
                        className="bg-gray-50 rounded-2xl p-4 border border-gray-100"
                      >
                        <div className="flex gap-4">
                          {/* Product Image */}
                          <div className="flex-shrink-0">
                            <img
                              src={item.productImage}
                              alt={item.productName}
                              className="w-20 h-20 rounded-xl object-cover"
                            />
                          </div>

                          {/* Product Info */}
                          <div className="flex-1 min-w-0">
                            <h3 className="text-gray-900 mb-1 line-clamp-1">
                              {item.productName}
                            </h3>
                            <p className="text-xs text-[#F2B524] mb-2">
                              {item.productCategory} • سایز {item.size}
                            </p>

                            {/* Price & Quantity */}
                            <div className="flex items-center justify-between">
                              <div className="flex flex-col">
                                <span className="text-sm bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
                                  {formatPrice(finalPrice * item.quantity)} تومان
                                </span>
                                {item.discount && (
                                  <span className="text-xs text-gray-400 line-through">
                                    {formatPrice(item.price * item.quantity)}
                                  </span>
                                )}
                              </div>

                              {/* Quantity Controls */}
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => updateQuantity(item.productId, item.size, item.quantity - 1)}
                                  className="w-7 h-7 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100 transition-colors"
                                >
                                  <Minus className="w-3 h-3 text-gray-600" />
                                </button>
                                <span className="text-sm text-gray-900 min-w-[1.5rem] text-center">
                                  {toPersianNumber(item.quantity)}
                                </span>
                                <button
                                  onClick={() => updateQuantity(item.productId, item.size, item.quantity + 1)}
                                  className="w-7 h-7 rounded-full bg-gradient-to-r from-[#156394] to-[#1a7bb3] flex items-center justify-center hover:shadow-md transition-all"
                                >
                                  <Plus className="w-3 h-3 text-white" />
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Delete Button */}
                          <button
                            onClick={() => removeFromCart(item.productId, item.size)}
                            className="flex-shrink-0 p-2 hover:bg-red-50 rounded-full transition-colors group"
                          >
                            <Trash2 className="w-5 h-5 text-gray-400 group-hover:text-red-500" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Footer */}
            {cartItems.length > 0 && (
              <div className="border-t border-gray-200 p-6 bg-gray-50">
                {/* Discount Info */}
                {(() => {
                  const discountInfo = getDiscountInfo();
                  return discountInfo.currentDiscount > 0 ? (
                    <div className={`mb-4 p-4 rounded-xl border-2 ${
                      discountInfo.isCapped 
                        ? 'bg-gradient-to-br from-amber-50 to-orange-50 border-amber-300' 
                        : 'bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200'
                    }`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-sm font-bold ${
                          discountInfo.isCapped ? 'text-amber-700' : 'text-emerald-700'
                        }`}>
                          🎁 {discountInfo.isCapped ? 'سقف تخفیف (۱۰۰م)' : 'تخفیف ویژه'}
                        </span>
                        <span className={`text-lg font-bold ${
                          discountInfo.isCapped ? 'text-amber-600' : 'text-emerald-600'
                        }`}>
                          {toPersianNumber(discountInfo.currentDiscount)}٪
                        </span>
                      </div>
                      <div className="text-xs text-gray-600">
                        شما {formatPrice(discountInfo.discountAmount)} تومان تخفیف دریافت کردید!
                      </div>
                      {discountInfo.nextTier && !discountInfo.isCapped && (
                        <div className="text-xs text-emerald-600 mt-2">
                          تا تخفیف {toPersianNumber(discountInfo.nextTier.discount)}٪ فقط{' '}
                          {formatPrice(discountInfo.nextTier.minPrice - discountInfo.total)} تومان مانده!
                        </div>
                      )}
                      {discountInfo.isCapped && (
                        <div className="text-xs text-amber-700 mt-2 font-bold">
                          ✨ شما به حداکثر تخفیف رسیده‌اید!
                        </div>
                      )}
                    </div>
                  ) : discountInfo.nextTier ? (
                    <div className="mb-4 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border-2 border-blue-200">
                      <div className="text-sm text-blue-700 font-bold mb-1">💰 تا ۱۰۰ میلیون تومان تخفیف بگیرید!</div>
                      <div className="text-xs text-gray-600">
                        تا تخفیف {toPersianNumber(discountInfo.nextTier.discount)}٪ فقط{' '}
                        {formatPrice(discountInfo.nextTier.minPrice - discountInfo.total)} تومان مانده!
                      </div>
                    </div>
                  ) : null;
                })()}

                {/* Total */}
                <div className="space-y-2 mb-4 pb-4 border-b border-gray-200">
                  {getDiscountInfo().currentDiscount > 0 && (
                    <>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-500">مبلغ کل:</span>
                        <span className="text-gray-500 line-through">
                          {formatPrice(getTotalPrice())} تومان
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className={getDiscountInfo().isCapped ? 'text-amber-600' : 'text-emerald-600'}>
                          تخفیف {getDiscountInfo().isCapped && '(سقف ۱۰۰م)'}:
                        </span>
                        <span className={getDiscountInfo().isCapped ? 'text-amber-600' : 'text-emerald-600'}>
                          {formatPrice(getDiscountInfo().discountAmount)} تومان-
                        </span>
                      </div>
                    </>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">
                      {getDiscountInfo().currentDiscount > 0 ? 'قابل پرداخت:' : 'مجموع:'}
                    </span>
                    <div className="flex flex-col items-end">
                      <span className="text-2xl bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
                        {formatPrice(getTotalPriceWithDiscount())} تومان
                      </span>
                      <span className="text-xs text-gray-500">
                        {toPersianNumber(getTotalItems())} محصول
                      </span>
                    </div>
                  </div>
                </div>

                {/* Checkout Button */}
                <Button
                  className="w-full bg-gradient-to-r from-[#156394] to-[#1a7bb3] hover:shadow-xl hover:shadow-[#156394]/20 text-white rounded-full py-6"
                  size="lg"
                >
                  تکمیل خرید
                </Button>

                {/* Download PDF Button */}
                <Button
                  className="w-full bg-gradient-to-r from-[#F2B524] to-[#f5c947] hover:shadow-xl hover:shadow-[#F2B524]/20 text-gray-900 rounded-full py-6 mt-3 flex items-center justify-center gap-2"
                  size="lg"
                  onClick={downloadPDF}
                  disabled={isGeneratingPDF}
                >
                  {isGeneratingPDF ? (
                    <>
                      <div className="w-5 h-5 border-2 border-gray-900 border-t-transparent rounded-full animate-spin" />
                      در حال تولید پیش‌فاکتور...
                    </>
                  ) : (
                    <>
                      <Download className="w-5 h-5" />
                      دانلود پیش‌فاکتور
                    </>
                  )}
                </Button>
              </div>
            )}
          </motion.div>

          {/* Hidden Invoice Template for PDF */}
          <div style={{ position: 'fixed', left: '-9999px', top: 0 }}>
            <div
              ref={invoiceRef}
              style={{ 
                fontFamily: 'IRANSans, Tahoma, sans-serif', 
                direction: 'rtl',
                backgroundColor: '#ffffff',
                padding: '48px',
                width: '794px'
              }}
            >
              {/* Header */}
              <div 
                style={{
                  background: 'linear-gradient(to left, #156394, #1a7bb3)',
                  color: '#ffffff',
                  padding: '32px',
                  borderRadius: '16px',
                  marginBottom: '32px'
                }}
              >
                <h1 style={{ fontSize: '36px', marginBottom: '8px', fontWeight: 'bold', margin: 0 }}>پیش‌فاکتور</h1>
                <p style={{ fontSize: '20px', opacity: 0.9, margin: 0 }}>شرکت صنعت پایتخت جهان موج</p>
              </div>

              {/* Invoice Info */}
              <div 
                style={{
                  backgroundColor: '#f3f4f6',
                  padding: '24px',
                  borderRadius: '12px',
                  marginBottom: '32px',
                  display: 'grid',
                  gridTemplateColumns: 'repeat(3, 1fr)',
                  gap: '16px'
                }}
              >
                <div>
                  <p style={{ fontSize: '14px', color: '#4b5563', marginBottom: '4px' }}>شماره فاکتور</p>
                  <p style={{ fontSize: '18px', color: '#156394', fontWeight: '600', margin: 0 }}>{toPersianNumber(invoiceNumber)}</p>
                </div>
                <div>
                  <p style={{ fontSize: '14px', color: '#4b5563', marginBottom: '4px' }}>تاریخ صدور</p>
                  <p style={{ fontSize: '18px', fontWeight: '600', margin: 0 }}>{persianDate}</p>
                </div>
                <div>
                  <p style={{ fontSize: '14px', color: '#4b5563', marginBottom: '4px' }}>تعداد کل محصولات</p>
                  <p style={{ fontSize: '18px', color: '#F2B524', fontWeight: '600', margin: 0 }}>{toPersianNumber(getTotalItems())} محصول</p>
                </div>
              </div>

              {/* Items Table */}
              <div style={{ marginBottom: '32px' }}>
                <div 
                  style={{
                    backgroundColor: '#156394',
                    color: '#ffffff',
                    padding: '16px',
                    borderRadius: '12px 12px 0 0',
                    display: 'grid',
                    gridTemplateColumns: '60px 80px 1fr 100px 80px 120px',
                    gap: '16px',
                    textAlign: 'center',
                    fontWeight: '600'
                  }}
                >
                  <div>ردیف</div>
                  <div>تصویر</div>
                  <div style={{ textAlign: 'right' }}>نام محصول</div>
                  <div>سایز</div>
                  <div>تعداد</div>
                  <div>قیمت کل</div>
                </div>
                {cartItems.map((item, index) => {
                  const finalPrice = item.discount
                    ? Math.round(item.price * (1 - item.discount / 100))
                    : item.price;

                  return (
                    <div
                      key={`${item.productId}-${item.size}`}
                      style={{
                        display: 'grid',
                        gridTemplateColumns: '60px 80px 1fr 100px 80px 120px',
                        gap: '16px',
                        padding: '16px',
                        textAlign: 'center',
                        borderBottom: '1px solid #e5e7eb',
                        backgroundColor: index % 2 === 0 ? '#ffffff' : '#f9fafb',
                        alignItems: 'center'
                      }}
                    >
                      <div style={{ color: '#156394', fontWeight: '600' }}>{toPersianNumber(index + 1)}</div>
                      <div style={{ display: 'flex', justifyContent: 'center' }}>
                        <img
                          src={item.productImage}
                          alt={item.productName}
                          style={{
                            width: '60px',
                            height: '60px',
                            objectFit: 'cover',
                            borderRadius: '8px',
                            border: '2px solid #e5e7eb'
                          }}
                          crossOrigin="anonymous"
                        />
                      </div>
                      <div style={{ textAlign: 'right' }}>{item.productName}</div>
                      <div style={{ color: '#F2B524', fontWeight: '600' }}>{item.size}</div>
                      <div style={{ fontWeight: '600' }}>{toPersianNumber(item.quantity)}</div>
                      <div style={{ color: '#156394', fontWeight: '600' }}>{formatPrice(finalPrice * item.quantity)} تومان</div>
                    </div>
                  );
                })}
              </div>

              {/* Discount and Total */}
              <div>
                {(() => {
                  const discountInfo = getDiscountInfo();
                  return discountInfo.currentDiscount > 0 ? (
                    <div
                      style={{
                        background: 'linear-gradient(to left, #10b981, #059669)',
                        color: '#ffffff',
                        padding: '20px',
                        borderRadius: '12px',
                        marginBottom: '16px'
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                        <span style={{ fontSize: '18px' }}>مبلغ کل:</span>
                        <span style={{ fontSize: '20px', textDecoration: 'line-through', opacity: 0.8 }}>{formatPrice(getTotalPrice())} تومان</span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                        <span style={{ fontSize: '18px' }}>🎁 تخفیف ({toPersianNumber(discountInfo.currentDiscount)}٪){discountInfo.isCapped ? ' - سقف' : ''}:</span>
                        <span style={{ fontSize: '20px' }}>- {formatPrice(discountInfo.discountAmount)} تومان</span>
                      </div>
                      {discountInfo.isCapped && (
                        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: '12px', padding: '8px', background: 'rgba(255,255,255,0.2)', borderRadius: '8px' }}>
                          <span style={{ fontSize: '14px' }}>✨ شما به حداکثر سقف تخفیف (۱۲۵ میلیون تومان) رسیدید!</span>
                        </div>
                      )}
                      <div style={{ borderTop: '2px solid rgba(255,255,255,0.3)', paddingTop: '12px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ fontSize: '24px', fontWeight: 'bold' }}>قابل پرداخت:</span>
                          <span style={{ fontSize: '32px', fontWeight: 'bold' }}>{formatPrice(getTotalPriceWithDiscount())} تومان</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div
                      style={{
                        background: 'linear-gradient(to left, #156394, #1a7bb3)',
                        color: '#ffffff',
                        padding: '24px',
                        borderRadius: '12px',
                        marginBottom: '16px'
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <span style={{ fontSize: '24px', fontWeight: 'bold' }}>جمع کل:</span>
                        <span style={{ fontSize: '30px', fontWeight: 'bold' }}>{formatPrice(getTotalPrice())} تومان</span>
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Footer */}
              <div 
                style={{
                  marginTop: '32px',
                  paddingTop: '24px',
                  textAlign: 'center',
                  color: '#6b7280',
                  fontSize: '14px',
                  borderTop: '1px solid #e5e7eb'
                }}
              >
                <p style={{ marginBottom: '8px' }}>این پیش‌فاکتور جنبه اطلاع‌رسانی دارد</p>
                <p style={{ marginBottom: '16px' }}>لطفاً برای تکمیل سفارش با واحد فروش تماس حاصل فرمایید</p>
                
                {/* Contact Numbers */}
                <div 
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(3, 1fr)',
                    gap: '16px',
                    marginBottom: '24px'
                  }}
                >
                  {/* Phone 1 */}
                  <div 
                    style={{
                      backgroundColor: '#f3f4f6',
                      border: '2px solid #156394',
                      borderRadius: '16px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px'
                    }}
                  >
                    <div 
                      style={{
                        width: '48px',
                        height: '48px',
                        background: 'linear-gradient(to bottom right, #156394, #1a7bb3)',
                        borderRadius: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto'
                      }}
                    >
                      <span style={{ fontSize: '24px' }}>📞</span>
                    </div>
                    <p style={{ fontSize: '12px', color: '#F2B524', fontWeight: '600', margin: 0 }}>تلفن دفتر مرکزی</p>
                    <p style={{ fontSize: '16px', color: '#156394', fontWeight: 'bold', margin: 0 }}>۰۲۱-۶۸۴۹۶۰۰۰</p>
                  </div>

                  {/* Phone 2 */}
                  <div 
                    style={{
                      backgroundColor: '#f3f4f6',
                      border: '2px solid #156394',
                      borderRadius: '16px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px'
                    }}
                  >
                    <div 
                      style={{
                        width: '48px',
                        height: '48px',
                        background: 'linear-gradient(to bottom right, #156394, #1a7bb3)',
                        borderRadius: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto'
                      }}
                    >
                      <span style={{ fontSize: '24px' }}>📞</span>
                    </div>
                    <p style={{ fontSize: '12px', color: '#F2B524', fontWeight: '600', margin: 0 }}>تلفن فروش</p>
                    <p style={{ fontSize: '16px', color: '#156394', fontWeight: 'bold', margin: 0 }}>۰۲۱-۶۶۱۹۳۹۷۲</p>
                  </div>

                  {/* Mobile */}
                  <div 
                    style={{
                      backgroundColor: '#f3f4f6',
                      border: '2px solid #156394',
                      borderRadius: '16px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '8px'
                    }}
                  >
                    <div 
                      style={{
                        width: '48px',
                        height: '48px',
                        background: 'linear-gradient(to bottom right, #156394, #1a7bb3)',
                        borderRadius: '12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        margin: '0 auto'
                      }}
                    >
                      <span style={{ fontSize: '24px' }}>📱</span>
                    </div>
                    <p style={{ fontSize: '12px', color: '#F2B524', fontWeight: '600', margin: 0 }}>موبایل</p>
                    <p style={{ fontSize: '16px', color: '#156394', fontWeight: 'bold', margin: 0 }}>۰۹۱۲-۹۳۶-۸۲۳۸</p>
                  </div>
                </div>

                <p style={{ color: '#156394', fontWeight: '600', margin: 0 }}>شرکت صنعت پایتخت جهان موج - تامین‌کننده تجهیزات استخر و موتورخانه</p>
              </div>
            </div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}