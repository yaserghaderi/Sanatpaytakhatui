import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, SlidersHorizontal, ChevronDown, X, Grid2X2, List,
  Plus, Star, ShoppingCart, Filter,
  Droplets, Wrench, Settings, Zap, FlaskConical, Link,
  Disc, Radio, Shirt, Waves, Factory
} from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

// ─── Types ────────────────────────────────────────────────────────────────────

interface Product {
  id: number;
  name: string;
  category: string;
  tab: string;
  price: number;
  unit: string;
  brand: string;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  sizes: { size: string; price: number }[];
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

const tabs = [
  { id: 'all', label: 'همه', icon: Factory },
  { id: 'polymer', label: 'اتصالات پلیمری', icon: Link },
  { id: 'valve', label: 'شیرآلات', icon: Droplets },
  { id: 'insulation', label: 'عایق و شیلنگ', icon: Shirt },
  { id: 'flange', label: 'لرزه‌گیر و فلنج', icon: Disc },
  { id: 'pool', label: 'استخر و جکوزی', icon: Waves },
  { id: 'pipe-acc', label: 'متعلقات لوله‌کشی', icon: Settings },
  { id: 'clamp', label: 'بست و نگه‌دارنده', icon: Radio },
  { id: 'pump', label: 'پمپ و الکتروموتور', icon: Zap },
  { id: 'tools', label: 'ابزار و تجهیزات', icon: Wrench },
  { id: 'adhesive', label: 'چسب و مواد شیمیایی', icon: FlaskConical },
];

const PRODUCTS: Product[] = [
  { id: 1, name: 'زانو PVC ۹۰ درجه', category: 'اتصالات پلیمری', tab: 'polymer', price: 28000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.7, reviews: 124, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=400&q=80', badge: 'پرفروش', sizes: [{ size: '20mm', price: 18000 }, { size: '25mm', price: 28000 }, { size: '32mm', price: 42000 }, { size: '40mm', price: 58000 }, { size: '50mm', price: 75000 }] },
  { id: 2, name: 'سه‌راه مساوی پلیمری', category: 'اتصالات پلیمری', tab: 'polymer', price: 45000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.5, reviews: 89, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=400&q=80', sizes: [{ size: '25mm', price: 35000 }, { size: '32mm', price: 45000 }, { size: '40mm', price: 65000 }, { size: '50mm', price: 88000 }] },
  { id: 3, name: 'شیر توپی برنجی', category: 'شیرآلات', tab: 'valve', price: 185000, unit: 'عدد', brand: 'بنکن', rating: 4.9, reviews: 312, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=400&q=80', badge: 'کیفیت بالا', sizes: [{ size: '1/4"', price: 120000 }, { size: '1/2"', price: 165000 }, { size: '3/4"', price: 185000 }, { size: '1"', price: 220000 }, { size: '1.5"', price: 310000 }, { size: '2"', price: 420000 }] },
  { id: 4, name: 'شیر کشویی فلنجی', category: 'شیرآلات', tab: 'valve', price: 850000, unit: 'عدد', brand: 'ولدان', rating: 4.6, reviews: 67, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=400&q=80', sizes: [{ size: 'DN50', price: 650000 }, { size: 'DN65', price: 780000 }, { size: 'DN80', price: 850000 }, { size: 'DN100', price: 1100000 }] },
  { id: 5, name: 'عایق لوله الاستومری', category: 'عایق و شیلنگ', tab: 'insulation', price: 95000, unit: 'متر', brand: 'ارا', rating: 4.4, reviews: 45, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', sizes: [{ size: '18mm×13mm', price: 68000 }, { size: '22mm×13mm', price: 82000 }, { size: '28mm×13mm', price: 95000 }, { size: '35mm×19mm', price: 125000 }] },
  { id: 6, name: 'شیلنگ فشار قوی تقویت‌شده', category: 'عایق و شیلنگ', tab: 'insulation', price: 180000, unit: 'متر', brand: 'فارآب', rating: 4.8, reviews: 198, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', badge: 'جدید', sizes: [{ size: '1/2"', price: 130000 }, { size: '3/4"', price: 160000 }, { size: '1"', price: 180000 }, { size: '1.5"', price: 240000 }] },
  { id: 7, name: 'فلنج گلودار PN16', category: 'لرزه‌گیر و فلنج', tab: 'flange', price: 320000, unit: 'عدد', brand: 'ولدان', rating: 4.7, reviews: 156, image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?w=400&q=80', sizes: [{ size: 'DN50', price: 220000 }, { size: 'DN65', price: 260000 }, { size: 'DN80', price: 320000 }, { size: 'DN100', price: 420000 }, { size: 'DN150', price: 680000 }] },
  { id: 8, name: 'لرزه‌گیر لاستیکی تکپارچه', category: 'لرزه‌گیر و فلنج', tab: 'flange', price: 480000, unit: 'عدد', brand: 'بنکن', rating: 4.5, reviews: 88, image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?w=400&q=80', badge: 'تخفیف', sizes: [{ size: 'DN50', price: 320000 }, { size: 'DN65', price: 380000 }, { size: 'DN80', price: 480000 }, { size: 'DN100', price: 620000 }] },
  { id: 9, name: 'پمپ سیرکولاتور استخر', category: 'استخر و جکوزی', tab: 'pool', price: 8500000, unit: 'دستگاه', brand: 'اطلس پول', rating: 4.9, reviews: 234, image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?w=400&q=80', badge: 'پرفروش', sizes: [{ size: '0.5HP', price: 6200000 }, { size: '0.75HP', price: 7400000 }, { size: '1HP', price: 8500000 }, { size: '1.5HP', price: 11200000 }, { size: '2HP', price: 14500000 }] },
  { id: 10, name: 'فیلتر شنی استخر', category: 'استخر و جکوزی', tab: 'pool', price: 18500000, unit: 'دستگاه', brand: 'پیمتاش', rating: 4.8, reviews: 167, image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?w=400&q=80', sizes: [{ size: '400mm', price: 14500000 }, { size: '500mm', price: 18500000 }, { size: '600mm', price: 24000000 }, { size: '750mm', price: 32000000 }] },
  { id: 11, name: 'مانیفولد توزیع پلیمری', category: 'متعلقات لوله‌کشی', tab: 'pipe-acc', price: 650000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.6, reviews: 92, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', sizes: [{ size: '3 مسیره', price: 480000 }, { size: '4 مسیره', price: 580000 }, { size: '5 مسیره', price: 650000 }, { size: '6 مسیره', price: 750000 }] },
  { id: 12, name: 'بست U شکل گالوانیزه', category: 'بست و نگه‌دارنده', tab: 'clamp', price: 12000, unit: 'عدد', brand: 'ارس', rating: 4.3, reviews: 445, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', sizes: [{ size: '20mm', price: 8000 }, { size: '25mm', price: 10000 }, { size: '32mm', price: 12000 }, { size: '40mm', price: 16000 }, { size: '50mm', price: 22000 }] },
  { id: 13, name: 'پمپ سانتریفیوژ صنعتی', category: 'پمپ و الکتروموتور', tab: 'pump', price: 24000000, unit: 'دستگاه', brand: 'ارس پمپ', rating: 4.8, reviews: 78, image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?w=400&q=80', badge: 'صنعتی', sizes: [{ size: '1HP', price: 18000000 }, { size: '2HP', price: 24000000 }, { size: '3HP', price: 32000000 }, { size: '5HP', price: 52000000 }] },
  { id: 14, name: 'آچار لوله سنگین', category: 'ابزار و تجهیزات', tab: 'tools', price: 3800000, unit: 'عدد', brand: 'ترموپلاستیک', rating: 4.7, reviews: 203, image: 'https://images.unsplash.com/photo-1761074342668-c38fc2e62e67?w=400&q=80', sizes: [{ size: '10"', price: 2800000 }, { size: '14"', price: 3800000 }, { size: '18"', price: 5200000 }, { size: '24"', price: 7800000 }] },
  { id: 15, name: 'چسب PVC فوری', category: 'چسب و مواد شیمیایی', tab: 'adhesive', price: 1400000, unit: 'عدد', brand: 'فارآب', rating: 4.6, reviews: 367, image: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?w=400&q=80', badge: 'پرفروش', sizes: [{ size: '100گرم', price: 850000 }, { size: '250گرم', price: 1200000 }, { size: '500گرم', price: 1400000 }, { size: '1کیلو', price: 2200000 }] },
  { id: 16, name: 'درزگیر سیلیکونی صنعتی', category: 'چسب و مواد شیمیایی', tab: 'adhesive', price: 280000, unit: 'عدد', brand: 'بنکن', rating: 4.5, reviews: 189, image: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?w=400&q=80', sizes: [{ size: '300ml', price: 220000 }, { size: '500ml', price: 280000 }, { size: '1000ml', price: 480000 }] },
];

const sortOptions = [
  { value: 'default', label: 'پیش‌فرض' },
  { value: 'price-asc', label: 'ارزان‌ترین' },
  { value: 'price-desc', label: 'گران‌ترین' },
  { value: 'rating', label: 'بهترین امتیاز' },
  { value: 'reviews', label: 'بیشترین نظر' },
];

// ─── Product Card ─────────────────────────────────────────────────────────────

function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [selectedIdx, setSelectedIdx] = useState(0);
  const selectedSize = product.sizes[selectedIdx];

  const handleAdd = () => {
    addToCart({
      productId: product.id,
      productName: product.name,
      productCategory: product.category,
      productImage: product.image,
      size: selectedSize.size,
      price: selectedSize.price,
    });
    toast.success(`${product.name} به پیش‌فاکتور اضافه شد`);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg hover:border-gray-200 transition-all duration-200 group flex flex-col"
    >
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-50">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
        {product.badge && (
          <span className="absolute top-3 right-3 bg-[#F2B524] text-gray-900 text-xs px-2.5 py-1 rounded-full font-bold shadow-sm">
            {product.badge}
          </span>
        )}
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1">
        <p className="text-xs text-gray-400 mb-1">{product.brand} · {product.category}</p>
        <h3 className="text-gray-800 text-sm mb-2 line-clamp-2 flex-1">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <Star size={12} className="text-[#F2B524] fill-[#F2B524]" />
          <span className="text-xs text-gray-600">{toPersianNumber(product.rating)}</span>
          <span className="text-xs text-gray-400">({toPersianNumber(product.reviews)} نظر)</span>
        </div>

        {/* Size selector */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {product.sizes.slice(0, 4).map((s, i) => (
            <button key={i} onClick={() => setSelectedIdx(i)}
              className={`px-2.5 py-1 rounded-lg text-xs transition-all ${
                selectedIdx === i
                  ? 'bg-[#156394] text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}>
              {s.size}
            </button>
          ))}
          {product.sizes.length > 4 && (
            <span className="px-2.5 py-1 rounded-lg text-xs bg-gray-50 text-gray-400">+{toPersianNumber(product.sizes.length - 4)}</span>
          )}
        </div>

        {/* Price + Add */}
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-gray-100">
          <div>
            <span className="text-[#156394] text-sm">{toPersianNumber(selectedSize.price.toLocaleString())}</span>
            <span className="text-gray-400 text-xs mr-1">تومان / {product.unit}</span>
          </div>
          <button onClick={handleAdd}
            className="flex items-center gap-1.5 px-3 py-2 bg-[#156394] text-white rounded-xl text-xs hover:bg-[#0d4a6f] transition-colors shadow-sm hover:shadow-md">
            <Plus size={13} />
            افزودن
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export function CategoryPage() {
  const [activeTab, setActiveTab] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('default');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilter, setShowFilter] = useState(false);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);

  const brands = [...new Set(PRODUCTS.map(p => p.brand))];

  const toggleBrand = (b: string) =>
    setSelectedBrands(prev => prev.includes(b) ? prev.filter(x => x !== b) : [...prev, b]);

  let filtered = PRODUCTS.filter(p => {
    const tabMatch = activeTab === 'all' || p.tab === activeTab;
    const searchMatch = !search || p.name.includes(search) || p.category.includes(search);
    const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(p.brand);
    return tabMatch && searchMatch && brandMatch;
  });

  if (sort === 'price-asc') filtered = [...filtered].sort((a, b) => a.price - b.price);
  else if (sort === 'price-desc') filtered = [...filtered].sort((a, b) => b.price - a.price);
  else if (sort === 'rating') filtered = [...filtered].sort((a, b) => b.rating - a.rating);
  else if (sort === 'reviews') filtered = [...filtered].sort((a, b) => b.reviews - a.reviews);

  const activeTabData = tabs.find(t => t.id === activeTab)!;

  return (
    <section className="pt-28 pb-16 bg-gray-50 min-h-screen" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 md:px-6">

        {/* Page Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
            <a href="/" className="hover:text-[#156394]">خانه</a>
            <span>/</span>
            <span className="text-gray-600">دسته‌بندی محصولات</span>
            {activeTab !== 'all' && <>
              <span>/</span>
              <span className="text-[#156394]">{activeTabData.label}</span>
            </>}
          </div>
          <h1 className="text-2xl text-gray-900 mb-1">
            {activeTab === 'all' ? 'همه محصولات' : activeTabData.label}
          </h1>
          <p className="text-gray-500 text-sm">{toPersianNumber(filtered.length)} محصول یافت شد</p>
        </div>

        <div className="flex gap-6">
          {/* Sidebar Filter */}
          <AnimatePresence>
            {(showFilter || window.innerWidth >= 1024) && (
              <motion.aside
                initial={{ width: 0, opacity: 0 }} animate={{ width: 240, opacity: 1 }} exit={{ width: 0, opacity: 0 }}
                className="shrink-0 hidden lg:block"
                style={{ width: 240 }}
              >
                <div className="bg-white rounded-2xl border border-gray-100 p-5 sticky top-24">
                  <h3 className="text-gray-800 mb-4 pb-3 border-b border-gray-100 flex items-center gap-2">
                    <SlidersHorizontal size={16} className="text-[#156394]" />
                    فیلترها
                  </h3>

                  {/* Brand filter */}
                  <div>
                    <p className="text-sm text-gray-600 mb-3">برند</p>
                    <div className="space-y-2">
                      {brands.map(brand => (
                        <label key={brand} className="flex items-center gap-2.5 cursor-pointer group">
                          <div onClick={() => toggleBrand(brand)}
                            className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors cursor-pointer
                              ${selectedBrands.includes(brand) ? 'bg-[#156394] border-[#156394]' : 'border-gray-300 group-hover:border-[#156394]'}`}>
                            {selectedBrands.includes(brand) && <span className="text-white text-xs">✓</span>}
                          </div>
                          <span className="text-sm text-gray-600 group-hover:text-gray-800 flex-1">{brand}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {selectedBrands.length > 0 && (
                    <button onClick={() => setSelectedBrands([])}
                      className="mt-4 w-full py-2 border border-red-200 text-red-500 rounded-xl text-sm hover:bg-red-50 transition-colors">
                      پاک کردن فیلترها
                    </button>
                  )}
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Horizontal Tabs */}
            <div className="bg-white rounded-2xl border border-gray-100 p-2 mb-4 overflow-x-auto">
              <div className="flex gap-1 min-w-max">
                {tabs.map(tab => {
                  const Icon = tab.icon;
                  const active = tab.id === activeTab;
                  return (
                    <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm transition-all whitespace-nowrap
                        ${active ? 'bg-[#156394] text-white shadow-sm' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'}`}>
                      <Icon size={14} />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Toolbar */}
            <div className="flex items-center justify-between mb-4 gap-3">
              {/* Search */}
              <div className="relative flex-1 max-w-xs">
                <input type="text" placeholder="جستجو در محصولات..." value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full pr-9 pl-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20 focus:border-[#156394]/30" />
                <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              </div>

              <div className="flex items-center gap-2">
                {/* Mobile filter button */}
                <button onClick={() => setShowFilter(v => !v)} className="lg:hidden flex items-center gap-2 px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm text-gray-600">
                  <Filter size={14} />
                  فیلتر
                </button>

                {/* Sort */}
                <div className="relative">
                  <select value={sort} onChange={e => setSort(e.target.value)}
                    className="appearance-none pr-3 pl-8 py-2.5 bg-white border border-gray-200 rounded-xl text-sm text-gray-600 focus:outline-none focus:ring-2 focus:ring-[#156394]/20 cursor-pointer">
                    {sortOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                  <ChevronDown size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                </div>

                {/* View toggle */}
                <div className="flex bg-white border border-gray-200 rounded-xl overflow-hidden">
                  <button onClick={() => setViewMode('grid')}
                    className={`p-2.5 transition-colors ${viewMode === 'grid' ? 'bg-[#156394] text-white' : 'text-gray-500 hover:bg-gray-50'}`}>
                    <Grid2X2 size={15} />
                  </button>
                  <button onClick={() => setViewMode('list')}
                    className={`p-2.5 transition-colors ${viewMode === 'list' ? 'bg-[#156394] text-white' : 'text-gray-500 hover:bg-gray-50'}`}>
                    <List size={15} />
                  </button>
                </div>
              </div>
            </div>

            {/* Active filters */}
            {selectedBrands.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-4">
                {selectedBrands.map(b => (
                  <span key={b} className="flex items-center gap-1.5 px-3 py-1.5 bg-[#156394]/10 text-[#156394] rounded-full text-xs">
                    {b}
                    <button onClick={() => toggleBrand(b)}><X size={11} /></button>
                  </span>
                ))}
              </div>
            )}

            {/* Products Grid */}
            {filtered.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
                <ShoppingCart size={40} className="mx-auto mb-3 text-gray-300" />
                <p className="text-gray-500">محصولی یافت نشد</p>
              </div>
            ) : (
              <motion.div layout
                className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-2 md:grid-cols-3 xl:grid-cols-4' : 'grid-cols-1'}`}>
                {filtered.map((product, i) => (
                  <motion.div key={product.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}>
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
