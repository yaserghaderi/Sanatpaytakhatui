import { motion } from 'motion/react';
import { ShoppingCart, FileCheck, Headphones } from 'lucide-react';

const orderSteps = [
  {
    icon: ShoppingCart,
    step: '۱',
    title: 'ساخت پیش‌فاکتور آنلاین',
    description: 'افزودن محصولات به لیست خرید',
    gradient: 'from-[#156394] to-[#0d4a6f]'
  },
  {
    icon: FileCheck,
    step: '۲',
    title: 'ثبت درخواست',
    description: 'دریافت قیمت نهایی',
    gradient: 'from-[#F2B524] to-[#d89a0f]'
  },
  {
    icon: Headphones,
    step: '۳',
    title: 'هماهنگی کارشناس فروش',
    description: 'پرداخت و ارسال سفارش',
    gradient: 'from-[#156394] to-[#0d4a6f]'
  }
];

export function Features() {
  return (
    <section className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-4">مراحل ثبت سفارش</h2>
          <p className="text-xl text-gray-600">سفارش خود را در ۳ مرحله ساده تکمیل کنید</p>
        </motion.div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {orderSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15, duration: 0.6 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="group relative bg-white rounded-3xl p-8 border-2 border-gray-200/50 hover:border-[#F2B524] hover:shadow-2xl transition-all duration-300 text-center overflow-hidden"
              >
                {/* Gradient Background on Hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${step.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300 rounded-3xl`} />
                
                {/* Step Number Badge */}
                <div className="absolute top-6 right-6 w-10 h-10 bg-gradient-to-br from-[#F2B524] to-[#d89a0f] rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-white text-lg">{step.step}</span>
                </div>
                
                <div className="relative mt-4">
                  {/* Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-br ${step.gradient} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  {/* Title */}
                  <h3 className="text-gray-900 mb-3 text-xl">{step.title}</h3>
                  
                  {/* Description */}
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>

                {/* Arrow Connector (except last item) */}
                {index < orderSteps.length - 1 && (
                  <div className="hidden md:block absolute left-full top-1/2 -translate-y-1/2 translate-x-4 z-10">
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none" className="text-gray-300">
                      <path d="M8 16H24M24 16L18 10M24 16L18 22" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}