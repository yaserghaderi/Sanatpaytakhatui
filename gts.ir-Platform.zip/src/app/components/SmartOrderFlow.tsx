import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Upload, Camera, CheckCircle2, FileText, Loader2,
  Plus, Minus, Trash2, Edit3, ChevronLeft, ChevronRight,
  ShoppingCart, Sparkles, AlertCircle, Phone, User, MapPin, X, Download
} from 'lucide-react';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (d) => persianDigits[parseInt(d)]);
};

const formatPrice = (n: number) =>
  new Intl.NumberFormat('fa-IR').format(n);

const toJalali = (date: Date) => {
  const g2j = (gy: number, gm: number, gd: number) => {
    let jy = gy - 1600, jm = 0, jd = 0;
    let g_d_no = 365 * gy + Math.floor((gy + 3) / 4) - Math.floor((gy + 99) / 100) + Math.floor((gy + 399) / 400);
    for (let i = 0; i < gm - 1; i++) g_d_no += [31,28+((gy%4===0&&gy%100!==0)||gy%400===0?1:0),31,30,31,30,31,31,30,31,30,31][i];
    g_d_no += gd - 1;
    let j_d_no = g_d_no - 79;
    let j_np = Math.floor(j_d_no / 12053); j_d_no %= 12053;
    jy = 979 + 33 * j_np + 4 * Math.floor(j_d_no / 1461);
    j_d_no %= 1461;
    if (j_d_no >= 366) { jy += Math.floor((j_d_no - 1) / 365); j_d_no = (j_d_no - 1) % 365; }
    for (let i = 0; i < 11 && j_d_no >= [31,31,31,31,31,31,30,30,30,30,30][i]; i++) { j_d_no -= [31,31,31,31,31,31,30,30,30,30,30][i]; jm++; }
    jd = j_d_no + 1;
    return { year: jy, month: jm + 1, day: jd };
  };
  return g2j(date.getFullYear(), date.getMonth() + 1, date.getDate());
};

const persianMonths = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];

// ─── Types ────────────────────────────────────────────────────────────────────

export interface DetectedItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  category: string;
}

interface OrderForm {
  customerName: string;
  phone: string;
  address: string;
  note: string;
}

// ─── Mock AI Parser ───────────────────────────────────────────────────────────

const MOCK_PRODUCTS: Record<string, { unitPrice: number; unit: string; category: string }> = {
  'لوله پوش‌فیت ۱۱۰': { unitPrice: 185000, unit: 'متر', category: 'لوله و اتصالات' },
  'اتصال زانویی ۹۰ درجه': { unitPrice: 42000, unit: 'عدد', category: 'لوله و اتصالات' },
  'شیر توپی ½"': { unitPrice: 98000, unit: 'عدد', category: 'شیرآلات' },
  'پمپ آب ۱ اسب': { unitPrice: 4200000, unit: 'دستگاه', category: 'پمپ' },
  'رابط سه‌راهه ۲۵': { unitPrice: 56000, unit: 'عدد', category: 'لوله و اتصالات' },
  'کلر استخر گرانول': { unitPrice: 320000, unit: 'کیلوگرم', category: 'شیمیایی' },
  'فیلتر شنی ۵۰۰mm': { unitPrice: 8500000, unit: 'دستگاه', category: 'تصفیه' },
  'درپوش انتهایی ۱۱۰': { unitPrice: 18000, unit: 'عدد', category: 'لوله و اتصالات' },
  'واشر لاستیکی': { unitPrice: 5000, unit: 'عدد', category: 'یراق‌آلات' },
  'چسب PVC': { unitPrice: 45000, unit: 'عدد', category: 'چسب' },
  'شیر فشارشکن': { unitPrice: 650000, unit: 'عدد', category: 'شیرآلات' },
  'لوله PVC ۶۳mm': { unitPrice: 95000, unit: 'متر', category: 'لوله و اتصالات' },
};

const parseShoppingList = async (_file: File): Promise<DetectedItem[]> => {
  await new Promise(r => setTimeout(r, 2800));
  const allKeys = Object.keys(MOCK_PRODUCTS);
  const count = 4 + Math.floor(Math.random() * 4);
  const shuffled = [...allKeys].sort(() => Math.random() - 0.5).slice(0, count);
  return shuffled.map((name, i) => {
    const p = MOCK_PRODUCTS[name];
    return { id: `item-${i}`, name, quantity: 1 + Math.floor(Math.random() * 8), unit: p.unit, unitPrice: p.unitPrice, category: p.category };
  });
};

// ─── Step Indicator ───────────────────────────────────────────────────────────

const STEPS = [
  { label: 'آپلود تصویر', icon: Camera },
  { label: 'بررسی آیتم‌ها', icon: Edit3 },
  { label: 'پیش‌فاکتور', icon: FileText },
];

function StepIndicator({ current }: { current: number }) {
  return (
    <div className="flex items-center justify-center gap-0 mb-6">
      {STEPS.map((step, i) => {
        const Icon = step.icon;
        const done = i < current;
        const active = i === current;
        return (
          <div key={i} className="flex items-center">
            <div className="flex flex-col items-center gap-1">
              <motion.div
                animate={{ scale: active ? 1.1 : 1 }}
                className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300
                  ${done ? 'bg-[#156394] border-[#156394] text-white' : ''}
                  ${active ? 'bg-white border-[#156394] text-[#156394] shadow-md' : ''}
                  ${!done && !active ? 'bg-gray-100 border-gray-300 text-gray-400' : ''}
                `}
              >
                {done ? <CheckCircle2 size={18} /> : <Icon size={16} />}
              </motion.div>
              <span className={`text-xs whitespace-nowrap ${active ? 'text-[#156394]' : done ? 'text-[#156394]/60' : 'text-gray-400'}`}>
                {step.label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className={`w-12 h-0.5 mx-1 mb-4 transition-colors duration-500 ${i < current ? 'bg-[#156394]' : 'bg-gray-200'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

// ─── Step 1: Upload ───────────────────────────────────────────────────────────

function UploadStep({ onComplete }: { onComplete: (file: File, items: DetectedItem[]) => void }) {
  const [dragging, setDragging] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((f: File) => {
    if (!f.type.startsWith('image/')) { toast.error('لطفاً یک فایل تصویری انتخاب کنید'); return; }
    setFile(f);
    setPreview(URL.createObjectURL(f));
  }, []);

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    setLoadingMsg('در حال ارسال تصویر...');
    await new Promise(r => setTimeout(r, 800));
    setLoadingMsg('هوش مصنوعی در حال خواندن لیست...');
    await new Promise(r => setTimeout(r, 1000));
    setLoadingMsg('شناسایی محصولات...');
    const items = await parseShoppingList(file);
    setLoading(false);
    onComplete(file, items);
    toast.success(`${items.length} آیتم شناسایی شد!`);
  };

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
      <div className="text-center mb-5">
        <div className="inline-flex items-center gap-2 bg-blue-50 text-[#156394] px-4 py-1.5 rounded-full text-sm mb-3">
          <Sparkles size={14} />
          <span>هوش مصنوعی لیست شما را می‌خواند</span>
        </div>
        <h3 className="text-lg text-gray-800 mb-1">تصویر لیست خرید خود را آپلود کنید</h3>
        <p className="text-gray-500 text-sm">دست‌نویس، تایپی یا هر فرمتی قابل قبول است</p>
      </div>

      {!preview ? (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if (f) handleFile(f); }}
          onClick={() => inputRef.current?.click()}
          className={`border-2 border-dashed rounded-2xl p-8 flex flex-col items-center gap-4 cursor-pointer transition-all duration-200
            ${dragging ? 'border-[#156394] bg-blue-50 scale-[1.01]' : 'border-gray-300 bg-gray-50 hover:border-[#156394] hover:bg-blue-50/40'}`}
        >
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#156394] to-[#1a7bb3] flex items-center justify-center shadow-lg">
            <Upload size={24} className="text-white" />
          </div>
          <div className="text-center">
            <p className="text-gray-700 mb-1">عکس لیست خرید را اینجا بکشید</p>
            <p className="text-gray-400 text-sm">یا <span className="text-[#156394] underline">انتخاب از دستگاه</span></p>
          </div>
          <div className="flex gap-2 text-xs text-gray-400">
            {['JPG', 'PNG', 'HEIC', 'PDF'].map(f => (
              <span key={f} className="bg-white border border-gray-200 px-3 py-1 rounded-full">{f}</span>
            ))}
          </div>
        </div>
      ) : (
        <div className="relative rounded-2xl overflow-hidden border border-gray-200 shadow-md">
          <img src={preview} alt="لیست خرید" className="w-full max-h-56 object-contain bg-gray-50" />
          <button onClick={() => { setPreview(null); setFile(null); }} className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm rounded-full p-1.5 shadow hover:bg-red-50 text-gray-500 hover:text-red-500 transition-colors">
            <X size={14} />
          </button>
        </div>
      )}

      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={e => e.target.files?.[0] && handleFile(e.target.files[0])} />

      <div className="mt-4 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3 flex gap-3">
        <Camera size={16} className="text-amber-500 mt-0.5 shrink-0" />
        <p className="text-amber-700 text-sm">نکته: برای نتیجه بهتر، عکس را در نور کافی و با دوربین اصلی بگیرید</p>
      </div>

      <button
        onClick={handleAnalyze}
        disabled={!file || loading}
        className={`mt-5 w-full py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all duration-200
          ${file && !loading ? 'bg-gradient-to-l from-[#156394] to-[#1a7bb3] text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5' : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
      >
        {loading ? <><Loader2 size={18} className="animate-spin" /><span>{loadingMsg}</span></> : <><Sparkles size={18} /><span>تحلیل با هوش مصنوعی</span></>}
      </button>
    </motion.div>
  );
}

// ─── Step 2: Review ───────────────────────────────────────────────────────────

function ReviewStep({ items, previewUrl, onUpdate, onNext, onBack }: {
  items: DetectedItem[]; previewUrl: string;
  onUpdate: (items: DetectedItem[]) => void; onNext: () => void; onBack: () => void;
}) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [newItemName, setNewItemName] = useState('');
  const [showAdd, setShowAdd] = useState(false);

  const updateQty = (id: string, delta: number) =>
    onUpdate(items.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));

  const addItem = () => {
    if (!newItemName.trim()) return;
    onUpdate([...items, { id: `item-${Date.now()}`, name: newItemName.trim(), quantity: 1, unit: 'عدد', unitPrice: 0, category: 'سایر' }]);
    setNewItemName(''); setShowAdd(false); toast.success('آیتم اضافه شد');
  };

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
      <div className="flex items-start gap-3 mb-4">
        <div className="flex-1">
          <h3 className="text-lg text-gray-800 mb-0.5">آیتم‌های شناسایی‌شده</h3>
          <p className="text-gray-500 text-sm">بررسی و در صورت نیاز ویرایش کنید</p>
        </div>
        {previewUrl && <img src={previewUrl} alt="" className="w-14 h-14 rounded-xl object-cover border border-gray-200 shadow-sm" />}
      </div>

      <div className="flex items-center gap-2 bg-green-50 border border-green-200 rounded-xl px-3 py-2 mb-4">
        <CheckCircle2 size={15} className="text-green-500" />
        <span className="text-green-700 text-sm">{items.length} آیتم شناسایی شد — لطفاً بررسی کنید</span>
      </div>

      <div className="space-y-2 max-h-60 overflow-y-auto pl-1">
        {items.map((item, i) => (
          <motion.div key={item.id} layout initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
            className="bg-white border border-gray-200 rounded-xl p-3 flex items-center gap-2 hover:border-[#156394]/30 hover:shadow-sm transition-all">
            <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center text-[#156394] shrink-0">
              <ShoppingCart size={13} />
            </div>
            <div className="flex-1 min-w-0">
              {editingId === item.id ? (
                <div className="flex gap-2">
                  <input autoFocus value={editName} onChange={e => setEditName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { onUpdate(items.map(it => it.id === item.id ? { ...it, name: editName } : it)); setEditingId(null); } }}
                    className="flex-1 border border-blue-300 rounded-lg px-2 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/30" />
                  <button onClick={() => { onUpdate(items.map(it => it.id === item.id ? { ...it, name: editName } : it)); setEditingId(null); }} className="text-[#156394] text-xs px-2 py-1 bg-blue-50 rounded-lg">ذخیره</button>
                </div>
              ) : (
                <>
                  <p className="text-sm text-gray-800 truncate">{item.name}</p>
                  <p className="text-xs text-gray-400">{item.category}</p>
                </>
              )}
            </div>
            <div className="flex items-center gap-0.5 bg-gray-50 rounded-lg p-0.5">
              <button onClick={() => updateQty(item.id, -1)} className="w-6 h-6 rounded-md flex items-center justify-center text-gray-500 hover:bg-white hover:text-[#156394] transition-colors"><Minus size={12} /></button>
              <span className="w-7 text-center text-sm text-gray-700">{item.quantity}</span>
              <button onClick={() => updateQty(item.id, 1)} className="w-6 h-6 rounded-md flex items-center justify-center text-gray-500 hover:bg-white hover:text-[#156394] transition-colors"><Plus size={12} /></button>
            </div>
            <span className="text-xs text-gray-400 w-7 text-center">{item.unit}</span>
            <div className="flex gap-0.5">
              <button onClick={() => { setEditingId(item.id); setEditName(item.name); }} className="p-1.5 rounded-lg text-gray-400 hover:text-[#156394] hover:bg-blue-50 transition-colors"><Edit3 size={12} /></button>
              <button onClick={() => { onUpdate(items.filter(it => it.id !== item.id)); toast.success('آیتم حذف شد'); }} className="p-1.5 rounded-lg text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"><Trash2 size={12} /></button>
            </div>
          </motion.div>
        ))}
      </div>

      {showAdd ? (
        <div className="mt-3 flex gap-2">
          <input autoFocus value={newItemName} onChange={e => setNewItemName(e.target.value)} onKeyDown={e => e.key === 'Enter' && addItem()}
            placeholder="نام محصول..." className="flex-1 border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/30" />
          <button onClick={addItem} className="px-4 py-2 bg-[#156394] text-white rounded-xl text-sm hover:bg-[#0d4a6f]">افزودن</button>
          <button onClick={() => setShowAdd(false)} className="px-3 py-2 text-gray-500 hover:text-red-500"><X size={15} /></button>
        </div>
      ) : (
        <button onClick={() => setShowAdd(true)}
          className="mt-3 w-full border-2 border-dashed border-gray-200 rounded-xl py-2.5 text-sm text-gray-400 hover:border-[#156394]/40 hover:text-[#156394] flex items-center justify-center gap-2 transition-colors">
          <Plus size={15} /> افزودن آیتم جدید
        </button>
      )}

      {items.length === 0 && (
        <div className="text-center py-5 text-gray-400"><AlertCircle size={28} className="mx-auto mb-2 opacity-50" /><p className="text-sm">هیچ آیتمی باقی نمانده</p></div>
      )}

      <div className="flex gap-3 mt-5">
        <button onClick={onBack} className="flex items-center gap-2 px-4 py-3 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 transition-colors">
          <ChevronRight size={15} /> بازگشت
        </button>
        <button onClick={onNext} disabled={items.length === 0}
          className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-l from-[#156394] to-[#1a7bb3] text-white py-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-40 disabled:cursor-not-allowed">
          ساخت پیش‌فاکتور <ChevronLeft size={15} />
        </button>
      </div>
    </motion.div>
  );
}

// ─── Step 3: Quote ────────────────────────────────────────────────────────────

function QuoteStep({ items, onBack, onReset }: { items: DetectedItem[]; onBack: () => void; onReset: () => void; }) {
  const [form, setForm] = useState<OrderForm>({ customerName: '', phone: '', address: '', note: '' });
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [downloadingPDF, setDownloadingPDF] = useState(false);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const subtotal = items.reduce((sum, i) => sum + i.unitPrice * i.quantity, 0);
  const tax = Math.round(subtotal * 0.09);
  const total = subtotal + tax;

  const currentDate = new Date();
  const jalali = toJalali(currentDate);
  const persianDate = `${toPersianNumber(jalali.day)} ${persianMonths[jalali.month - 1]} ${toPersianNumber(jalali.year)}`;
  const invoiceNumber = `AI-${Date.now().toString().slice(-6)}`;

  const handleSubmit = async () => {
    if (!form.customerName || !form.phone) { toast.error('نام و شماره تماس الزامی است'); return; }
    setSubmitting(true);
    await new Promise(r => setTimeout(r, 1500));
    setSubmitting(false);
    setSubmitted(true);
    toast.success('پیش‌فاکتور ثبت شد!');
  };

  const downloadPDF = async () => {
    if (!invoiceRef.current) return;
    setDownloadingPDF(true);
    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2, useCORS: true, allowTaint: true, logging: false, backgroundColor: '#ffffff',
        onclone: (clonedDoc) => {
          clonedDoc.querySelectorAll('*').forEach(el => {
            const e = el as HTMLElement;
            const cs = window.getComputedStyle(e);
            if (cs.backgroundColor?.includes('oklch')) e.style.backgroundColor = '#ffffff';
            if (cs.color?.includes('oklch')) e.style.color = '#000000';
            if (cs.borderColor?.includes('oklch')) e.style.borderColor = '#e5e7eb';
          });
        }
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const imgWidth = 210, pdfHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight, position = 0;
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
      while (heightLeft > 0) { position = heightLeft - imgHeight; pdf.addPage(); pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight); heightLeft -= pdfHeight; }
      pdf.save(`AI-PishFactor-${toPersianNumber(jalali.year)}-${toPersianNumber(jalali.month)}-${toPersianNumber(jalali.day)}.pdf`);
      toast.success('پیش‌فاکتور دانلود شد');
    } catch (e) {
      toast.error('خطا در دانلود. دوباره تلاش کنید.');
    } finally {
      setDownloadingPDF(false);
    }
  };

  if (submitted) {
    return (
      <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-4">
        <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', delay: 0.2 }}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-green-200">
          <CheckCircle2 size={30} className="text-white" />
        </motion.div>
        <h3 className="text-lg text-gray-800 mb-1">پیش‌فاکتور ثبت شد!</h3>
        <p className="text-gray-500 text-sm mb-4">کارشناسان ما به زودی با شما تماس می‌گیرند</p>

        <div className="bg-gradient-to-l from-[#156394]/10 to-[#1a7bb3]/10 border border-[#156394]/20 rounded-xl p-4 mb-5 text-right">
          <p className="text-sm text-gray-500 mb-1">مبلغ کل تقریبی</p>
          <p className="text-2xl text-[#156394]">{formatPrice(total)} تومان</p>
          <p className="text-xs text-gray-400 mt-1">شامل ۹٪ مالیات بر ارزش افزوده</p>
        </div>

        <div className="grid grid-cols-3 gap-2 mb-5">
          <button onClick={downloadPDF} disabled={downloadingPDF}
            className="col-span-3 flex items-center justify-center gap-2 bg-gradient-to-l from-[#156394] to-[#1a7bb3] text-white py-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-60">
            {downloadingPDF ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />}
            {downloadingPDF ? 'در حال آماده‌سازی...' : 'دانلود پیش‌فاکتور PDF'}
          </button>
          <button onClick={onReset} className="col-span-2 py-2.5 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 text-sm">سفارش جدید</button>
          <a href="tel:+98" className="py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm flex items-center justify-center gap-1">
            <Phone size={14} /> تماس
          </a>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}>
      <h3 className="text-lg text-gray-800 mb-1">پیش‌فاکتور سفارش</h3>
      <p className="text-gray-500 text-sm mb-4">اطلاعات تماس را کامل کنید</p>

      {/* Item summary */}
      <div className="bg-gray-50 rounded-xl p-3 mb-4 max-h-40 overflow-y-auto space-y-1.5">
        {items.map(item => (
          <div key={item.id} className="flex items-center justify-between text-sm">
            <span className="text-gray-700 flex-1 truncate">{item.name}</span>
            <span className="text-gray-400 mx-2 shrink-0">{item.quantity} {item.unit}</span>
            <span className="text-gray-600 shrink-0 text-xs">
              {item.unitPrice > 0 ? `${formatPrice(item.unitPrice * item.quantity)} ت` : <span className="text-amber-500">استعلام</span>}
            </span>
          </div>
        ))}
        <div className="border-t border-gray-200 pt-2 space-y-1">
          <div className="flex justify-between text-xs text-gray-400"><span>جمع کل</span><span>{formatPrice(subtotal)} تومان</span></div>
          <div className="flex justify-between text-xs text-gray-400"><span>مالیات ۹٪</span><span>{formatPrice(tax)} تومان</span></div>
          <div className="flex justify-between text-sm text-[#156394]"><span>مبلغ نهایی</span><span>{formatPrice(total)} تومان</span></div>
        </div>
      </div>

      <div className="space-y-3">
        {[
          { icon: User, value: form.customerName, key: 'customerName', placeholder: 'نام و نام خانوادگی *', type: 'text' },
          { icon: Phone, value: form.phone, key: 'phone', placeholder: 'شماره تماس *', type: 'tel' },
          { icon: MapPin, value: form.address, key: 'address', placeholder: 'آدرس (اختیاری)', type: 'text' },
        ].map(({ icon: Icon, value, key, placeholder, type }) => (
          <div key={key} className="relative">
            <Icon size={14} className="absolute top-3.5 right-3 text-gray-400" />
            <input value={value} type={type} placeholder={placeholder} dir={key === 'phone' ? 'ltr' : 'rtl'}
              onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
              className="w-full border border-gray-200 rounded-xl pr-8 pl-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/30 bg-white text-right" />
          </div>
        ))}
        <textarea value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} placeholder="توضیحات اضافه... (اختیاری)" rows={2}
          className="w-full border border-gray-200 rounded-xl px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/30 bg-white resize-none" />
      </div>

      <div className="flex gap-3 mt-5">
        <button onClick={onBack} className="flex items-center gap-2 px-4 py-3 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 transition-colors">
          <ChevronRight size={15} /> بازگشت
        </button>
        <button onClick={handleSubmit} disabled={submitting}
          className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-l from-[#156394] to-[#1a7bb3] text-white py-3 rounded-xl hover:shadow-lg transition-all disabled:opacity-60">
          {submitting ? <Loader2 size={16} className="animate-spin" /> : <FileText size={16} />}
          {submitting ? 'در حال ثبت...' : 'ثبت و دریافت پیش‌فاکتور'}
        </button>
      </div>

      {/* Hidden invoice template for PDF - same style as CartDrawer */}
      <div style={{ position: 'fixed', left: '-9999px', top: 0, pointerEvents: 'none' }}>
        <div ref={invoiceRef} style={{ fontFamily: 'IRANSans, Tahoma, sans-serif', direction: 'rtl', backgroundColor: '#ffffff', padding: '48px', width: '794px' }}>
          <div style={{ background: 'linear-gradient(to left, #156394, #1a7bb3)', color: '#ffffff', padding: '32px', borderRadius: '16px', marginBottom: '32px' }}>
            <h1 style={{ fontSize: '32px', fontWeight: 'bold', margin: 0, marginBottom: '8px' }}>پیش‌فاکتور هوشمند</h1>
            <p style={{ fontSize: '18px', opacity: 0.9, margin: 0 }}>شرکت صنعت پایتخت جهان موج</p>
          </div>
          <div style={{ backgroundColor: '#f3f4f6', padding: '20px', borderRadius: '12px', marginBottom: '28px', display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: '16px' }}>
            <div><p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>شماره فاکتور</p><p style={{ fontSize: '16px', color: '#156394', fontWeight: '600', margin: 0 }}>{invoiceNumber}</p></div>
            <div><p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>تاریخ صدور</p><p style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>{persianDate}</p></div>
            <div><p style={{ fontSize: '12px', color: '#6b7280', marginBottom: '4px' }}>مشتری</p><p style={{ fontSize: '16px', fontWeight: '600', margin: 0 }}>{form.customerName || 'ثبت نشده'}</p></div>
          </div>
          {form.phone && (
            <div style={{ backgroundColor: '#f9fafb', padding: '16px', borderRadius: '12px', marginBottom: '28px' }}>
              <p style={{ fontSize: '14px', color: '#6b7280', marginBottom: '4px' }}>شماره تماس: <span style={{ color: '#156394', fontWeight: '600' }}>{form.phone}</span></p>
              {form.address && <p style={{ fontSize: '14px', color: '#6b7280', margin: 0 }}>آدرس: {form.address}</p>}
            </div>
          )}
          <div style={{ marginBottom: '28px' }}>
            <div style={{ backgroundColor: '#156394', color: '#fff', padding: '14px 16px', borderRadius: '12px 12px 0 0', display: 'grid', gridTemplateColumns: '50px 1fr 80px 60px 140px', gap: '12px', textAlign: 'center', fontWeight: '600', fontSize: '14px' }}>
              <div>ردیف</div><div style={{ textAlign: 'right' }}>نام محصول</div><div>واحد</div><div>تعداد</div><div>قیمت کل</div>
            </div>
            {items.map((item, idx) => (
              <div key={item.id} style={{ display: 'grid', gridTemplateColumns: '50px 1fr 80px 60px 140px', gap: '12px', padding: '14px 16px', textAlign: 'center', borderBottom: '1px solid #e5e7eb', backgroundColor: idx % 2 === 0 ? '#ffffff' : '#f9fafb', alignItems: 'center', fontSize: '14px' }}>
                <div style={{ color: '#156394', fontWeight: '600' }}>{toPersianNumber(idx + 1)}</div>
                <div style={{ textAlign: 'right' }}>{item.name}</div>
                <div>{item.unit}</div>
                <div style={{ fontWeight: '600' }}>{toPersianNumber(item.quantity)}</div>
                <div style={{ color: item.unitPrice > 0 ? '#156394' : '#d97706', fontWeight: '600' }}>
                  {item.unitPrice > 0 ? `${formatPrice(item.unitPrice * item.quantity)} ت` : 'استعلام'}
                </div>
              </div>
            ))}
          </div>
          <div style={{ background: 'linear-gradient(to left, #156394, #1a7bb3)', color: '#fff', padding: '24px', borderRadius: '12px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px', fontSize: '16px' }}>
              <span>جمع کل:</span><span>{formatPrice(subtotal)} تومان</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px', fontSize: '16px', opacity: 0.85 }}>
              <span>مالیات ۹٪:</span><span>{formatPrice(tax)} تومان</span>
            </div>
            <div style={{ borderTop: '2px solid rgba(255,255,255,0.3)', paddingTop: '16px', display: 'flex', justifyContent: 'space-between', fontSize: '24px', fontWeight: 'bold' }}>
              <span>قابل پرداخت:</span><span>{formatPrice(total)} تومان</span>
            </div>
          </div>
          {form.note && <div style={{ marginTop: '20px', padding: '16px', backgroundColor: '#fffbeb', borderRadius: '12px', border: '1px solid #fde68a' }}><p style={{ fontSize: '14px', color: '#92400e', margin: 0 }}>توضیحات: {form.note}</p></div>}
          <div style={{ marginTop: '32px', textAlign: 'center', color: '#9ca3af', fontSize: '12px' }}>
            <p>این پیش‌فاکتور توسط سیستم هوش مصنوعی صنعت پایتخت جهان موج صادر شده است</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// ─── Main Export ──────────────────────────────────────────────────────────────

export function SmartOrderFlow({ onClose }: { onClose?: () => void }) {
  const [step, setStep] = useState(0);
  const [previewUrl, setPreviewUrl] = useState('');
  const [items, setItems] = useState<DetectedItem[]>([]);

  const handleUploadComplete = (file: File, detected: DetectedItem[]) => {
    setPreviewUrl(URL.createObjectURL(file));
    setItems(detected);
    setStep(1);
  };

  const reset = () => { setStep(0); setPreviewUrl(''); setItems([]); };

  return (
    <div>
      <StepIndicator current={step} />
      <AnimatePresence mode="wait">
        {step === 0 && <UploadStep key="upload" onComplete={handleUploadComplete} />}
        {step === 1 && <ReviewStep key="review" items={items} previewUrl={previewUrl} onUpdate={setItems} onNext={() => setStep(2)} onBack={() => setStep(0)} />}
        {step === 2 && <QuoteStep key="quote" items={items} onBack={() => setStep(1)} onReset={reset} />}
      </AnimatePresence>

      <div className="flex justify-center gap-4 mt-5 pt-4 border-t border-gray-100 text-xs text-gray-400">
        <span className="flex items-center gap-1"><CheckCircle2 size={11} className="text-green-400" /> رمزنگاری شده</span>
        <span className="flex items-center gap-1"><CheckCircle2 size={11} className="text-green-400" /> بدون ثبت‌نام</span>
        <span className="flex items-center gap-1"><CheckCircle2 size={11} className="text-green-400" /> پاسخ سریع</span>
      </div>
    </div>
  );
}
