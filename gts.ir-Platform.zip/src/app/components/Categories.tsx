import { motion } from 'motion/react';
import { ArrowLeft } from 'lucide-react';

const categories = [
  {
    name: 'لوله و اتصالات',
    description: 'انواع لوله‌های صنعتی',
    image: 'https://images.unsplash.com/photo-1600065621653-2f1de87d0f43?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcGlwZXMlMjBmaXR0aW5nc3xlbnwxfHx8fDE3NjYyNDM3MDN8MA&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-blue-500/90 via-cyan-500/90 to-blue-600/90',
    items: '۵۰۰+'
  },
  {
    name: 'شیرآلات',
    description: 'راهکارهای حرفه‌ای شیرآلات',
    image: 'https://images.unsplash.com/photo-1738918897772-0ba101be25c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwdmFsdmVzJTIwcGx1bWJpbmd8ZW58MXx8fHwxNzY2MzI5MDU1fDA&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-orange-500/90 via-amber-500/90 to-yellow-500/90',
    items: '۳۰۰+'
  },
  {
    name: 'فلنج و متعلقات',
    description: 'فلنج‌ها و قطعات با کیفیت',
    image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmxhbmdlc3xlbnwxfHx8fDE3NjYzMjkwNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-slate-600/90 via-gray-600/90 to-zinc-700/90',
    items: '۲۵۰+'
  },
  {
    name: 'استخر و جکوزی',
    description: 'همه چیز برای سیستم استخر',
    image: 'https://images.unsplash.com/photo-1749704647688-a5ee71ac578c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwb29sJTIwamFjdXp6aXxlbnwxfHx8fDE3NjYzMjgwMjd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-sky-500/90 via-blue-500/90 to-indigo-600/90',
    items: '۴۰۰+'
  },
  {
    name: 'چسب',
    description: 'چسب‌های صنعتی',
    image: 'https://images.unsplash.com/photo-1766302524567-36ec1759fef3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2ltbWluZyUyMHBvb2wlMjBlcXVpcG1lbnR8ZW58MXx8fHwxNzY2MzI4MDI3fDA&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-rose-500/90 via-pink-500/90 to-fuchsia-600/90',
    items: '۱۰۰+'
  },
  {
    name: 'ابزار لوله‌کشی',
    description: 'ابزار و تجهیزات حرفه‌ای',
    image: 'https://images.unsplash.com/photo-1668874184010-87aa286683dd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbHVtYmluZyUyMHRvb2xzfGVufDF8fHx8MTc2NjMyODAyN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    gradient: 'from-emerald-500/90 via-green-500/90 to-teal-600/90',
    items: '۲۰۰+'
  }
];

export function Categories() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block bg-gradient-to-r from-[#156394]/10 to-[#F2B524]/10 border border-[#156394]/20 rounded-full px-6 py-2 mb-6"
          >
            <span className="text-gray-700">دسته‌بندی محصولات</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl mb-4"
          >
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              مجموعه محصولات ما
            </span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 max-w-2xl mx-auto"
          >
            دقیقاً آنچه نیاز دارید را از مجموعه گسترده ما پیدا کنید
          </motion.p>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <motion.div
              key={category.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              whileHover={{ y: -8, transition: { duration: 0.3 } }}
              className="group relative overflow-hidden rounded-[2.5rem] shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer h-[400px]"
            >
              {/* Background Image */}
              <div className="absolute inset-0">
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${category.gradient} group-hover:opacity-95 transition-opacity duration-500`} />
              </div>

              {/* Content */}
              <div className="relative h-full flex flex-col justify-end p-8 text-white">
                <motion.div
                  className="transform transition-all duration-500"
                  whileHover={{ y: -4 }}
                >
                  <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-md border border-white/30 rounded-full px-4 py-2 mb-4">
                    <span className="text-sm">{category.items} محصول</span>
                  </div>
                  
                  <h3 className="text-3xl mb-3">
                    {category.name}
                  </h3>
                  
                  <p className="text-white/90 mb-6 text-lg">{category.description}</p>
                  
                  <div className="flex items-center gap-2 text-white group-hover:gap-4 transition-all">
                    <span className="text-lg">مشاهده</span>
                    <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center group-hover:bg-white group-hover:text-[#156394] transition-all">
                      <ArrowLeft className="w-5 h-5" />
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Hover Shine Effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute inset-0 bg-gradient-to-l from-transparent via-white/10 to-transparent -skew-x-12 translate-x-full group-hover:-translate-x-full transition-transform duration-1000" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
