import { motion } from 'motion/react';
import { Star, ShoppingCart, Heart, Eye } from 'lucide-react';
import { Button } from './ui/button';
import Slider from 'react-slick';
import { SliderStyles } from './SliderStyles';
import { useState } from 'react';
import { ProductCard } from './ProductCard';

// Import تصاویر
import img1 from '../../assets/7c5c739cd34e30bf8b766f02cf574cb8706d3e1e.png';
import img2 from '../../assets/5f92673b1304874f3a85849d81343dfdc1025b2a.png';
import img3 from '../../assets/7eeae581676e92671b8ee40714b2154b85c3a3f3.png';

// تبدیل اعداد به فارسی
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

// فرمت کردن قیمت به تومان
const formatPrice = (price: number) => {
  return toPersianNumber(price.toLocaleString('fa-IR'));
};

// تولید سایزها برای محصولات
const generateSizes = (productId: number, basePrice: number) => {
  const sizes = ['۱۵', '۲۰', '۲۵', '۳۲', '۴۰', '۵۰', '۶۳', '۷۵', '۹۰', '۱۱۰', '۱۲۵', '۱۴۰', '۱۶۰', '۱۸۰', '۲۰۰', '۲۲۵', '۲۵۰', '۲۸۰', '۳۱۵', '۳۵۵', '۴۰۰', '۴۵۰', '۵۰۰', '۵۶۰', '۶۳۰', '۷۱۰', '۸۰۰', '۹۰۰', '۱۰۰۰', '۱۲۵۰'];
  
  // هر محصول تعداد متفاوتی از سایز داره (بین 5 تا 30)
  const numSizes = Math.min(5 + (productId * 2), 30);
  const productSizes = sizes.slice(0, numSizes);
  
  return productSizes.map((size, index) => ({
    size,
    price: Math.round(basePrice * (1 + index * 0.15)) // قیمت با هر سایز بیشتر میشه
  }));
};

const products = [
  {
    id: 1,
    name: 'شیر یکطرفه فرب',
    category: 'شیرآلات',
    price: 2500000,
    rating: 4.8,
    reviews: 124,
    image: img1,
    badge: 'پرفروش',
    discount: 15,
    sizes: generateSizes(1, 2500000)
  },
  {
    id: 2,
    name: 'شیر فلکه فرب',
    category: 'شیرآلات',
    price: 3200000,
    rating: 4.9,
    reviews: 89,
    image: img2,
    badge: 'جدید',
    sizes: generateSizes(2, 3200000)
  },
  {
    id: 3,
    name: 'شیر توپی پیمتاش',
    category: 'شیرآلات',
    price: 1850000,
    rating: 4.7,
    reviews: 156,
    image: img3,
    badge: 'محبوب',
    sizes: generateSizes(3, 1850000)
  },
  {
    id: 4,
    name: 'شیر یکطرفه فرب DN50',
    category: 'شیرآلات',
    price: 2750000,
    rating: 4.6,
    reviews: 203,
    image: img1,
    discount: 20,
    sizes: generateSizes(4, 2750000)
  },
  {
    id: 5,
    name: 'شیر فلکه فرب DN80',
    category: 'شیرآلات',
    price: 4500000,
    rating: 4.8,
    reviews: 67,
    image: img2,
    badge: 'ویژه',
    sizes: generateSizes(5, 4500000)
  },
  {
    id: 6,
    name: 'شیر توپی پیمتاش DN65',
    category: 'شیرآلات',
    price: 2100000,
    rating: 5.0,
    reviews: 42,
    image: img3,
    badge: 'ویژه',
    discount: 10,
    sizes: generateSizes(6, 2100000)
  },
  {
    id: 7,
    name: 'شیر یکطرفه فرب DN100',
    category: 'شیرآلات',
    price: 5200000,
    rating: 4.9,
    reviews: 95,
    image: img1,
    badge: 'پرفروش',
    sizes: generateSizes(7, 5200000)
  },
  {
    id: 8,
    name: 'شیر فلکه فرب DN125',
    category: 'شیرآلات',
    price: 6800000,
    rating: 4.7,
    reviews: 78,
    image: img2,
    discount: 12,
    sizes: generateSizes(8, 6800000)
  },
  {
    id: 9,
    name: 'شیر توپی پیمتاش DN40',
    category: 'شیرآلات',
    price: 1650000,
    rating: 4.8,
    reviews: 134,
    image: img3,
    badge: 'محبوب',
    sizes: generateSizes(9, 1650000)
  },
  {
    id: 10,
    name: 'شیر یکطرفه فرب DN32',
    category: 'شیرآلات',
    price: 2200000,
    rating: 4.6,
    reviews: 112,
    image: img1,
    discount: 8,
    sizes: generateSizes(10, 2200000)
  },
  {
    id: 11,
    name: 'شیر فلکه فرب DN150',
    category: 'شیرآلات',
    price: 8500000,
    rating: 5.0,
    reviews: 56,
    image: img2,
    badge: 'ویژه',
    sizes: generateSizes(11, 8500000)
  },
  {
    id: 12,
    name: 'شیر توپی پیمتاش DN50',
    category: 'شیرآلات',
    price: 1950000,
    rating: 4.7,
    reviews: 143,
    image: img3,
    badge: 'پرفروش',
    discount: 15,
    sizes: generateSizes(12, 1950000)
  }
];

export function FeaturedProducts() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    rtl: true,
    autoplay: false,
    autoplaySpeed: 3000,
    responsive: [
      {
        breakpoint: 1536,
        settings: {
          slidesToShow: 4,
        }
      },
      {
        breakpoint: 1280,
        settings: {
          slidesToShow: 3,
        }
      },
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2,
        }
      },
      {
        breakpoint: 640,
        settings: {
          slidesToShow: 1,
        }
      }
    ]
  };

  return (
    <section className="py-12 bg-gradient-to-br from-gray-50 via-white to-blue-50/20">
      <SliderStyles />
      <div className="max-w-[1800px] mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">

          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl mb-4"
          >
            <span className="bg-gradient-to-r from-gray-900 via-[#156394] to-gray-900 bg-clip-text text-transparent">
              پرفروش‌ترین‌ها
            </span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl text-gray-600 max-w-2xl mx-auto"
          >
            محصولات برتر مورد اعتماد متخصصان در سراسر جهان
          </motion.p>
        </div>

        {/* Products Slider */}
        <div className="px-4 pb-12">
          <Slider {...settings}>
            {products.map((product) => (
              <div key={product.id} className="px-3">
                <ProductCard product={product} />
              </div>
            ))}
          </Slider>
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white hover:shadow-xl hover:shadow-[#156394]/20 rounded-full px-10"
          >
            مشاهده همه محصولات
          </Button>
        </motion.div>
      </div>
    </section>
  );
}