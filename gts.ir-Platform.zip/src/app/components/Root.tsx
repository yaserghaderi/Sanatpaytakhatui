import { Outlet } from 'react-router';
import { Header } from './Header';
import { Footer } from './Footer';
import { CartProvider, useCart } from '../contexts/CartContext';
import { SmartOrderProvider } from '../contexts/SmartOrderContext';
import { CartDrawer } from './CartDrawer';
import { FloatingAIButton } from './FloatingAIButton';
import { Toaster } from 'sonner';

function RootContent() {
  const { isCartOpen, closeCart } = useCart();
  return (
    <div className="min-h-screen bg-white" dir="rtl">
      <Toaster position="top-center" richColors />
      <Header />
      <Outlet />
      <Footer />
      <CartDrawer isOpen={isCartOpen} onClose={closeCart} />
      <FloatingAIButton />
    </div>
  );
}

export function Root() {
  return (
    <CartProvider>
      <SmartOrderProvider>
        <RootContent />
      </SmartOrderProvider>
    </CartProvider>
  );
}
