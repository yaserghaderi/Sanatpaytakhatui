import { useState } from 'react';
import { Star, ShoppingCart, Heart, Eye, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { motion } from 'motion/react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';

// تبدیل اعداد به فارسی
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

// فرمت کردن قیمت به تومان
const formatPrice = (price: number) => {
  return toPersianNumber(price.toLocaleString('fa-IR'));
};

interface ProductSize {
  size: string;
  price: number;
}

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    category: string;
    price: number;
    rating: number;
    reviews: number;
    image: string;
    badge?: string;
    discount?: number;
    sizes: ProductSize[];
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const [selectedSizeIndex, setSelectedSizeIndex] = useState(0);
  
  const currentSize = product.sizes[selectedSizeIndex];
  const currentPrice = currentSize.price;
  const finalPrice = product.discount 
    ? Math.round(currentPrice * (1 - product.discount / 100))
    : currentPrice;

  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart({
      productId: product.id,
      productName: product.name,
      productCategory: product.category,
      productImage: product.image,
      size: currentSize.size,
      price: currentPrice,
      discount: product.discount,
    });
    toast.success(`${product.name} (سایز ${currentSize.size}) به پیش‌فاکتور اضافه شد`, {
      description: `قیمت: ${formatPrice(finalPrice)} تومان`,
      duration: 3000,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className="group bg-white rounded-[2rem] overflow-hidden border border-gray-100 hover:border-[#156394]/20 hover:shadow-2xl transition-all duration-500"
    >
      {/* Product Image */}
      <div className="relative overflow-hidden aspect-square bg-gray-100">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        
        {/* Badges */}
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {product.badge && (
            <span className="bg-white/95 backdrop-blur-sm text-gray-900 px-4 py-1.5 rounded-full text-sm border border-gray-200">
              {product.badge}
            </span>
          )}
          {product.discount && (
            <span className="bg-gradient-to-r from-[#F2B524] to-orange-500 text-white px-4 py-1.5 rounded-full text-sm">
              ٪{toPersianNumber(product.discount)}-
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div className="absolute top-4 left-4 flex flex-col gap-2 opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
          <button className="bg-white text-gray-700 p-2.5 rounded-full shadow-lg hover:bg-[#156394] hover:text-white transition-colors">
            <Heart className="w-5 h-5" />
          </button>
          <button className="bg-white text-gray-700 p-2.5 rounded-full shadow-lg hover:bg-[#156394] hover:text-white transition-colors">
            <Eye className="w-5 h-5" />
          </button>
        </div>

        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      {/* Product Info */}
      <div className="p-6 text-right">
        <div className="text-sm text-[#F2B524] mb-2">{product.category}</div>
        <h3 className="text-xl mb-3 text-gray-900 group-hover:text-[#156394] transition-colors line-clamp-2">
          {product.name}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating)
                    ? 'fill-[#F2B524] text-[#F2B524]'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-500">
            {toPersianNumber(product.rating)} ({toPersianNumber(product.reviews)})
          </span>
        </div>

        {/* Size Slider */}
        <div className="mb-4 pb-4 border-b border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500">سایز:</span>
            <span className="text-sm bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
              {currentSize.size}
            </span>
          </div>
          
          {/* Horizontal Size Slider with custom scrollbar */}
          <div className="relative">
            <div 
              className="flex gap-2 overflow-x-auto pb-2 size-slider"
              style={{
                scrollbarWidth: 'thin',
                scrollbarColor: '#156394 #f3f4f6'
              }}
            >
              {product.sizes.map((sizeOption, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedSizeIndex(index)}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs transition-all ${
                    index === selectedSizeIndex
                      ? 'bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white shadow-md'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {sizeOption.size}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Price & Cart */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="flex flex-col gap-1">
            {product.discount ? (
              <>
                <span className="text-lg bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
                  {formatPrice(finalPrice)} تومان
                </span>
                <span className="text-xs text-gray-400 line-through">
                  {formatPrice(currentPrice)}
                </span>
              </>
            ) : (
              <span className="text-lg bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
                {formatPrice(currentPrice)} تومان
              </span>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              size="icon"
              className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] hover:shadow-lg hover:shadow-[#156394]/30 hover:scale-110 text-white transition-all rounded-full w-14 h-14"
              onClick={handleAddToCart}
            >
              <Plus className="w-8 h-8" strokeWidth={3} />
            </Button>
          </div>
        </div>
      </div>

      {/* Custom Scrollbar Styles */}
      <style suppressHydrationWarning>{`
        .size-slider::-webkit-scrollbar {
          height: 4px;
        }
        
        .size-slider::-webkit-scrollbar-track {
          background: #f3f4f6;
          border-radius: 10px;
        }
        
        .size-slider::-webkit-scrollbar-thumb {
          background: linear-gradient(to right, #156394, #1a7bb3);
          border-radius: 10px;
        }
        
        .size-slider::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(to right, #124a73, #156394);
        }
      `}</style>
    </motion.div>
  );
}