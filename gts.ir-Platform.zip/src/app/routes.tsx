import { createBrowserRouter } from 'react-router';
import { Root } from './components/Root';
import { HomePage } from './pages/HomePage';
import { CategoryPage } from './pages/CategoryPage';
import { AccountPage } from './pages/AccountPage';
import { DashboardLayout } from './pages/dashboard/DashboardLayout';
import { DashboardHome } from './pages/dashboard/DashboardHome';
import { DashboardProducts } from './pages/dashboard/DashboardProducts';
import { DashboardQuotations } from './pages/dashboard/DashboardQuotations';
import { DashboardOrders } from './pages/dashboard/DashboardOrders';
import { DashboardCustomers } from './pages/dashboard/DashboardCustomers';
import { DashboardAnalytics } from './pages/dashboard/DashboardAnalytics';
import { DashboardSync } from './pages/dashboard/DashboardSync';
import DashboardPurchases from './pages/dashboard/DashboardPurchases';
import DashboardShortcuts from './pages/dashboard/DashboardShortcuts';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Root,
    children: [
      { index: true, Component: HomePage },
      { path: 'category', Component: CategoryPage },
      { path: 'category/:tabId', Component: CategoryPage },
      { path: 'account', Component: AccountPage },
    ],
  },
  {
    path: '/dashboard',
    Component: DashboardLayout,
    children: [
      { index: true, Component: DashboardHome },
      { path: 'products', Component: DashboardProducts },
      { path: 'quotations', Component: DashboardQuotations },
      { path: 'orders', Component: DashboardOrders },
      { path: 'purchases', Component: DashboardPurchases },
      { path: 'shortcuts', Component: DashboardShortcuts },
      { path: 'customers', Component: DashboardCustomers },
      { path: 'analytics', Component: DashboardAnalytics },
      { path: 'sync', Component: DashboardSync },
    ],
  },
]);
