import { Hero } from '../components/Hero';
import { FeaturedProducts } from '../components/FeaturedProducts';
import { Brands } from '../components/Brands';
import { CategoryProducts } from '../components/CategoryProducts';
import { AboutUs } from '../components/AboutUs';
import { Clients } from '../components/Clients';
import { Features } from '../components/Features';
import { FAQ } from '../components/FAQ';
import { PoolCalculator } from '../components/PoolCalculator';

export function HomePage() {
  return (
    <main>
      <Hero />
      <FeaturedProducts />
      <Brands />
      <CategoryProducts
        category="لوله و اتصالات"
        title="لوله و اتصالات"
        description="محصولات با کیفیت برای سیستم‌های آب‌رسانی و لوله‌کشی صنعتی"
        bgGradient="from-white via-gray-50 to-white"
      />
      <CategoryProducts
        category="استخر و جکوزی"
        title="استخر و جکوزی"
        description="تجهیزات کامل برای ساخت و نگهداری استخر و جکوزی"
        bgGradient="from-blue-50/30 via-white to-blue-50/30"
      />
      <AboutUs />
      <Clients />
      <Features />
      <FAQ />
      <PoolCalculator />
    </main>
  );
}
