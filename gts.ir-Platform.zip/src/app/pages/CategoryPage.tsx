import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  SlidersHorizontal, ChevronDown, X, Plus, Star,
  ShoppingCart, Home, ChevronLeft, Tag, TrendingDown,
  TrendingUp, PackageCheck, Heart, Eye
} from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { megaTabs } from '../data/megaMenuData';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

const formatPrice = (price: number) =>
  toPersianNumber(price.toLocaleString('fa-IR'));

// ─── Mock products ────────────────────────────────────────────────────────────

interface Product {
  id: number;
  name: string;
  tab: string;
  category: string;
  price: number;
  unit: string;
  brand: string;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  discount?: number;
  inStock: boolean;
  material?: string;
  sizes: { size: string; price: number }[];
}

const PRODUCTS: Product[] = [
  { id: 1, name: 'زانو PVC ۹۰ درجه', tab: 'polymer', category: 'اتصالات پلیمری', price: 28000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.7, reviews: 124, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=400&q=80', badge: 'پرفروش', inStock: true, material: 'PVC', discount: 10, sizes: [{ size: '20mm', price: 18000 }, { size: '25mm', price: 28000 }, { size: '32mm', price: 42000 }, { size: '40mm', price: 58000 }, { size: '50mm', price: 75000 }] },
  { id: 2, name: 'سه‌راه مساوی پلیمری', tab: 'polymer', category: 'اتصالات پلیمری', price: 45000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.5, reviews: 89, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=400&q=80', inStock: true, material: 'PVC', sizes: [{ size: '25mm', price: 35000 }, { size: '32mm', price: 45000 }, { size: '40mm', price: 65000 }, { size: '50mm', price: 88000 }] },
  { id: 3, name: 'لوله PE100 صنعتی', tab: 'polymer', category: 'اتصالات پلیمری', price: 185000, unit: 'متر', brand: 'فارآب', rating: 4.8, reviews: 203, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', badge: 'پرفروش', inStock: true, material: 'پلی‌اتیلن', sizes: [{ size: '25mm', price: 95000 }, { size: '32mm', price: 130000 }, { size: '40mm', price: 165000 }, { size: '50mm', price: 185000 }, { size: '63mm', price: 240000 }] },
  { id: 4, name: 'شیر توپی برنجی', tab: 'valve', category: 'شیرآلات', price: 185000, unit: 'عدد', brand: 'بنکن', rating: 4.9, reviews: 312, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=400&q=80', badge: 'کیفیت بالا', inStock: true, material: 'برنج', sizes: [{ size: '1/4"', price: 120000 }, { size: '1/2"', price: 165000 }, { size: '3/4"', price: 185000 }, { size: '1"', price: 220000 }, { size: '2"', price: 420000 }] },
  { id: 5, name: 'شیر کشویی فلنجی', tab: 'valve', category: 'شیرآلات', price: 850000, unit: 'عدد', brand: 'ولدان', rating: 4.6, reviews: 67, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=400&q=80', inStock: true, material: 'چدن', discount: 15, sizes: [{ size: 'DN50', price: 650000 }, { size: 'DN65', price: 780000 }, { size: 'DN80', price: 850000 }, { size: 'DN100', price: 1100000 }] },
  { id: 6, name: 'شیر برقی ۲ طرفه', tab: 'valve', category: 'شیرآلات', price: 920000, unit: 'عدد', brand: 'بنکن', rating: 4.7, reviews: 145, image: 'https://images.unsplash.com/photo-1657183421041-a2e0d4983683?w=400&q=80', inStock: false, material: 'استیل', sizes: [{ size: '1/2"', price: 680000 }, { size: '3/4"', price: 820000 }, { size: '1"', price: 920000 }, { size: '1.5"', price: 1250000 }] },
  { id: 7, name: 'عایق لوله الاستومری', tab: 'insulation', category: 'عایق و شیلنگ', price: 95000, unit: 'متر', brand: 'ارا', rating: 4.4, reviews: 45, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', inStock: true, material: 'لاستیک', sizes: [{ size: '18mm×13mm', price: 68000 }, { size: '22mm×13mm', price: 82000 }, { size: '28mm×13mm', price: 95000 }, { size: '35mm×19mm', price: 125000 }] },
  { id: 8, name: 'شیلنگ فشار قوی', tab: 'insulation', category: 'عایق و شیلنگ', price: 180000, unit: 'متر', brand: 'فارآب', rating: 4.8, reviews: 198, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', badge: 'جدید', inStock: true, material: 'لاستیک', sizes: [{ size: '1/2"', price: 130000 }, { size: '3/4"', price: 160000 }, { size: '1"', price: 180000 }, { size: '1.5"', price: 240000 }] },
  { id: 9, name: 'فلنج گلودار PN16', tab: 'flange', category: 'لرزه‌گیر و فلنج', price: 320000, unit: 'عدد', brand: 'ولدان', rating: 4.7, reviews: 156, image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?w=400&q=80', inStock: true, material: 'فولاد', sizes: [{ size: 'DN50', price: 220000 }, { size: 'DN80', price: 320000 }, { size: 'DN100', price: 420000 }, { size: 'DN150', price: 680000 }] },
  { id: 10, name: 'لرزه‌گیر لاستیکی', tab: 'flange', category: 'لرزه‌گیر و فلنج', price: 480000, unit: 'عدد', brand: 'بنکن', rating: 4.5, reviews: 88, image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?w=400&q=80', badge: 'تخفیف', inStock: true, material: 'لاستیک', discount: 20, sizes: [{ size: 'DN50', price: 320000 }, { size: 'DN80', price: 480000 }, { size: 'DN100', price: 620000 }] },
  { id: 11, name: 'پمپ سیرکولاتور استخر ۱HP', tab: 'pool', category: 'استخر و جکوزی', price: 8500000, unit: 'دستگاه', brand: 'اطلس پول', rating: 4.9, reviews: 234, image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?w=400&q=80', badge: 'پرفروش', inStock: true, material: 'پلاستیک', sizes: [{ size: '0.5HP', price: 6200000 }, { size: '0.75HP', price: 7400000 }, { size: '1HP', price: 8500000 }, { size: '1.5HP', price: 11200000 }] },
  { id: 12, name: 'فیلتر شنی استخر', tab: 'pool', category: 'استخر و جکوزی', price: 18500000, unit: 'دستگاه', brand: 'پیمتاش', rating: 4.8, reviews: 167, image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?w=400&q=80', inStock: true, material: 'فایبرگلاس', sizes: [{ size: '400mm', price: 14500000 }, { size: '500mm', price: 18500000 }, { size: '600mm', price: 24000000 }] },
  { id: 13, name: 'جت جکوزی استیل', tab: 'pool', category: 'استخر و جکوزی', price: 1200000, unit: 'عدد', brand: 'مکس پول', rating: 4.6, reviews: 92, image: 'https://images.unsplash.com/photo-1700692883566-c1941832499f?w=400&q=80', inStock: false, material: 'استیل', sizes: [{ size: '1/2"', price: 950000 }, { size: '3/4"', price: 1200000 }, { size: '1"', price: 1580000 }] },
  { id: 14, name: 'مانیفولد برنجی ۵ مسیره', tab: 'pipe-acc', category: 'متعلقات لوله‌کشی', price: 650000, unit: 'عدد', brand: 'پلیمرتوس', rating: 4.6, reviews: 92, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', inStock: true, material: 'برنج', sizes: [{ size: '3 مسیره', price: 480000 }, { size: '4 مسیره', price: 580000 }, { size: '5 مسیره', price: 650000 }, { size: '6 مسیره', price: 750000 }] },
  { id: 15, name: 'بست U شکل گالوانیزه', tab: 'clamp', category: 'بست و نگه‌دارنده', price: 12000, unit: 'عدد', brand: 'ارس', rating: 4.3, reviews: 445, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80', inStock: true, material: 'فولاد گالوانیزه', sizes: [{ size: '20mm', price: 8000 }, { size: '25mm', price: 10000 }, { size: '32mm', price: 12000 }, { size: '40mm', price: 16000 }, { size: '50mm', price: 22000 }] },
  { id: 16, name: 'پمپ سانتریفیوژ صنعتی', tab: 'pump', category: 'پمپ و الکتروموتور', price: 24000000, unit: 'دستگاه', brand: 'ارس پمپ', rating: 4.8, reviews: 78, image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?w=400&q=80', badge: 'صنعتی', inStock: true, material: 'چدن', sizes: [{ size: '1HP', price: 18000000 }, { size: '2HP', price: 24000000 }, { size: '3HP', price: 32000000 }, { size: '5HP', price: 52000000 }] },
  { id: 17, name: 'آچار لوله سنگین ۱۴ اینچ', tab: 'tools', category: 'ابزار و تجهیزات', price: 3800000, unit: 'عدد', brand: 'ترموپلاستیک', rating: 4.7, reviews: 203, image: 'https://images.unsplash.com/photo-1761074342668-c38fc2e62e67?w=400&q=80', inStock: true, material: 'فولاد', sizes: [{ size: '10"', price: 2800000 }, { size: '14"', price: 3800000 }, { size: '18"', price: 5200000 }, { size: '24"', price: 7800000 }] },
  { id: 18, name: 'چسب PVC فوری ۵۰۰گرم', tab: 'adhesive', category: 'چسب و مواد شیمیایی', price: 1400000, unit: 'عدد', brand: 'فارآب', rating: 4.6, reviews: 367, image: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?w=400&q=80', badge: 'پرفروش', inStock: true, material: 'شیمیایی', sizes: [{ size: '100گرم', price: 850000 }, { size: '250گرم', price: 1200000 }, { size: '500گرم', price: 1400000 }, { size: '1کیلو', price: 2200000 }] },
  { id: 19, name: 'درزگیر سیلیکونی صنعتی', tab: 'adhesive', category: 'چسب و مواد شیمیایی', price: 280000, unit: 'عدد', brand: 'بنکن', rating: 4.5, reviews: 189, image: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?w=400&q=80', inStock: false, material: 'سیلیکون', discount: 12, sizes: [{ size: '300ml', price: 220000 }, { size: '500ml', price: 280000 }, { size: '1000ml', price: 480000 }] },
  { id: 20, name: 'کلر گرانول استخر ۵کیلو', tab: 'pool', category: 'استخر و جکوزی', price: 1850000, unit: 'بسته', brand: 'اطلس پول', rating: 4.7, reviews: 312, image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?w=400&q=80', inStock: true, material: 'شیمیایی', sizes: [{ size: '1kg', price: 420000 }, { size: '3kg', price: 1100000 }, { size: '5kg', price: 1850000 }, { size: '10kg', price: 3400000 }] },
];

// ─── Filter sidebar data ───────────────────────────────────────────────────────

const BRANDS = [...new Set(PRODUCTS.map(p => p.brand))];
const MATERIALS = [...new Set(PRODUCTS.map(p => p.material).filter(Boolean))] as string[];
const SIZE_GROUPS = ['زیر ۲۵mm', '۲۵ تا ۵۰mm', '۵۰ تا ۱۰۰mm', 'بالای ۱۰۰mm'];
const GUARANTEE_OPTIONS = ['دارد', 'ندارد'];
const USAGE_OPTIONS = ['صنعتی', 'ساختمانی', 'استخر', 'عمومی'];

// ─── Product Card (matching home page style) ──────────────────────────────────

function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [selectedIdx, setSelectedIdx] = useState(0);
  const selectedSize = product.sizes[selectedIdx];
  const finalPrice = product.discount
    ? Math.round(selectedSize.price * (1 - product.discount / 100))
    : selectedSize.price;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group bg-white rounded-[2rem] overflow-hidden border border-gray-100 hover:border-[#156394]/20 hover:shadow-2xl transition-all duration-500"
    >
      {/* Image */}
      <div className="relative overflow-hidden aspect-square bg-gray-50">
        <img src={product.image} alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {product.badge && (
            <span className="bg-white/95 backdrop-blur-sm text-gray-900 px-3 py-1 rounded-full text-xs border border-gray-200">
              {product.badge}
            </span>
          )}
          {product.discount && (
            <span className="bg-gradient-to-r from-[#F2B524] to-orange-500 text-white px-3 py-1 rounded-full text-xs">
              ٪{toPersianNumber(product.discount)}-
            </span>
          )}
          {!product.inStock && (
            <span className="bg-gray-500/90 text-white px-3 py-1 rounded-full text-xs">ناموجود</span>
          )}
        </div>
        <div className="absolute top-4 left-4 flex flex-col gap-2 opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
          <button className="bg-white text-gray-700 p-2 rounded-full shadow-lg hover:bg-[#156394] hover:text-white transition-colors">
            <Heart className="w-4 h-4" />
          </button>
          <button className="bg-white text-gray-700 p-2 rounded-full shadow-lg hover:bg-[#156394] hover:text-white transition-colors">
            <Eye className="w-4 h-4" />
          </button>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      </div>

      {/* Info */}
      <div className="p-5 text-right">
        <div className="text-xs text-[#F2B524] mb-1.5">{product.category}</div>
        <h3 className="text-gray-900 mb-2 group-hover:text-[#156394] transition-colors line-clamp-2">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1.5 mb-3">
          <div className="flex items-center gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(product.rating) ? 'fill-[#F2B524] text-[#F2B524]' : 'text-gray-300'}`} />
            ))}
          </div>
          <span className="text-xs text-gray-500">{toPersianNumber(product.rating)} ({toPersianNumber(product.reviews)})</span>
        </div>

        {/* Size slider */}
        <div className="mb-3 pb-3 border-b border-gray-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-gray-500">سایز:</span>
            <span className="text-xs text-[#156394]">{selectedSize.size}</span>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1 size-slider-cat" style={{ scrollbarWidth: 'thin', scrollbarColor: '#156394 #f3f4f6' }}>
            {product.sizes.map((s, i) => (
              <button key={i} onClick={() => setSelectedIdx(i)}
                className={`flex-shrink-0 px-2.5 py-1 rounded-full text-xs transition-all ${i === selectedIdx ? 'bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white shadow-sm' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                {s.size}
              </button>
            ))}
          </div>
        </div>

        {/* Price + Add */}
        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-0.5">
            <span className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
              {formatPrice(finalPrice)} تومان
            </span>
            {product.discount && (
              <span className="text-xs text-gray-400 line-through">{formatPrice(selectedSize.price)}</span>
            )}
          </div>
          <button
            disabled={!product.inStock}
            onClick={() => {
              addToCart({ productId: product.id, productName: product.name, productCategory: product.category, productImage: product.image, size: selectedSize.size, price: selectedSize.price });
              toast.success(`${product.name} به پیش‌فاکتور اضافه شد`);
            }}
            className="bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white p-3 rounded-full shadow-md hover:shadow-lg hover:scale-110 transition-all disabled:opacity-40 disabled:cursor-not-allowed disabled:scale-100"
          >
            <Plus className="w-5 h-5" strokeWidth={3} />
          </button>
        </div>
      </div>

      <style suppressHydrationWarning>{`
        .size-slider-cat::-webkit-scrollbar { height: 3px; }
        .size-slider-cat::-webkit-scrollbar-track { background: #f3f4f6; border-radius: 10px; }
        .size-slider-cat::-webkit-scrollbar-thumb { background: linear-gradient(to right, #156394, #1a7bb3); border-radius: 10px; }
      `}</style>
    </motion.div>
  );
}

// ─── Sidebar filter checkbox ──────────────────────────────────────────────────

function FilterCheck({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-center gap-2.5 cursor-pointer group py-0.5">
      <div onClick={onChange}
        className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors shrink-0
          ${checked ? 'bg-[#156394] border-[#156394]' : 'border-gray-300 group-hover:border-[#156394]'}`}>
        {checked && <span className="text-white text-[9px] font-bold leading-none">✓</span>}
      </div>
      <span className="text-xs text-gray-600 group-hover:text-gray-800 flex-1">{label}</span>
    </label>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

type QuickFilter = 'discount' | 'cheapest' | 'expensive' | 'inStock' | null;

export function CategoryPage() {
  const { tabId } = useParams<{ tabId?: string }>();
  const navigate = useNavigate();
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [selectedMaterials, setSelectedMaterials] = useState<string[]>([]);
  const [selectedSizeGroups, setSelectedSizeGroups] = useState<string[]>([]);
  const [selectedGuarantee, setSelectedGuarantee] = useState<string | null>(null);
  const [selectedUsage, setSelectedUsage] = useState<string[]>([]);
  const [quickFilter, setQuickFilter] = useState<QuickFilter>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    brand: true, material: true, size: false, guarantee: false, usage: false
  });

  const activeTabId = tabId || 'all';
  const activeTab = megaTabs.find(t => t.id === activeTabId);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setSelectedBrands([]);
    setSelectedMaterials([]);
    setSelectedSizeGroups([]);
    setSelectedGuarantee(null);
    setSelectedUsage([]);
    setQuickFilter(null);
  }, [activeTabId]);

  const toggleArr = <T,>(arr: T[], val: T) =>
    arr.includes(val) ? arr.filter(x => x !== val) : [...arr, val];

  const toggleSection = (key: string) =>
    setExpandedSections(s => ({ ...s, [key]: !s[key] }));

  let filtered = PRODUCTS.filter(p => {
    const tabMatch = !tabId || p.tab === tabId;
    const brandMatch = selectedBrands.length === 0 || selectedBrands.includes(p.brand);
    const materialMatch = selectedMaterials.length === 0 || (p.material && selectedMaterials.includes(p.material));
    return tabMatch && brandMatch && materialMatch;
  });

  if (quickFilter === 'discount') filtered = filtered.filter(p => !!p.discount);
  else if (quickFilter === 'cheapest') filtered = [...filtered].sort((a, b) => a.price - b.price);
  else if (quickFilter === 'expensive') filtered = [...filtered].sort((a, b) => b.price - a.price);
  else if (quickFilter === 'inStock') filtered = filtered.filter(p => p.inStock);

  const activeFilterCount = selectedBrands.length + selectedMaterials.length + selectedSizeGroups.length + (selectedGuarantee ? 1 : 0) + selectedUsage.length;

  const clearAll = () => {
    setSelectedBrands([]);
    setSelectedMaterials([]);
    setSelectedSizeGroups([]);
    setSelectedGuarantee(null);
    setSelectedUsage([]);
    setQuickFilter(null);
  };

  const quickFilters = [
    { key: 'discount' as QuickFilter, label: 'تخفیف‌دار', icon: Tag },
    { key: 'cheapest' as QuickFilter, label: 'ارزان‌ترین', icon: TrendingDown },
    { key: 'expensive' as QuickFilter, label: 'گران‌ترین', icon: TrendingUp },
    { key: 'inStock' as QuickFilter, label: 'موجود', icon: PackageCheck },
  ];

  return (
    <section className="pt-28 pb-16 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 md:px-6">

        {/* Breadcrumb */}
        <div className="flex items-center gap-1.5 text-sm text-gray-400 mb-5">
          <button onClick={() => navigate('/')} className="flex items-center gap-1 hover:text-[#156394] transition-colors">
            <Home size={14} /> خانه
          </button>
          <ChevronLeft size={13} className="text-gray-300" />
          <button onClick={() => navigate('/category')} className="hover:text-[#156394] transition-colors">دسته‌بندی</button>
          {activeTab && (
            <>
              <ChevronLeft size={13} className="text-gray-300" />
              <span className="text-gray-700">{activeTab.label}</span>
            </>
          )}
        </div>

        {/* Page title */}
        <div className="mb-6">
          <h1 className="text-2xl text-gray-900 mb-1">{activeTab ? activeTab.label : 'همه محصولات'}</h1>
          <p className="text-gray-500 text-sm">{toPersianNumber(filtered.length)} محصول یافت شد</p>
        </div>

        <div className="flex gap-6">
          {/* Sidebar */}
          <aside className="shrink-0 hidden lg:block" style={{ width: 220 }}>
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden sticky top-24">

              {/* Header */}
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
                <div className="flex items-center gap-2">
                  <SlidersHorizontal size={14} className="text-[#156394]" />
                  <span className="text-sm text-gray-700">فیلترها</span>
                  {activeFilterCount > 0 && (
                    <span className="bg-[#156394] text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">
                      {toPersianNumber(activeFilterCount)}
                    </span>
                  )}
                </div>
                {activeFilterCount > 0 && (
                  <button onClick={clearAll} className="text-xs text-red-400 hover:text-red-600 transition-colors">پاک کردن</button>
                )}
              </div>

              {/* Brand */}
              <div className="border-b border-gray-100">
                <button onClick={() => toggleSection('brand')}
                  className="flex items-center justify-between w-full px-4 py-3 text-right">
                  <span className="text-xs text-gray-700">برند</span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedSections.brand ? 'rotate-180' : ''}`} />
                </button>
                {expandedSections.brand && (
                  <div className="px-4 pb-3 space-y-1.5">
                    {BRANDS.map(b => (
                      <FilterCheck key={b} label={b} checked={selectedBrands.includes(b)}
                        onChange={() => setSelectedBrands(prev => toggleArr(prev, b))} />
                    ))}
                  </div>
                )}
              </div>

              {/* Material */}
              <div className="border-b border-gray-100">
                <button onClick={() => toggleSection('material')}
                  className="flex items-center justify-between w-full px-4 py-3 text-right">
                  <span className="text-xs text-gray-700">جنس اتصالات</span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedSections.material ? 'rotate-180' : ''}`} />
                </button>
                {expandedSections.material && (
                  <div className="px-4 pb-3 space-y-1.5">
                    {MATERIALS.map(m => (
                      <FilterCheck key={m} label={m} checked={selectedMaterials.includes(m)}
                        onChange={() => setSelectedMaterials(prev => toggleArr(prev, m))} />
                    ))}
                  </div>
                )}
              </div>

              {/* Size group */}
              <div className="border-b border-gray-100">
                <button onClick={() => toggleSection('size')}
                  className="flex items-center justify-between w-full px-4 py-3 text-right">
                  <span className="text-xs text-gray-700">ضخامت / سایز</span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedSections.size ? 'rotate-180' : ''}`} />
                </button>
                {expandedSections.size && (
                  <div className="px-4 pb-3 space-y-1.5">
                    {SIZE_GROUPS.map(s => (
                      <FilterCheck key={s} label={s} checked={selectedSizeGroups.includes(s)}
                        onChange={() => setSelectedSizeGroups(prev => toggleArr(prev, s))} />
                    ))}
                  </div>
                )}
              </div>

              {/* Guarantee */}
              <div className="border-b border-gray-100">
                <button onClick={() => toggleSection('guarantee')}
                  className="flex items-center justify-between w-full px-4 py-3 text-right">
                  <span className="text-xs text-gray-700">گارانتی</span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedSections.guarantee ? 'rotate-180' : ''}`} />
                </button>
                {expandedSections.guarantee && (
                  <div className="px-4 pb-3 space-y-1.5">
                    {GUARANTEE_OPTIONS.map(g => (
                      <label key={g} className="flex items-center gap-2.5 cursor-pointer py-0.5">
                        <div onClick={() => setSelectedGuarantee(selectedGuarantee === g ? null : g)}
                          className={`w-4 h-4 rounded-full border-2 flex items-center justify-center transition-colors shrink-0
                            ${selectedGuarantee === g ? 'border-[#156394] bg-[#156394]' : 'border-gray-300'}`}>
                          {selectedGuarantee === g && <span className="w-2 h-2 bg-white rounded-full block" />}
                        </div>
                        <span className="text-xs text-gray-600">{g}</span>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              {/* Usage */}
              <div>
                <button onClick={() => toggleSection('usage')}
                  className="flex items-center justify-between w-full px-4 py-3 text-right">
                  <span className="text-xs text-gray-700">کاربری</span>
                  <ChevronDown size={12} className={`text-gray-400 transition-transform ${expandedSections.usage ? 'rotate-180' : ''}`} />
                </button>
                {expandedSections.usage && (
                  <div className="px-4 pb-3 space-y-1.5">
                    {USAGE_OPTIONS.map(u => (
                      <FilterCheck key={u} label={u} checked={selectedUsage.includes(u)}
                        onChange={() => setSelectedUsage(prev => toggleArr(prev, u))} />
                    ))}
                  </div>
                )}
              </div>

            </div>
          </aside>

          {/* Main content */}
          <div className="flex-1 min-w-0">

            {/* Quick filter chips */}
            <div className="flex items-center gap-2 mb-4 flex-wrap">
              {quickFilters.map(({ key, label, icon: Icon }) => (
                <button key={key}
                  onClick={() => setQuickFilter(quickFilter === key ? null : key)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm transition-all border
                    ${quickFilter === key
                      ? 'bg-[#156394] text-white border-[#156394] shadow-md'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394] hover:text-[#156394]'}`}>
                  <Icon size={13} />
                  {label}
                </button>
              ))}
              {activeFilterCount > 0 && (
                <button onClick={clearAll}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-full text-xs text-red-400 border border-red-200 hover:bg-red-50 transition-colors">
                  <X size={11} /> پاک کردن فیلترها
                </button>
              )}
              <span className="mr-auto text-xs text-gray-400">{toPersianNumber(filtered.length)} محصول</span>
            </div>

            {/* Active filter tags */}
            <AnimatePresence>
              {(selectedBrands.length > 0 || selectedMaterials.length > 0) && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}
                  className="flex flex-wrap gap-2 mb-4">
                  {selectedBrands.map(b => (
                    <span key={b} className="flex items-center gap-1.5 px-3 py-1 bg-[#156394]/10 text-[#156394] rounded-full text-xs">
                      {b} <button onClick={() => setSelectedBrands(p => p.filter(x => x !== b))}><X size={10} /></button>
                    </span>
                  ))}
                  {selectedMaterials.map(m => (
                    <span key={m} className="flex items-center gap-1.5 px-3 py-1 bg-[#156394]/10 text-[#156394] rounded-full text-xs">
                      {m} <button onClick={() => setSelectedMaterials(p => p.filter(x => x !== m))}><X size={10} /></button>
                    </span>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Products grid */}
            {filtered.length === 0 ? (
              <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
                <ShoppingCart size={40} className="mx-auto mb-3 text-gray-200" />
                <p className="text-gray-500 text-sm">محصولی یافت نشد</p>
                <button onClick={clearAll} className="mt-3 text-[#156394] text-sm hover:underline">
                  پاک کردن فیلترها
                </button>
              </div>
            ) : (
              <motion.div layout className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                <AnimatePresence mode="popLayout">
                  {filtered.map((product, i) => (
                    <motion.div key={product.id} layout
                      initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.97 }} transition={{ delay: i * 0.03 }}>
                      <ProductCard product={product} />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
