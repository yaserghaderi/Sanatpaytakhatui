import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router';
import {
  User, FileText, ShoppingCart, Star, RefreshCw,
  Package, Clock, CheckCircle, Truck, ChevronLeft, LogIn, Plus, Heart
} from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};
const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

type Tab = 'overview' | 'orders' | 'quotations' | 'favorites' | 'profile';
type OrderStatus = 'processing' | 'confirmed' | 'shipped' | 'delivered';

interface UserOrder {
  id: string; date: string; status: OrderStatus;
  items: { name: string; qty: number; price: number; image: string }[];
  total: number;
}

const USER_ORDERS: UserOrder[] = [
  {
    id: 'ORD-۱۴۰۳-۱۲۸', date: '۱۴۰۳/۰۹/۱۸', status: 'processing',
    items: [
      { name: 'شیر توپی برنجی ۱/۲"', qty: 5, price: 165000, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=200&q=80' },
      { name: 'لوله PE100 25mm', qty: 50, price: 95000, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=200&q=80' },
    ],
    total: 5575000
  },
  {
    id: 'ORD-۱۴۰۳-۱۱۵', date: '۱۴۰۳/۰۸/۲۵', status: 'delivered',
    items: [
      { name: 'فیلتر شنی استخر ۵۰۰mm', qty: 1, price: 18500000, image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?w=200&q=80' },
    ],
    total: 18500000
  },
];

const USER_QUOTATIONS = [
  { id: 'QT-۱۴۰۳-۰۴۵', date: '۱۴۰۳/۰۹/۱۸', status: 'pending_review', items: 3, total: 10405000 },
  { id: 'QT-۱۴۰۳-۰۳۸', date: '۱۴۰۳/۰۹/۰۵', status: 'sent', items: 2, total: 35500000 },
  { id: 'QT-۱۴۰۳-۰۲۹', date: '۱۴۰۳/۰۸/۱۵', status: 'converted', items: 4, total: 5840000 },
];

const FREQUENT_ITEMS = [
  { name: 'شیر توپی برنجی ۱/۲"', count: 6, price: 165000, image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?w=200&q=80' },
  { name: 'لوله PE100 25mm', count: 4, price: 95000, image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?w=200&q=80' },
  { name: 'زانو PVC 25mm', count: 3, price: 28000, image: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=200&q=80' },
];

const statusCfg: Record<OrderStatus, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  processing: { label: 'در حال پردازش', icon: Clock,        color: 'text-yellow-700', bg: 'bg-yellow-50' },
  confirmed:  { label: 'تایید شده',      icon: CheckCircle,  color: 'text-blue-600',   bg: 'bg-blue-50' },
  shipped:    { label: 'ارسال شده',      icon: Truck,        color: 'text-purple-600', bg: 'bg-purple-50' },
  delivered:  { label: 'تحویل داده شد', icon: Package,      color: 'text-green-600',  bg: 'bg-green-50' },
};

const quotationStatusCfg: Record<string, { label: string; color: string }> = {
  pending_review: { label: 'در حال بررسی', color: 'text-yellow-700' },
  sent:           { label: 'دریافت شد',    color: 'text-blue-600' },
  converted:      { label: 'تبدیل به سفارش', color: 'text-green-600' },
};

const tabs: { key: Tab; label: string; icon: React.ElementType }[] = [
  { key: 'overview', label: 'خلاصه', icon: User },
  { key: 'orders', label: 'سفارش‌ها', icon: ShoppingCart },
  { key: 'quotations', label: 'پیش‌فاکتورها', icon: FileText },
  { key: 'favorites', label: 'خریدهای پرتکرار', icon: RefreshCw },
  { key: 'profile', label: 'اطلاعات حساب', icon: User },
];

export function AccountPage() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [isLoggedIn] = useState(true); // mock

  if (!isLoggedIn) {
    return (
      <section className="pt-28 pb-16 bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="bg-white rounded-3xl p-10 text-center max-w-sm w-full shadow-lg">
          <div className="w-16 h-16 bg-[#156394]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <LogIn size={28} className="text-[#156394]" />
          </div>
          <h2 className="text-gray-800 mb-2">ورود به حساب کاربری</h2>
          <p className="text-sm text-gray-500 mb-6">برای مشاهده سفارش‌ها و پیش‌فاکتورهای خود وارد شوید.</p>
          <button className="w-full py-3 bg-[#156394] text-white rounded-xl hover:bg-[#0d4a6f] transition-colors">
            ورود / ثبت‌نام
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="pt-24 pb-16 bg-gray-50 min-h-screen">
      <div className="max-w-5xl mx-auto px-4 md:px-6">

        {/* Profile header card */}
        <div className="bg-gradient-to-r from-[#0f2744] to-[#156394] rounded-3xl p-6 mb-6 flex items-center gap-5">
          <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center shrink-0">
            <span className="text-white text-2xl">م</span>
          </div>
          <div className="flex-1">
            <h1 className="text-white mb-1">مهندس احمدی</h1>
            <p className="text-white/70 text-sm">09123456789 · تهران</p>
            <div className="flex items-center gap-4 mt-3">
              <div className="text-center">
                <p className="text-white">{toPersianNumber(12)}</p>
                <p className="text-white/60 text-xs">سفارش</p>
              </div>
              <div className="w-px h-8 bg-white/20" />
              <div className="text-center">
                <p className="text-white">{toPersianNumber(3)}</p>
                <p className="text-white/60 text-xs">پیش‌فاکتور</p>
              </div>
              <div className="w-px h-8 bg-white/20" />
              <div className="text-center">
                <p className="text-[#F2B524]">{formatPrice(142000000)}</p>
                <p className="text-white/60 text-xs">جمع خریدها</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2 shrink-0">
            <div className="bg-white/10 rounded-xl px-3 py-1.5 text-xs text-white flex items-center gap-1">
              <Star size={11} className="fill-[#F2B524] text-[#F2B524]" />
              مشتری VIP
            </div>
          </div>
        </div>

        <div className="flex gap-5">
          {/* Sidebar nav */}
          <aside className="shrink-0 hidden md:block w-48">
            <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
              {tabs.map(t => {
                const Icon = t.icon;
                const active = activeTab === t.key;
                return (
                  <button key={t.key} onClick={() => setActiveTab(t.key)}
                    className={`flex items-center gap-3 w-full px-4 py-3 text-sm text-right border-b border-gray-50 transition-all
                      ${active ? 'bg-[#156394] text-white' : 'text-gray-600 hover:bg-gray-50'}`}>
                    <Icon size={15} />
                    {t.label}
                  </button>
                );
              })}
            </div>
          </aside>

          {/* Mobile tab bar */}
          <div className="flex gap-2 md:hidden mb-4 overflow-x-auto">
            {tabs.map(t => {
              const Icon = t.icon;
              return (
                <button key={t.key} onClick={() => setActiveTab(t.key)}
                  className={`flex items-center gap-1.5 shrink-0 px-3 py-2 rounded-xl text-xs border transition-all
                    ${activeTab === t.key ? 'bg-[#156394] text-white border-[#156394]' : 'bg-white text-gray-600 border-gray-200'}`}>
                  <Icon size={12} />
                  {t.label}
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <AnimatePresence mode="wait">
              <motion.div key={activeTab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                transition={{ duration: 0.15 }}>

                {activeTab === 'overview' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Last order */}
                      <div className="bg-white rounded-2xl border border-gray-100 p-5">
                        <div className="flex items-center justify-between mb-4">
                          <p className="text-sm text-gray-700">آخرین سفارش</p>
                          <button onClick={() => setActiveTab('orders')} className="text-xs text-[#156394] hover:underline">مشاهده همه</button>
                        </div>
                        {USER_ORDERS[0] && (() => {
                          const o = USER_ORDERS[0];
                          const st = statusCfg[o.status];
                          const Icon = st.icon;
                          return (
                            <div>
                              <div className="flex items-center gap-2 mb-3">
                                <span className={`flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full ${st.bg} ${st.color}`}>
                                  <Icon size={11} /> {st.label}
                                </span>
                                <span className="text-xs text-gray-400">{o.date}</span>
                              </div>
                              {o.items.map((item, i) => (
                                <div key={i} className="flex items-center gap-2 py-2 border-b border-gray-50">
                                  <img src={item.image} alt="" className="w-10 h-10 rounded-lg object-cover shrink-0" />
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs text-gray-700 truncate">{item.name}</p>
                                    <p className="text-[10px] text-gray-400">{toPersianNumber(item.qty)} عدد</p>
                                  </div>
                                </div>
                              ))}
                              <p className="text-sm text-[#156394] mt-3">{formatPrice(o.total)} تومان</p>
                            </div>
                          );
                        })()}
                      </div>

                      {/* Frequent buys */}
                      <div className="bg-white rounded-2xl border border-gray-100 p-5">
                        <div className="flex items-center justify-between mb-4">
                          <p className="text-sm text-gray-700">خریدهای پرتکرار شما</p>
                          <RefreshCw size={14} className="text-gray-400" />
                        </div>
                        <div className="space-y-3">
                          {FREQUENT_ITEMS.map((item, i) => (
                            <div key={i} className="flex items-center gap-3">
                              <img src={item.image} alt="" className="w-10 h-10 rounded-xl object-cover shrink-0" />
                              <div className="flex-1">
                                <p className="text-xs text-gray-700">{item.name}</p>
                                <p className="text-[10px] text-gray-400">{toPersianNumber(item.count)} بار خریداری شده</p>
                              </div>
                              <button className="px-3 py-1.5 bg-[#156394] text-white rounded-xl text-[10px] flex items-center gap-1 hover:bg-[#0d4a6f] transition-colors shrink-0">
                                <Plus size={10} /> افزودن
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Quick actions */}
                    <div className="bg-white rounded-2xl border border-gray-100 p-5">
                      <p className="text-sm text-gray-700 mb-4">اقدامات سریع</p>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {[
                          { label: 'پیش‌فاکتور هوشمند', icon: FileText, color: '#156394', onClick: () => {} },
                          { label: 'مشاهده سفارشات', icon: ShoppingCart, color: '#10b981', onClick: () => setActiveTab('orders') },
                          { label: 'بازسفارش مجدد', icon: RefreshCw, color: '#F2B524', onClick: () => setActiveTab('favorites') },
                          { label: 'پیگیری تحویل', icon: Truck, color: '#8b5cf6', onClick: () => setActiveTab('orders') },
                        ].map((a, i) => {
                          const Icon = a.icon;
                          return (
                            <button key={i} onClick={a.onClick}
                              className="flex flex-col items-center gap-2 p-4 rounded-2xl border border-gray-100 hover:border-[#156394]/20 hover:shadow-md transition-all">
                              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: a.color + '18' }}>
                                <Icon size={18} style={{ color: a.color }} />
                              </div>
                              <p className="text-xs text-gray-600 text-center">{a.label}</p>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'orders' && (
                  <div className="space-y-4">
                    <h2 className="text-sm text-gray-700">سفارش‌های من</h2>
                    {USER_ORDERS.map((o, i) => {
                      const st = statusCfg[o.status];
                      const Icon = st.icon;
                      return (
                        <div key={i} className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
                          <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-50">
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-400 font-mono">{o.id}</span>
                              <span className={`flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full ${st.bg} ${st.color}`}>
                                <Icon size={10} />{st.label}
                              </span>
                            </div>
                            <span className="text-xs text-gray-400">{o.date}</span>
                          </div>
                          <div className="p-5">
                            <div className="space-y-2 mb-4">
                              {o.items.map((item, j) => (
                                <div key={j} className="flex items-center gap-3">
                                  <img src={item.image} alt="" className="w-12 h-12 rounded-xl object-cover shrink-0" />
                                  <div className="flex-1">
                                    <p className="text-xs text-gray-800">{item.name}</p>
                                    <p className="text-[10px] text-gray-500">{toPersianNumber(item.qty)} عدد × {formatPrice(item.price)} تومان</p>
                                  </div>
                                  <p className="text-xs text-[#156394] shrink-0">{formatPrice(item.qty * item.price)} ت</p>
                                </div>
                              ))}
                            </div>
                            <div className="flex items-center justify-between pt-3 border-t border-gray-50">
                              <p className="text-sm text-[#156394]">{formatPrice(o.total)} تومان</p>
                              <button className="flex items-center gap-1.5 text-xs text-[#156394] hover:underline">
                                <RefreshCw size={12} /> سفارش مجدد
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                {activeTab === 'quotations' && (
                  <div className="space-y-4">
                    <h2 className="text-sm text-gray-700">پیش‌فاکتورهای من</h2>
                    {USER_QUOTATIONS.map((q, i) => {
                      const st = quotationStatusCfg[q.status];
                      return (
                        <div key={i} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-center gap-4">
                          <div className="w-10 h-10 bg-[#156394]/10 rounded-xl flex items-center justify-center shrink-0">
                            <FileText size={18} className="text-[#156394]" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-mono text-gray-600">{q.id}</span>
                              <span className={`text-[10px] ${st.color}`}>{st.label}</span>
                            </div>
                            <p className="text-xs text-gray-500">{q.date} · {toPersianNumber(q.items)} کالا</p>
                          </div>
                          <div className="text-left">
                            <p className="text-sm text-[#156394]">{formatPrice(q.total)} ت</p>
                          </div>
                          <button className="px-3 py-1.5 border border-gray-200 rounded-xl text-xs text-gray-600 hover:bg-gray-50 transition-colors shrink-0">
                            دانلود PDF
                          </button>
                        </div>
                      );
                    })}
                  </div>
                )}

                {activeTab === 'favorites' && (
                  <div className="space-y-4">
                    <h2 className="text-sm text-gray-700">خریدهای پرتکرار — سفارش مجدد با یک کلیک</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {FREQUENT_ITEMS.map((item, i) => (
                        <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4">
                          <img src={item.image} alt="" className="w-16 h-16 rounded-xl object-cover shrink-0" />
                          <div className="flex-1">
                            <p className="text-sm text-gray-800 mb-1">{item.name}</p>
                            <p className="text-xs text-gray-400 mb-2">{toPersianNumber(item.count)} بار خریداری شده</p>
                            <p className="text-xs text-[#156394]">{formatPrice(item.price)} تومان</p>
                          </div>
                          <button className="flex flex-col items-center gap-1 px-3 py-2.5 bg-[#156394] text-white rounded-xl hover:bg-[#0d4a6f] transition-colors shrink-0">
                            <Plus size={14} />
                            <span className="text-[10px]">افزودن</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'profile' && (
                  <div className="bg-white rounded-2xl border border-gray-100 p-6">
                    <h2 className="text-sm text-gray-700 mb-5">اطلاعات حساب کاربری</h2>
                    <div className="space-y-4">
                      {[
                        { label: 'نام و نام خانوادگی', value: 'مهندس احمدی', type: 'text' },
                        { label: 'شماره موبایل', value: '09123456789', type: 'tel' },
                        { label: 'شهر', value: 'تهران', type: 'text' },
                        { label: 'آدرس', value: 'تهران، خیابان ولیعصر، پلاک ۱۲', type: 'text' },
                        { label: 'کد اقتصادی / شناسه ملی', value: '۱۰۳۴۵۶۷۸۹۰', type: 'text' },
                      ].map((f, i) => (
                        <div key={i}>
                          <label className="block text-xs text-gray-500 mb-1.5">{f.label}</label>
                          <input type={f.type} defaultValue={f.value}
                            className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
                        </div>
                      ))}
                      <button className="px-6 py-2.5 bg-[#156394] text-white rounded-xl text-sm hover:bg-[#0d4a6f] transition-colors">
                        ذخیره تغییرات
                      </button>
                    </div>
                  </div>
                )}

              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
