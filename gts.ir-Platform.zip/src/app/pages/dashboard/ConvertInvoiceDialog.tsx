import { useEffect, useState } from 'react';
import { ArrowLeftRight, UserRound, Package, ListTodo, Check } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Label } from '../../components/ui/label';
import { Checkbox } from '../../components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';

const transfers = [
  { key: 'buyer', label: 'اطلاعات خریدار', icon: UserRound },
  { key: 'items', label: 'لیست کالاهای فاکتور', icon: Package },
  { key: 'workflow', label: 'گردش کار فاکتور', icon: ListTodo },
] as const;

export default function ConvertInvoiceDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [target, setTarget] = useState('');
  const [selected, setSelected] = useState<string[]>(['buyer', 'items']);
  const [confirmed, setConfirmed] = useState(false);
  useEffect(() => { if (open) { setTarget(''); setSelected(['buyer', 'items']); setConfirmed(false); } }, [open]);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent dir="rtl" className="rounded-2xl">
    <DialogHeader className="text-right sm:text-right">
      <span className="mb-2 flex size-11 items-center justify-center rounded-xl bg-brand/10 text-brand"><ArrowLeftRight size={21} /></span>
      <DialogTitle>تبدیل پیش‌فاکتور</DialogTitle>
      <DialogDescription>نوع سند مقصد و اطلاعاتی که می‌خواهید به آن منتقل شوند را انتخاب کنید.</DialogDescription>
    </DialogHeader>
    <div className="space-y-2"><Label htmlFor="convert-target" className="text-xs">تبدیل به</Label><Select value={target} onValueChange={value => { setTarget(value); setConfirmed(false); }}><SelectTrigger id="convert-target" className="w-full rounded-xl"><SelectValue placeholder="انتخاب نوع سند مقصد" /></SelectTrigger><SelectContent dir="rtl">{['برگشت از فروش', 'پیش‌فاکتور خرید', 'پیش‌فاکتور برگشت از خرید'].map(value => <SelectItem value={value} key={value}>{value}</SelectItem>)}</SelectContent></Select></div>
    <div className="space-y-2"><Label className="text-xs text-muted-foreground">اطلاعات قابل انتقال</Label>{transfers.map(item => <Label key={item.key} className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3 text-xs transition-colors ${selected.includes(item.key) ? 'border-brand/25 bg-brand/5' : 'border-border bg-background'}`}><Checkbox checked={selected.includes(item.key)} onCheckedChange={checked => { setSelected(current => checked === true ? [...current, item.key] : current.filter(key => key !== item.key)); setConfirmed(false); }} /><item.icon size={16} className="text-muted-foreground" /><span>{item.label}</span></Label>)}</div>
    {confirmed && <div role="status" className="flex items-center gap-2 rounded-xl bg-brand/10 p-3 text-xs leading-relaxed text-brand"><Check size={16} className="shrink-0" />انتخاب‌ها تأیید شدند؛ سند جدیدی ایجاد نشده است.</div>}
    <div className="flex justify-end gap-2 border-t border-border/60 pt-4"><Button variant="outline" className="rounded-xl" onClick={() => onOpenChange(false)}>انصراف</Button><Button disabled={!target || confirmed} className="rounded-xl bg-brand text-white hover:bg-brand/90" onClick={() => setConfirmed(true)}><ArrowLeftRight size={15} />تأیید تبدیل</Button></div>
  </DialogContent></Dialog>;
}
