import { useEffect, useState } from 'react';
import { Keyboard, Check, RotateCcw, X, Sparkles, Plus, Save, ArrowDownUp, ArrowLeftRight, Star, Search, AlertCircle } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { loadShortcuts, shortcutDefinitions, shortcutFromEvent, shortcutStorageKey } from '../../data/shortcuts';

const icons = { shortcuts: Keyboard, smart: Sparkles, manual: Plus, save: Save, navigate: ArrowDownUp, convert: ArrowLeftRight, star: Star };
const keyLabel: Record<string, string> = { Meta: '⌘', ArrowDown: '↓', ArrowUp: '↑', ArrowLeft: '←', ArrowRight: '→' };

export default function DashboardShortcuts() {
  const [bindings, setBindings] = useState(loadShortcuts);
  const [recording, setRecording] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  useEffect(() => {
    if (!saved) return;
    const timer = window.setTimeout(() => setSaved(null), 2500);
    return () => window.clearTimeout(timer);
  }, [saved]);
  const commit = (id: string, keys: string) => {
    const conflict = shortcutDefinitions.find(item => item.id !== id && bindings[item.id] === keys);
    if (conflict) { setError(`این ترکیب برای «${conflict.label}» استفاده شده است؛ ترکیب دیگری را فشار دهید.`); return; }
    const next = { ...bindings, [id]: keys };
    try {
      localStorage.setItem(shortcutStorageKey, JSON.stringify(next));
      setBindings(next); setRecording(null); setError(''); setSaved(id);
    } catch { setError('ذخیره تنظیمات ممکن نشد. دسترسی مرورگر به حافظه را بررسی کنید.'); }
  };
  useEffect(() => {
    if (!recording) return;
    const handler = (event: KeyboardEvent) => {
      if (event.isComposing || event.repeat) return;
      if (event.key === 'Tab') return;
      event.preventDefault(); event.stopPropagation();
      if (event.key === 'Escape') { setRecording(null); setError(''); return; }
      const keys = shortcutFromEvent(event);
      if (keys) commit(recording, keys);
      else if (!['Control', 'Alt', 'Meta', 'Shift'].includes(event.key)) setError('از Ctrl، Alt یا Command همراه یک کلید دیگر، یا کلیدهای F1 تا F12 استفاده کنید.');
    };
    window.addEventListener('keydown', handler, true);
    return () => window.removeEventListener('keydown', handler, true);
  }, [recording, bindings]);
  const filtered = shortcutDefinitions.filter(item => `${item.label} ${item.description}`.includes(search.trim()));
  return <div dir="rtl" className="mx-auto max-w-screen-xl space-y-6 p-4 sm:p-6">
    <div className="flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-3"><span className="flex size-12 items-center justify-center rounded-2xl bg-brand/10 text-brand"><Keyboard size={25} /></span><div><div className="text-lg font-semibold">میانبرها، به سبک شما</div><div className="mt-1 text-xs leading-relaxed text-muted-foreground">روی ترکیب کلید هر عملیات کلیک کنید و میانبر دلخواهتان را فشار دهید.</div></div></div>
      <span className="flex items-center gap-1.5 rounded-full border border-border bg-background px-3 py-2 text-xs text-muted-foreground"><Check size={14} className="text-emerald-600" />ذخیره خودکار تنظیمات</span>
    </div>
    <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-brand/15 bg-brand/5 p-4"><div className="flex items-center gap-3 text-xs leading-relaxed text-brand"><Keyboard size={20} className="shrink-0" /><span>یک کلیک، یک ترکیب جدید. برای لغو ضبط کلید Escape را بزنید.</span></div><span dir="ltr" className="flex items-center gap-1.5">{['Ctrl', '+', 'Alt', '+', 'K'].map((key, i) => <span key={i} className={key === '+' ? 'text-xs text-muted-foreground' : 'flex h-8 min-w-8 items-center justify-center rounded-lg border border-border bg-background px-2 text-xs font-medium shadow-sm'}>{key}</span>)}</span></div>
    <div className="relative max-w-sm"><Search size={16} className="absolute right-3 top-3 text-muted-foreground" /><Input aria-label="جستجوی میانبرها" placeholder="جستجوی عملیات…" value={search} onChange={event => setSearch(event.target.value)} className="h-10 rounded-xl bg-background pr-9" /></div>
    {['دسترسی سریع', 'ایجاد درخواست', 'عملیات فاکتور'].map(group => {
      const items = filtered.filter(item => item.group === group);
      if (!items.length) return null;
      return <section key={group} className="space-y-3"><div className="flex items-center gap-2 text-xs font-medium text-muted-foreground"><span>{group}</span><span className="rounded-md bg-muted px-1.5 py-0.5">{items.length.toLocaleString('fa-IR')}</span></div><div className="overflow-hidden rounded-2xl border border-border/60 bg-background shadow-sm">{items.map(item => {
        const Icon = icons[item.id as keyof typeof icons];
        const active = recording === item.id;
        return <div key={item.id} className={`flex flex-wrap items-center gap-3 border-b border-border/50 p-4 last:border-b-0 sm:gap-4 sm:p-5 ${active ? 'bg-brand/5' : ''}`}>
          <span className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${active ? 'bg-brand text-white' : 'bg-muted/60 text-brand'}`}><Icon size={18} /></span>
          <div className="min-w-0 flex-1"><div className="text-sm font-medium">{item.label}</div><div className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.description}</div></div>
          <div className="flex w-full items-center justify-end gap-2 sm:w-auto">
            {saved === item.id && <span role="status" className="flex items-center gap-1 text-xs text-emerald-600"><Check size={15} />ذخیره شد</span>}
            <Button variant="outline" aria-label={`تغییر میانبر ${item.label}`} aria-pressed={active} onClick={() => { setRecording(active ? null : item.id); setError(''); setSaved(null); }} className={`h-11 min-w-40 gap-1.5 rounded-xl px-3 ${active ? 'border-brand bg-brand/5 text-brand ring-2 ring-brand/10' : 'bg-muted/20 hover:border-brand/30'}`}>
              {active ? <span className="flex items-center gap-2 text-xs"><span className="size-1.5 animate-pulse rounded-full bg-brand" />کلیدها را فشار دهید…</span> : <span dir="ltr" className="flex items-center gap-1">{bindings[item.id] ? bindings[item.id].split('+').map((key, i) => <span key={i} className="flex h-7 min-w-7 items-center justify-center rounded-md border border-border bg-background px-1.5 text-xs font-medium shadow-sm">{keyLabel[key] ?? key}</span>) : <span className="text-xs text-muted-foreground">تنظیم میانبر</span>}</span>}
            </Button>
            <Button variant="ghost" size="icon" className="size-8 rounded-lg text-muted-foreground" aria-label={active ? 'لغو ضبط میانبر' : `بازنشانی میانبر ${item.label}`} disabled={!active && bindings[item.id] === item.keys} onClick={() => { if (active) { setRecording(null); setError(''); } else { setRecording(item.id); commit(item.id, item.keys); } }}>{active ? <X size={15} /> : <RotateCcw size={15} />}</Button>
          </div>
          {active && error && <div role="alert" className="flex w-full items-start gap-2 rounded-lg bg-destructive/5 p-3 text-xs leading-relaxed text-destructive"><AlertCircle size={15} className="shrink-0" />{error}</div>}
        </div>;
      })}</div></section>;
    })}
    {!filtered.length && <div className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">عملیاتی با این نام پیدا نشد.</div>}
  </div>;
}
