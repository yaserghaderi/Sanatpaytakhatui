import { useEffect, useRef, useState } from 'react';
import { Reply, Send, UserRound, X } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Textarea } from '../../components/ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from '../../components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { currentStaff } from '../../data/staff';
import type { Invoice } from './DashboardOrders';

type Message = NonNullable<Invoice['messages']>[number];
export default function InvoiceChatDialog({ open, onOpenChange, invoice, locked, onUpdate }: {
  open: boolean; onOpenChange: (open: boolean) => void; invoice: Invoice; locked: boolean; onUpdate: (invoice: Invoice) => void;
}) {
  const [text, setText] = useState('');
  const [reply, setReply] = useState<{ id: string; name: string; text: string } | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const focusComposer = () => document.getElementById(`chat-input-${invoice.id}`)?.focus();
  const messages = invoice.messages ?? [];
  useEffect(() => { if (open) bottom.current?.scrollIntoView({ block: 'nearest' }); }, [messages.length, open]);
  const send = () => {
    if (locked || !text.trim()) return;
    const message: Message = { id: crypto.randomUUID(), text: text.trim(), time: new Date().toLocaleString('fa-IR'), author: currentStaff, ...(reply ? { replyTo: reply } : {}) };
    onUpdate({ ...invoice, messages: [...messages, message] });
    setText(''); setReply(null); focusComposer();
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent dir="rtl" className="flex max-h-[85vh] flex-col gap-3 rounded-2xl sm:max-w-xl">
      <DialogHeader className="shrink-0 text-right sm:text-right"><DialogTitle>گفت‌وگوی درخواست #{invoice.id.toLocaleString('fa-IR')}</DialogTitle><DialogDescription>{messages.length.toLocaleString('fa-IR')} پیام</DialogDescription></DialogHeader>
      <div className="min-h-32 min-w-0 flex-1 space-y-4 overflow-y-auto rounded-xl bg-muted/30 p-3">
        {messages.map((message, index) => {
          const author: { name: string; avatar?: string } = message.author ?? { name: 'کاربر نامشخص' };
          const id = message.id ?? `legacy-${index}`;
          return <div key={id} className="flex items-start gap-2">
            <Avatar className="size-8 shrink-0"><AvatarImage src={author.avatar} alt={author.name} /><AvatarFallback><UserRound size={16} /></AvatarFallback></Avatar>
            <div className="min-w-0 flex-1 rounded-xl border border-border/60 bg-background p-3">
              <div className="flex items-center justify-between gap-2"><p className="text-xs font-semibold">{author.name}</p><span className="text-xs text-muted-foreground">{message.time}</span></div>
              {message.replyTo && <div className="mt-2 rounded-lg border-r-2 border-brand/50 bg-brand/5 p-2"><p className="text-xs font-medium text-brand">{message.replyTo.name}</p><p className="mt-1 line-clamp-2 break-words text-xs text-muted-foreground">{message.replyTo.text}</p></div>}
              <p className="mt-2 whitespace-pre-wrap break-words text-sm leading-relaxed">{message.text}</p>
              <Button variant="ghost" disabled={locked} onClick={() => { setReply({ id, name: author.name, text: message.text }); focusComposer(); }} className="mt-1 h-7 px-1 text-xs text-brand"><Reply size={13} /> پاسخ</Button>
            </div>
          </div>;
        })}
        {!messages.length && <p className="py-8 text-center text-xs text-muted-foreground">اولین پیام را برای این درخواست ثبت کنید.</p>}<div ref={bottom} />
      </div>
      <div className="shrink-0 space-y-2">
        {reply && <div className="flex items-center gap-2 rounded-lg border-r-2 border-brand bg-brand/5 p-2"><Reply size={14} className="text-brand" /><div className="min-w-0 flex-1"><p className="text-xs font-medium text-brand">پاسخ به {reply.name}</p><p className="truncate text-xs text-muted-foreground">{reply.text}</p></div><Button variant="ghost" size="icon" aria-label="لغو پاسخ" onClick={() => setReply(null)} className="size-7"><X size={13} /></Button></div>}
        <div className="flex items-end gap-2"><Textarea id={`chat-input-${invoice.id}`} aria-label="متن پیام" disabled={locked} maxLength={4000} value={text} onChange={e => setText(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); send(); } }} placeholder={locked ? 'گفت‌وگو در حالت فقط مشاهده است' : 'پیام بنویسید…'} className="h-16 min-h-16 field-sizing-fixed rounded-xl bg-background" /><Button disabled={locked || !text.trim()} aria-label="ارسال پیام" onClick={send} className="h-10 rounded-xl bg-brand text-white hover:bg-brand/90"><Send size={16} /></Button></div>
        <p className="text-xs text-muted-foreground">Enter: ارسال · Shift + Enter: خط جدید</p>
      </div>
    </DialogContent>
  </Dialog>;
}
