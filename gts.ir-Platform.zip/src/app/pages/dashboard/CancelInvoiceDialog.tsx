import { useEffect, useState } from 'react';
import { Button } from '../../components/ui/button';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';

const reasons = ['انصراف مشتری', 'درخواست تکراری', 'عدم امکان تأمین کالا', 'اطلاعات درخواست نامعتبر', 'سایر'];
export default function CancelInvoiceDialog({ open, onOpenChange, disabled, onConfirm }: {
  open: boolean; onOpenChange: (open: boolean) => void; disabled: boolean; onConfirm: (reason: string, explanation: string) => void;
}) {
  const [reason, setReason] = useState('');
  const [explanation, setExplanation] = useState('');
  useEffect(() => { if (open) { setReason(''); setExplanation(''); } }, [open]);
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent dir="rtl" className="rounded-2xl">
    <DialogHeader className="text-right sm:text-right"><DialogTitle>لغو پیش‌فاکتور</DialogTitle><DialogDescription>دلیل و توضیح لغو ثبت می‌شوند؛ فاکتور حذف نمی‌شود و به فهرست لغوشده‌ها می‌رود.</DialogDescription></DialogHeader>
    <div className="space-y-2"><Label htmlFor="cancel-reason">دلیل لغو <span className="text-destructive">*</span></Label><Select value={reason} onValueChange={setReason} disabled={disabled}><SelectTrigger id="cancel-reason" className="w-full rounded-xl"><SelectValue placeholder="دلیل لغو را انتخاب کنید" /></SelectTrigger><SelectContent dir="rtl">{reasons.map(value => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select></div>
    <div className="space-y-2"><Label htmlFor="cancel-explanation">توضیحات لغو <span className="text-destructive">*</span></Label><Textarea id="cancel-explanation" disabled={disabled} value={explanation} maxLength={2000} onChange={e => setExplanation(e.target.value)} aria-required placeholder="علت لغو را برای همکاران توضیح دهید…" className="min-h-24 rounded-xl bg-background" /><p className="text-xs text-muted-foreground">تکمیل توضیحات برای همه دلایل، از جمله «سایر»، الزامی است.</p></div>
    <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button><Button variant="destructive" disabled={disabled || !reason || !explanation.trim()} onClick={() => { if (!disabled && reason && explanation.trim()) onConfirm(reason, explanation.trim()); }}>تأیید لغو فاکتور</Button></div>
  </DialogContent></Dialog>;
}
