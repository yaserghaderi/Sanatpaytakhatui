import { useState } from 'react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  TrendingUp, TrendingDown, ShoppingCart, Users, Package,
  Warehouse, AlertTriangle, ArrowUpRight, ArrowDownRight,
  Clock, CheckCircle, XCircle, Zap, BarChart3
} from 'lucide-react';

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

// ── Mock data ──────────────────────────────────────────────────────────────────

const salesTrend = [
  { month: 'دی', sales: 285, profit: 82, orders: 34 },
  { month: 'بهم', sales: 320, profit: 95, orders: 41 },
  { month: 'اسف', sales: 198, profit: 55, orders: 25 },
  { month: 'فرو', sales: 410, profit: 128, orders: 56 },
  { month: 'ارد', sales: 380, profit: 112, orders: 49 },
  { month: 'خرد', sales: 520, profit: 162, orders: 68 },
  { month: 'تیر', sales: 480, profit: 148, orders: 62 },
  { month: 'مرد', sales: 340, profit: 98, orders: 44 },
  { month: 'شهر', sales: 390, profit: 115, orders: 51 },
  { month: 'مهر', sales: 445, profit: 138, orders: 58 },
  { month: 'آبا', sales: 510, profit: 160, orders: 66 },
  { month: 'آذر', sales: 468, profit: 145, orders: 60 },
];

const topProducts = [
  { name: 'شیر توپی برنجی', sales: 312, revenue: 57720 },
  { name: 'پمپ استخر ۱HP', sales: 234, revenue: 198900 },
  { name: 'لوله PE100', sales: 203, revenue: 37555 },
  { name: 'فیلتر شنی', sales: 167, revenue: 308950 },
  { name: 'چسب PVC', sales: 145, revenue: 20300 },
];

const categoryShare = [
  { name: 'شیرآلات', value: 28, color: '#156394' },
  { name: 'استخر و جکوزی', value: 24, color: '#F2B524' },
  { name: 'اتصالات پلیمری', value: 18, color: '#10b981' },
  { name: 'پمپ و موتور', value: 15, color: '#8b5cf6' },
  { name: 'سایر', value: 15, color: '#e5e7eb' },
];

const alerts = [
  { type: 'danger', icon: AlertTriangle, text: 'شیر توپی برنجی ۱/۲" — موجودی: ۳ عدد', action: 'سفارش مجدد' },
  { type: 'warn', icon: Clock, text: 'پیش‌فاکتور آقای رضایی — ۴۸ ساعت بدون پاسخ', action: 'پیگیری' },
  { type: 'info', icon: Zap, text: 'اتصال حسابداری — آخرین سینک: ۱۵ دقیقه پیش', action: 'جزئیات' },
  { type: 'success', icon: CheckCircle, text: '۳ سفارش آماده ارسال', action: 'مشاهده' },
];

const recentOrders = [
  { id: '۱۴۰۳-۱۲۸', customer: 'مهندس احمدی', items: 5, amount: 4500000, status: 'در حال پردازش' },
  { id: '۱۴۰۳-۱۲۷', customer: 'شرکت ساختمانی پارس', items: 12, amount: 18200000, status: 'تایید شده' },
  { id: '۱۴۰۳-۱۲۶', customer: 'استخر فروشی رضایی', items: 3, amount: 27500000, status: 'ارسال شد' },
  { id: '۱۴۰۳-۱۲۵', customer: 'علی محمدی', items: 1, amount: 850000, status: 'تحویل داده شد' },
  { id: '۱۴۰۳-۱۲۴', customer: 'پروژه ساختمانی دماوند', items: 28, amount: 62000000, status: 'تایید شده' },
];

const statusColor: Record<string, string> = {
  'در حال پردازش': 'bg-yellow-100 text-yellow-700',
  'تایید شده': 'bg-blue-100 text-blue-700',
  'ارسال شد': 'bg-purple-100 text-purple-700',
  'تحویل داده شد': 'bg-green-100 text-green-700',
};

// ── Sub-components ─────────────────────────────────────────────────────────────

function KPICard({ label, value, sub, icon: Icon, trend, color }: {
  label: string; value: string; sub: string; icon: React.ElementType;
  trend?: { dir: 'up' | 'down'; val: string }; color: string;
}) {
  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center`} style={{ background: color + '18' }}>
          <Icon size={20} style={{ color }} />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full
            ${trend.dir === 'up' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-500'}`}>
            {trend.dir === 'up' ? <ArrowUpRight size={12} /> : <ArrowDownRight size={12} />}
            {trend.val}
          </div>
        )}
      </div>
      <p className="text-gray-500 text-xs mb-1">{label}</p>
      <p className="text-2xl text-gray-900 mb-1">{value}</p>
      <p className="text-xs text-gray-400">{sub}</p>
    </div>
  );
}

// ── Main Page ──────────────────────────────────────────────────────────────────

export function DashboardHome() {
  const [period, setPeriod] = useState<'day' | 'month' | 'year'>('month');

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-end">
        <div className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-xl p-1">
          {(['day', 'month', 'year'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-lg text-xs transition-all ${period === p ? 'bg-[#156394] text-white shadow-sm' : 'text-gray-500 hover:bg-gray-50'}`}>
              {p === 'day' ? 'امروز' : p === 'month' ? 'این ماه' : 'امسال'}
            </button>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        <KPICard label="فروش امروز" value="۱۲.۴ م" sub="تومان" icon={TrendingUp} color="#156394" trend={{ dir: 'up', val: '۱۸٪' }} />
        <KPICard label="فروش این ماه" value="۴۶۸ م" sub="تومان" icon={BarChart3} color="#F2B524" trend={{ dir: 'up', val: '۱۲٪' }} />
        <KPICard label="سود تقریبی" value="۱۴۵ م" sub="این ماه" icon={TrendingUp} color="#10b981" trend={{ dir: 'up', val: '۸٪' }} />
        <KPICard label="تعداد فاکتور" value={toPersianNumber(60)} sub="این ماه" icon={ShoppingCart} color="#8b5cf6" trend={{ dir: 'down', val: '۳٪' }} />
        <KPICard label="مشتریان فعال" value={toPersianNumber(124)} sub="ماه جاری" icon={Users} color="#ef4444" trend={{ dir: 'up', val: '۲۱٪' }} />
        <KPICard label="ارزش انبار" value="۲.۱ م" sub="میلیارد تومان" icon={Warehouse} color="#f97316" />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Sales trend */}
        <div className="xl:col-span-2 bg-white rounded-2xl border border-gray-100 p-5">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-sm text-gray-700">روند فروش ۱۲ ماه اخیر (میلیون تومان)</h2>
          </div>
          <div dir="ltr">
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={salesTrend}>
                <defs>
                  <linearGradient id="salesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#156394" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#156394" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#F2B524" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#F2B524" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} />
                <Tooltip contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 4px 24px rgba(0,0,0,0.1)', fontSize: 12 }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Area type="monotone" dataKey="sales" name="فروش" stroke="#156394" strokeWidth={2} fill="url(#salesGrad)" />
                <Area type="monotone" dataKey="profit" name="سود" stroke="#F2B524" strokeWidth={2} fill="url(#profitGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category pie */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <h2 className="text-sm text-gray-700 mb-4">سهم دسته‌بندی‌ها از فروش</h2>
          <div dir="ltr">
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={categoryShare} cx="50%" cy="50%" innerRadius={45} outerRadius={70}
                  paddingAngle={3} dataKey="value">
                  {categoryShare.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(val) => `${val}٪`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-2 mt-2">
            {categoryShare.map((c, i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: c.color }} />
                <span className="text-xs text-gray-600 flex-1">{c.name}</span>
                <span className="text-xs text-gray-500">{toPersianNumber(c.value)}٪</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Top products */}
        <div className="xl:col-span-2 bg-white rounded-2xl border border-gray-100 p-5">
          <h2 className="text-sm text-gray-700 mb-4">پرفروش‌ترین محصولات (این ماه)</h2>
          <div dir="ltr">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={topProducts} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                <YAxis type="category" dataKey="name" width={110} tick={{ fontSize: 11, fill: '#6b7280', textAnchor: 'start' }} />
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="sales" name="تعداد فروش" fill="#156394" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Alerts */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5">
          <h2 className="text-sm text-gray-700 mb-4">هشدارها و اعلان‌ها</h2>
          <div className="space-y-3">
            {alerts.map((a, i) => {
              const Icon = a.icon;
              const colors = {
                danger: 'border-red-200 bg-red-50 text-red-600',
                warn: 'border-yellow-200 bg-yellow-50 text-yellow-700',
                info: 'border-blue-200 bg-blue-50 text-blue-600',
                success: 'border-green-200 bg-green-50 text-green-600',
              }[a.type];
              return (
                <div key={i} className={`rounded-xl border p-3 ${colors}`}>
                  <div className="flex items-start gap-2">
                    <Icon size={14} className="mt-0.5 shrink-0" />
                    <p className="text-xs flex-1 leading-relaxed">{a.text}</p>
                  </div>
                  <button className="text-[10px] mt-1.5 underline mr-5">{a.action}</button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Recent orders */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="text-sm text-gray-700">آخرین سفارش‌ها</h2>
          <button className="text-xs text-[#156394] hover:underline">مشاهده همه</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-50 bg-gray-50/50">
                {['شماره سفارش', 'مشتری', 'آیتم‌ها', 'مبلغ', 'وضعیت'].map(h => (
                  <th key={h} className="px-5 py-3 text-right text-xs text-gray-500">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentOrders.map((o, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                  <td className="px-5 py-3.5 text-xs text-gray-500">{o.id}</td>
                  <td className="px-5 py-3.5 text-xs text-gray-800">{o.customer}</td>
                  <td className="px-5 py-3.5 text-xs text-gray-500">{toPersianNumber(o.items)} کالا</td>
                  <td className="px-5 py-3.5 text-xs text-[#156394]">{formatPrice(o.amount)} ت</td>
                  <td className="px-5 py-3.5">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] ${statusColor[o.status]}`}>{o.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
