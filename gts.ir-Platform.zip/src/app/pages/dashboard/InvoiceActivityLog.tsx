import { useState } from 'react';
import { ChevronDown, History, ArrowLeft, UserRound } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../../components/ui/collapsible';
import type { InvoiceActivity } from '../../data/invoiceActivity';

export default function InvoiceActivityLog({ activities = [] }: { activities?: InvoiceActivity[] }) {
  const [open, setOpen] = useState(false);
  return <Collapsible open={open} onOpenChange={setOpen} className="overflow-hidden rounded-2xl border border-border/60 bg-background">
    <CollapsibleTrigger asChild>
      <Button variant="ghost" className="h-auto w-full justify-between rounded-none px-4 py-3 text-right hover:bg-muted/30">
        <span className="flex items-center gap-3">
          <span className="flex size-9 items-center justify-center rounded-xl bg-brand/10 text-brand"><History size={17} /></span>
          <span className="flex flex-col gap-1"><span className="text-sm font-semibold">تاریخچه فعالیت‌ها</span><span className="text-xs font-normal text-muted-foreground">تغییرات و اقدامات ثبت‌شده روی فاکتور</span></span>
        </span>
        <span className="flex items-center gap-3"><span className="rounded-full bg-muted px-2 py-1 text-xs text-muted-foreground">{activities.length.toLocaleString('fa-IR')}</span><ChevronDown size={16} className={`transition-transform ${open ? 'rotate-180' : ''}`} /></span>
      </Button>
    </CollapsibleTrigger>
    <CollapsibleContent className="border-t border-border/60">
      {activities.length ? <div className="max-h-96 space-y-4 overflow-y-auto p-4">{[...activities].reverse().map(activity => <div key={activity.id} className="relative border-r-2 border-brand/15 pr-4">
        <span className="absolute top-1 -right-1.5 size-2.5 rounded-full bg-brand ring-4 ring-background" />
        <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-semibold">{activity.action}</span><span className="text-xs text-muted-foreground">{new Date(activity.at).toLocaleDateString('fa-IR')} · {new Date(activity.at).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span></div>
        <span className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground"><UserRound size={13} />{activity.actor}</span>
        <div className="mt-3 divide-y divide-border/50 rounded-xl border border-border/60 bg-muted/20 px-3">
          {activity.changes.map((change, index) => <div key={index} className="grid gap-2 py-2.5 text-xs sm:grid-cols-3">
            <span className="font-medium">{change.field}</span>
            <span className="flex min-w-0 items-start gap-2 sm:col-span-2"><span className="min-w-0 flex-1 whitespace-pre-wrap break-words text-muted-foreground">{change.before}</span><ArrowLeft size={13} className="mt-0.5 shrink-0 text-muted-foreground" /><span className="min-w-0 flex-1 whitespace-pre-wrap break-words text-brand">{change.after}</span></span>
          </div>)}
        </div>
      </div>)}</div> : <div className="flex flex-col items-center gap-2 py-8 text-muted-foreground"><History size={24} /><span className="text-xs">هنوز فعالیتی ثبت نشده است.</span></div>}
    </CollapsibleContent>
  </Collapsible>;
}
