import { useEffect, useState } from 'react';
import { Building2, Banknote, Wallet, MoreHorizontal, Plus, Trash2, Upload, Paperclip, Eye, X, Check, AlertCircle, ArrowUpLeft, Save } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import LocalizedNumberInput from '../../components/LocalizedNumberInput';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Checkbox } from '../../components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../components/ui/table';
import CustomerAccountDialog from './CustomerAccountDialog';
import JalaliDateSelect from './JalaliDateSelect';
import FormattedNumberInput from './FormattedNumberInput';
import { accountBalance, availableCredit, allocatedAmount, activeEntries, newPaymentEntry, parseAmount, paymentLabels, type CustomerAccount, type InvoiceSettlement, type PaymentEntry, type PaymentMethod } from '../../data/invoiceFinance';

const money = (value: number) => value.toLocaleString('fa-IR');
const methods = [{ id: 'bank', icon: Building2, hint: 'فیش و مبلغ واریز' }, { id: 'cheque', icon: Banknote, hint: 'مبلغ، سررسید و تصویر' }, { id: 'credit', icon: Wallet, hint: 'استفاده از اعتبار مشتری' }, { id: 'other', icon: MoreHorizontal, hint: 'مبلغ، توضیحات و سند' }] as const;
export default function InvoiceSettlementPanel({ total, buyer, account, value, onChange, onSalesConfirm, onFinanceConfirm, salesApproval, financeApproval, locked, error }: {
  total: number; buyer: string; account?: CustomerAccount; value: InvoiceSettlement;
  onChange: (value: InvoiceSettlement) => void; onSalesConfirm: () => void; onFinanceConfirm: () => void;
  salesApproval?: { by: string; at: string }; financeApproval?: { by: string; at: string }; locked: boolean; error: string;
}) {
  const [accountOpen, setAccountOpen] = useState(false);
  const [attachmentError, setAttachmentError] = useState('');
  const [preview, setPreview] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState('');
  useEffect(() => {
    if (!preview) { setPreviewUrl(''); return; }
    const url = URL.createObjectURL(preview); setPreviewUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [preview]);
  const entries = activeEntries(value);
  const allocated = allocatedAmount(value);
  const remaining = total - allocated;
  const creditUsed = entries.filter(entry => entry.method === 'credit').reduce((sum, entry) => sum + (parseAmount(entry.amount) || 0), 0);
  const creditAvailable = account ? availableCredit(account) : 0;
  const balance = account ? accountBalance(account) : 0;
  const update = (id: string, patch: Partial<PaymentEntry>) => {
    if (!locked) onChange({ ...value, entries: value.entries.map(entry => entry.id === id ? { ...entry, ...patch } : entry) });
  };
  const toggle = (method: PaymentMethod) => {
    if (locked) return;
    const enabled = value.enabled.includes(method);
    onChange({ enabled: enabled ? value.enabled.filter(item => item !== method) : [...value.enabled, method],
      entries: !enabled && !value.entries.some(entry => entry.method === method) ? [...value.entries, newPaymentEntry(method)] : value.entries });
  };
  const attach = (entry: PaymentEntry, file?: File) => {
    if (!file || locked) return;
    const image = /^(image\/(png|jpeg|webp))$/.test(file.type);
    if ((!image && !(entry.method !== 'cheque' && file.type === 'application/pdf')) || file.size > 10 * 1024 * 1024) {
      setAttachmentError('فایل باید تصویر PNG، JPG، WEBP یا PDF و حداکثر ۱۰ مگابایت باشد؛ برای چک فقط تصویر پذیرفته می‌شود.'); return;
    }
    setAttachmentError(''); update(entry.id, { attachment: file });
  };
  return <div className="space-y-3">
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-brand/15 bg-brand/5 p-3">
      <div className="flex items-center gap-3"><span className="flex size-8 items-center justify-center rounded-lg bg-background text-brand"><Wallet size={20} /></span><div><span className="block text-sm font-semibold">{buyer || 'حساب مشتری'}</span><span className="mt-1 block text-xs text-muted-foreground">وضعیت حساب: {account ? `${money(Math.abs(balance))} ریال ${balance > 0 ? 'بدهکار' : balance < 0 ? 'بستانکار' : 'تسویه'}` : 'اطلاعات در دسترس نیست'}</span></div></div>
      <div className="flex flex-wrap items-center gap-4"><div><span className="block text-xs text-muted-foreground">اعتبار قابل استفاده</span><span className="mt-1 block text-sm font-semibold text-brand">{account ? `${money(creditAvailable)} ریال` : '—'}</span></div><Button variant="outline" onClick={() => setAccountOpen(true)} className="h-9 rounded-lg bg-background text-xs text-brand">مشاهده حساب‌ها<ArrowUpLeft size={15} /></Button></div>
    </div>
    <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-sm font-semibold">روش تسویه</span><span className="text-xs text-muted-foreground">امکان انتخاب هم‌زمان چند روش · مبالغ به ریال</span></div>
    <div className="grid grid-cols-2 gap-2 lg:grid-cols-4">{methods.map(method => <Label key={method.id} className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2.5 ${value.enabled.includes(method.id) ? 'border-brand/35 bg-brand/5 text-brand' : 'border-border/60 bg-background'}`}><Checkbox disabled={locked} checked={value.enabled.includes(method.id)} onCheckedChange={() => toggle(method.id)} aria-label={paymentLabels[method.id]} /><method.icon size={15} className="shrink-0" /><span className="min-w-0"><span className="block text-xs font-semibold">{paymentLabels[method.id]}</span></span></Label>)}</div>
    <div className="grid items-start gap-3 lg:grid-cols-2">{methods.filter(method => value.enabled.includes(method.id)).map(method => <div key={method.id} className="overflow-hidden rounded-xl border border-border/70">
      <div className="flex items-center justify-between gap-2 border-b border-border/50 bg-muted/20 px-3 py-2.5"><span className="flex items-center gap-2 text-xs font-semibold"><method.icon size={16} className="text-brand" />{paymentLabels[method.id]}</span>{method.id !== 'credit' && <Button variant="ghost" disabled={locked} className="h-7 rounded-lg px-2 text-xs text-brand" onClick={() => onChange({ ...value, entries: [...value.entries, newPaymentEntry(method.id)] })}><Plus size={13} />{method.id === 'bank' ? 'افزودن واریز' : method.id === 'cheque' ? 'افزودن چک' : 'افزودن پرداخت'}</Button>}</div>
      <div className="divide-y divide-border/50">{value.entries.filter(entry => entry.method === method.id).map((entry, index, group) => <div key={entry.id} className="space-y-2 p-3">
        <div className="flex items-center justify-between"><span className="text-xs text-muted-foreground">{paymentLabels[method.id]} {method.id !== 'credit' ? (index + 1).toLocaleString('fa-IR') : ''}</span>{group.length > 1 && <Button variant="ghost" size="icon" disabled={locked} aria-label={`حذف ${paymentLabels[method.id]} ${index + 1}`} className="size-7 rounded-lg text-muted-foreground hover:text-destructive" onClick={() => onChange({ ...value, entries: value.entries.filter(item => item.id !== entry.id) })}><Trash2 size={13} /></Button>}</div>
        <div className="grid items-start gap-3 sm:grid-cols-2">
          <div className="space-y-1.5"><Label htmlFor={`amount-${entry.id}`} className="text-xs">مبلغ {paymentLabels[method.id]} <span className="text-muted-foreground">(ریال)</span></Label><LocalizedNumberInput id={`amount-${entry.id}`} aria-label={`مبلغ ${paymentLabels[method.id]} ${index + 1}`} disabled={locked} value={entry.amount} onValueChange={amount => update(entry.id, { amount })} onFocus={event => event.currentTarget.select()} placeholder="۰" dir="ltr" className="h-8 rounded-lg border-border bg-muted/20 text-right tabular-nums focus-visible:border-brand" /><div className="flex gap-2"><Button variant="outline" disabled={locked} className="h-6 rounded-md px-2 text-xs" onClick={() => update(entry.id, { amount: String(total) })}>کل فاکتور</Button><Button variant="ghost" disabled={locked} className="h-6 rounded-md bg-brand/5 px-2 text-xs text-brand" onClick={() => update(entry.id, { amount: String(Math.max(0, total - (allocated - (parseAmount(entry.amount) || 0)))) })}>باقی‌مانده</Button></div></div>
          {method.id === 'cheque' && <JalaliDateSelect id={`date-${entry.id}`} label={`چک ${index + 1}`} disabled={locked} value={entry.date} onChange={date => update(entry.id, { date })} />}
          {method.id !== 'credit' && <div className={`space-y-1.5 ${method.id === 'cheque' ? 'sm:col-span-2' : ''}`}><Label className="text-xs">{method.id === 'bank' ? 'فیش واریز' : method.id === 'cheque' ? 'تصویر چک' : 'سند پرداخت'}</Label><div className="flex min-h-8 items-center gap-2 rounded-lg border border-dashed border-border bg-muted/15 px-2 py-1"><Input id={`attachment-${entry.id}`} type="file" disabled={locked} accept={method.id === 'cheque' ? 'image/png,image/jpeg,image/webp' : 'image/png,image/jpeg,image/webp,application/pdf'} className="sr-only" onChange={event => { attach(entry, event.target.files?.[0]); event.target.value = ''; }} /><Label htmlFor={`attachment-${entry.id}`} className={`flex min-w-0 flex-1 items-center gap-2 text-xs ${locked ? 'cursor-default opacity-60' : 'cursor-pointer text-brand'}`}>{entry.attachment ? <Paperclip size={14} className="shrink-0" /> : <Upload size={14} className="shrink-0" />}<span className="truncate">{entry.attachment?.name ?? 'انتخاب فایل'}</span></Label>{entry.attachment && <><Button variant="ghost" size="icon" aria-label={`مشاهده پیوست ${paymentLabels[method.id]} ${index + 1}`} className="size-6 shrink-0" onClick={() => setPreview(entry.attachment!)}><Eye size={13} /></Button><Button variant="ghost" size="icon" disabled={locked} aria-label="حذف پیوست" className="size-6 shrink-0 text-muted-foreground" onClick={() => update(entry.id, { attachment: undefined })}><X size={13} /></Button></>}</div></div>}
          {method.id === 'credit' && <div className={`rounded-lg border p-3 text-xs leading-relaxed ${creditUsed > creditAvailable || !account ? 'border-destructive/20 bg-destructive/5 text-destructive' : 'border-brand/15 bg-brand/5 text-brand'}`}>اعتبار پس از این تسویه: <span className="font-semibold">{account ? `${money(Math.max(0, creditAvailable - creditUsed))} ریال` : 'اطلاعات اعتبار در دسترس نیست'}</span>{account && creditUsed > creditAvailable && <span className="mt-2 block">مبلغ واردشده بیشتر از اعتبار قابل استفاده است.</span>}</div>}
        </div>
        {method.id === 'other' && <div className="space-y-2"><Label htmlFor={`description-${entry.id}`} className="text-xs">توضیحات پرداخت</Label><Textarea id={`description-${entry.id}`} aria-label={`توضیحات سایر ${index + 1}`} disabled={locked} value={entry.description} onChange={event => update(entry.id, { description: event.target.value })} placeholder="شرح روش تسویه و جزئیات سند…" maxLength={2000} className="min-h-16 rounded-lg border-border bg-muted/20 focus-visible:border-brand" /></div>}
      </div>)}</div>
    </div>)}</div>
    {(attachmentError || error) && <div role="alert" className="flex items-start gap-2 rounded-xl bg-destructive/5 p-3 text-xs leading-relaxed text-destructive"><AlertCircle size={15} className="shrink-0" />{attachmentError || error}</div>}
    <div className="overflow-hidden rounded-xl border border-border/70"><div className="flex items-center justify-between border-b border-border/60 bg-muted/20 px-4 py-3"><span className="text-xs font-semibold">ریز تسویه فاکتور</span><span className="text-xs text-muted-foreground">{entries.length.toLocaleString('fa-IR')} پرداخت</span></div>
      {entries.length > 0 ? <Table className="text-xs"><TableHeader><TableRow className="[&>th]:text-right">{['روش', 'جزئیات', 'مبلغ (ریال)'].map(label => <TableHead key={label}>{label}</TableHead>)}</TableRow></TableHeader><TableBody>{entries.map(entry => <TableRow key={entry.id}><TableCell>{paymentLabels[entry.method]}</TableCell><TableCell className="max-w-56 truncate text-muted-foreground">{entry.method === 'cheque' ? `سررسید ${entry.date || '—'}` : entry.method === 'credit' ? 'از اعتبار مشتری' : entry.description || entry.attachment?.name || '—'}</TableCell><TableCell className="font-medium tabular-nums">{money(parseAmount(entry.amount) || 0)}</TableCell></TableRow>)}</TableBody></Table> : <div className="p-5 text-center text-xs text-muted-foreground">هنوز روش تسویه‌ای انتخاب نشده است.</div>}
      <div className="grid grid-cols-1 gap-3 border-t border-border/60 bg-muted/15 p-4 sm:grid-cols-3">{[{ label: 'مبلغ فاکتور', amount: total }, { label: 'جمع روش‌های تسویه', amount: allocated }, { label: remaining < 0 ? 'مازاد تسویه' : 'باقی‌مانده', amount: Math.abs(remaining) }].map((item, index) => <div key={item.label}><span className="block text-xs text-muted-foreground">{item.label}</span><span className={`mt-2 block text-sm font-semibold tabular-nums ${index === 2 ? remaining === 0 ? 'text-emerald-600' : 'text-destructive' : 'text-foreground'}`}>{money(item.amount)} <span className="text-xs font-normal">ریال</span></span></div>)}</div>
    </div>
    <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/60 pt-3">
      <span className={`flex items-center gap-1.5 text-xs ${remaining === 0 && entries.length > 0 ? 'text-emerald-600' : 'text-muted-foreground'}`}>{remaining === 0 && entries.length > 0 && <Check size={14} />}{remaining === 0 && entries.length > 0 ? 'تخصیص مبلغ کامل است.' : 'برای تأیید، باقی‌مانده باید صفر باشد.'}</span>
      <div className="flex w-full flex-wrap gap-2 sm:w-auto"><Button variant="outline" disabled={locked || Boolean(salesApproval)} onClick={onSalesConfirm} className="h-9 flex-1 rounded-lg text-xs text-brand sm:flex-none"><Save size={14} />{salesApproval ? 'عامل فروش تأیید کرد' : 'تأیید و ذخیره عامل فروش'}</Button><Button disabled={locked || !salesApproval || Boolean(financeApproval)} onClick={onFinanceConfirm} title={!salesApproval ? 'ابتدا عامل فروش تسویه را تأیید کند' : undefined} className="h-9 flex-1 rounded-lg bg-brand text-xs text-white hover:bg-brand/90 sm:flex-none"><Check size={14} />{financeApproval ? 'واحد مالی تأیید کرد' : 'تأیید و ذخیره واحد مالی'}</Button></div>
      {(salesApproval || financeApproval) && <div className="flex w-full flex-wrap gap-x-5 gap-y-2 text-xs text-muted-foreground">{[{ label: 'عامل فروش', value: salesApproval }, { label: 'واحد مالی', value: financeApproval }].filter(item => item.value).map(item => <span key={item.label} className="flex items-center gap-1.5"><Check size={12} className="text-emerald-600" />{item.label}: {item.value!.by} · {new Date(item.value!.at).toLocaleString('fa-IR', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>)}</div>}
    </div>
    <CustomerAccountDialog open={accountOpen} onOpenChange={setAccountOpen} buyer={buyer} account={account} />
    <Dialog open={Boolean(preview)} onOpenChange={open => { if (!open) setPreview(null); }}><DialogContent dir="rtl" className="max-h-[90dvh] overflow-y-auto rounded-2xl sm:max-w-2xl"><DialogHeader className="text-right sm:text-right"><DialogTitle>مشاهده پیوست</DialogTitle><DialogDescription className="break-all">{preview?.name}</DialogDescription></DialogHeader>{previewUrl && (preview?.type === 'application/pdf' ? <iframe title="سند پرداخت" src={previewUrl} className="h-96 w-full rounded-lg border border-border" /> : <img src={previewUrl} alt="پیوست تسویه" className="max-h-96 w-full rounded-lg object-contain" />)}</DialogContent></Dialog>
  </div>;
}
