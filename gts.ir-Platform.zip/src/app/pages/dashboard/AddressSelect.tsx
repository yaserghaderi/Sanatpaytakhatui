import { useState } from 'react';
import { Check, ChevronsUpDown } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '../../components/ui/popover';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '../../components/ui/command';

export default function AddressSelect({ id, label, value, options, disabled, onChange }: {
  id: string; label: string; value: string; options: string[]; disabled: boolean; onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const normalize = (text: string) => text.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/[آأإ]/g, 'ا').replace(/[\s\u200c]/g, '').toLowerCase();
  return <Popover modal open={open} onOpenChange={setOpen}>
    <PopoverTrigger asChild><Button id={id} variant="outline" role="combobox" aria-expanded={open} disabled={disabled} className="h-9 w-full justify-between rounded-lg px-2 text-xs font-normal"><span className="truncate">{value || `انتخاب ${label}`}</span><ChevronsUpDown size={12} className="shrink-0 opacity-50" /></Button></PopoverTrigger>
    <PopoverContent dir="rtl" align="start" className="w-64 p-0"><Command filter={(option, search) => normalize(option).includes(normalize(search)) ? 1 : 0}><CommandInput aria-label={`جستجوی ${label}`} placeholder={`جستجوی ${label}…`} /><CommandList><CommandEmpty>نتیجه‌ای پیدا نشد.</CommandEmpty><CommandGroup>{Array.from(new Set([...options, ...(value ? [value] : [])])).map(option => <CommandItem key={option} value={option} onSelect={() => { onChange(option); setOpen(false); }} className="text-xs"><Check size={12} className={value === option ? 'opacity-100' : 'opacity-0'} />{option}</CommandItem>)}</CommandGroup></CommandList></Command></PopoverContent>
  </Popover>;
}
