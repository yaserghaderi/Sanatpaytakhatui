import { useEffect, useState } from 'react';
import { Search, Plus, Star, FileText, Image, Mic, Sparkles, ArrowUpLeft, Trash2, ReceiptText, Check, Clock, Package, Wallet, Truck, UserRound, X, SlidersHorizontal, LoaderCircle, Eye, KeyRound } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar';
import { currentStaff, demoEditor } from '../../data/staff';
import CreateInvoiceDialog, { type InvoiceSubmission } from './CreateInvoiceDialog';
import InvoiceDetailDialog from './InvoiceDetailDialog';
import { recordInvoiceActivity, type InvoiceActivity } from '../../data/invoiceActivity';
import { sampleInvoiceActivities } from '../../data/sampleInvoiceActivities';
import { sampleCustomerAccount, type CustomerAccount, type InvoiceSettlement, type SettlementApprovals } from '../../data/invoiceFinance';

type Stage = 'sales' | 'finance' | 'warehouse' | 'supply';
type StageStatus = 'done' | 'pending' | 'waiting';
export type InvoiceLine = { id: string; name: string; code: string; specs: string; qty: number; price: number; cost: number; note: string; aiText: string; unit?: string; discount?: number; status?: 'priced' | 'unpriced' | 'unmatched' };
export type Invoice = {
  id: number; buyer: string; phone: string; creator: string; date: string; time: string;
  amount: number; file: 'pdf' | 'image' | 'voice' | 'manual'; matched: number; count: number;
  starred: boolean; mine: boolean; delivery: 'none' | 'sent' | 'delivered'; cancelled: boolean;
  stages: Record<Stage, StageStatus>; products: string[];
  analysis?: { phase: 'reading' | 'detecting' | 'matching'; progress: number };
  editor?: { name: string; avatar?: string };
  submission?: InvoiceSubmission;
  lines?: InvoiceLine[];
  address?: { province: string; city: string; street: string; postal: string };
  discount?: number;
  discountCategory?: string;
  customerType?: string;
  official?: boolean;
  settlement?: InvoiceSettlement;
  settlementApprovals?: SettlementApprovals;
  customerAccount?: CustomerAccount;
  salesCommissions?: { staffId: string; rate: number }[];
  messages?: { id?: string; text: string; time: string; author?: { name: string; avatar?: string }; replyTo?: { id: string; name: string; text: string } }[];
  cancellation?: { reason: string; explanation: string; by: string; at: string };
  history?: string[];
  activities?: InvoiceActivity[];
};
const fa = (value: number | string) => String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);
const money = (value: number) => value.toLocaleString('fa-IR');
const stages = [
  { key: 'sales' as const, label: 'فروش', icon: ReceiptText },
  { key: 'finance' as const, label: 'مالی', icon: Wallet },
  { key: 'warehouse' as const, label: 'انبار', icon: Package },
  { key: 'supply' as const, label: 'تأمین', icon: Truck },
];
const initialInvoices: Invoice[] = [
  { id: 116, buyer: 'سید مهدی ثقه', phone: '09368442227', creator: 'یوسف اسکندرزاده', date: '۱۴۰۵/۰۷/۲۱', time: '۱۵:۵۲', amount: 128500000, file: 'image', matched: 0, count: 8, starred: false, mine: true, delivery: 'none', cancelled: false, stages: { sales: 'pending', finance: 'waiting', warehouse: 'waiting', supply: 'waiting' }, products: ['شیر توپی برنجی', 'لوله پلی‌اتیلن', 'اتصال سه‌راه'] },
  { id: 115, buyer: 'شرکت ساختمانی پارس', phone: '02144445555', creator: 'یوسف اسکندرزاده', date: '۱۴۰۵/۰۷/۲۱', time: '۱۵:۵۱', amount: 81500000, file: 'pdf', matched: 5, count: 8, starred: true, mine: true, delivery: 'none', cancelled: false, stages: { sales: 'done', finance: 'pending', warehouse: 'waiting', supply: 'waiting' }, products: ['فلنج گلودار DN100', 'لرزه‌گیر DN80'] },
  { id: 114, buyer: 'یاسر قادری', phone: '09309540066', creator: 'یاسر قادری', date: '۱۴۰۵/۰۷/۲۰', time: '۱۲:۴۶', amount: 303900000, file: 'voice', matched: 1, count: 1, starred: false, mine: false, delivery: 'none', cancelled: false, stages: { sales: 'done', finance: 'done', warehouse: 'done', supply: 'pending' }, products: ['پمپ سیرکولاتور صنعتی'] },
  { id: 111, buyer: 'داوود محمدنژاد', phone: '09123982028', creator: 'داوود محمدنژاد', date: '۱۴۰۵/۰۷/۱۹', time: '۱۲:۳۲', amount: 2033320037, file: 'pdf', matched: 31, count: 54, starred: true, mine: true, delivery: 'sent', cancelled: false, stages: { sales: 'done', finance: 'done', warehouse: 'done', supply: 'waiting' }, products: ['لوله PE100', 'شیر کشویی فلنجی', 'زانو PVC'] },
  { id: 110, buyer: 'استخر فروشی رضایی', phone: '09351234567', creator: 'داوود محمدنژاد', date: '۱۴۰۵/۰۷/۱۹', time: '۱۲:۱۴', amount: 100225000, file: 'image', matched: 5, count: 5, starred: false, mine: false, delivery: 'none', cancelled: false, stages: { sales: 'done', finance: 'done', warehouse: 'pending', supply: 'waiting' }, products: ['فیلتر شنی استخر', 'پمپ استخر'] },
  { id: 109, buyer: 'مهندس احمدی', phone: '09123456789', creator: 'یوسف اسکندرزاده', date: '۱۴۰۵/۰۷/۱۸', time: '۱۰:۲۵', amount: 55750000, file: 'pdf', matched: 4, count: 4, starred: false, mine: true, delivery: 'delivered', cancelled: false, stages: { sales: 'done', finance: 'done', warehouse: 'done', supply: 'done' }, products: ['شیر توپی برنجی', 'لوله PE100'] },
  { id: 108, buyer: 'پروژه دماوند', phone: '02188889999', creator: 'یاسر قادری', date: '۱۴۰۵/۰۷/۱۷', time: '۰۹:۱۰', amount: 431500000, file: 'image', matched: 7, count: 10, starred: false, mine: false, delivery: 'delivered', cancelled: false, stages: { sales: 'done', finance: 'done', warehouse: 'done', supply: 'done' }, products: ['سه‌راه صنعتی', 'زانو PVC'] },
  { id: 107, buyer: 'حسن محمدپور', phone: '09181234321', creator: 'یوسف اسکندرزاده', date: '۱۴۰۵/۰۷/۱۶', time: '۱۶:۴۰', amount: 9500000, file: 'voice', matched: 2, count: 3, starred: false, mine: true, delivery: 'none', cancelled: true, stages: { sales: 'waiting', finance: 'waiting', warehouse: 'waiting', supply: 'waiting' }, products: ['عایق لوله'] },
];
const filters = [
  { id: 'mine', label: 'کارتابل من' }, { id: 'all', label: 'همه فاکتورها' },
  { id: 'starred', label: 'ستاره‌دارها' }, ...stages.map(s => ({ id: s.key, label: s.label })),
  { id: 'sent', label: 'ارسال‌شده' }, { id: 'delivered', label: 'تحویل‌شده' }, { id: 'cancelled', label: 'لغوشده' },
];
const matchesFilter = (invoice: Invoice, filter: string) => {
  if (filter === 'all') return true;
  if (filter === 'mine') return invoice.mine && !invoice.cancelled;
  if (filter === 'starred') return invoice.starred;
  if (filter === 'cancelled') return invoice.cancelled;
  if (filter === 'sent' || filter === 'delivered') return invoice.delivery === filter && !invoice.cancelled;
  return !invoice.cancelled && invoice.stages[filter as Stage] === 'pending';
};
const statusLabel = { done: 'تأیید شده', pending: 'نیازمند اقدام', waiting: 'در انتظار' };
const fileConfig = { pdf: { icon: FileText, label: 'فایل PDF' }, image: { icon: Image, label: 'تصویر' }, voice: { icon: Mic, label: 'پیام صوتی' }, manual: { icon: ReceiptText, label: 'پیش‌فاکتور دستی' } };

function EditorAvatar({ editor }: { editor: NonNullable<Invoice['editor']> }) {
  return <span className="relative flex size-8 shrink-0 items-center justify-center">
    <span className="absolute inset-0 animate-spin rounded-full border-2 border-brand/20 border-t-brand motion-reduce:animate-none" />
    <Avatar className="size-6"><AvatarImage src={editor.avatar} alt={editor.name} /><AvatarFallback className="bg-brand/10 text-brand"><UserRound size={14} /></AvatarFallback></Avatar>
  </span>;
}

export function DashboardOrders({ kind = 'sales' }: { kind?: 'sales' | 'purchase' }) {
  const [invoices, setInvoices] = useState<Invoice[]>(() => initialInvoices.map(i => ({
    ...i,
    activities: sampleInvoiceActivities(i),
    customerAccount: sampleCustomerAccount(i.id),
    ...(i.id === 116 ? { analysis: { phase: 'reading' as const, progress: 0 } } : {}),
    ...(i.id === 111 ? { editor: demoEditor } : {}),
  })));
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('newest');
  const [detail, setDetail] = useState<Invoice | null>(null);
  const [deleting, setDeleting] = useState<Invoice | null>(null);
  const [accessInvoice, setAccessInvoice] = useState<Invoice | null>(null);
  const [readOnly, setReadOnly] = useState(false);
  const [requested, setRequested] = useState<number[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  // Preview-only simulation. Real analysis events and edit locks must come from the server.
  useEffect(() => {
    const timer = window.setInterval(() => setInvoices(current => current.map(i => {
      if (!i.analysis) return i;
      const { phase, progress } = i.analysis;
      if (phase === 'reading') return progress < 2 ? { ...i, analysis: { phase, progress: progress + 1 } } : { ...i, analysis: { phase: 'detecting', progress: 0 } };
      if (phase === 'detecting') return progress < 2 ? { ...i, analysis: { phase, progress: progress + 1 } } : i.submission?.autoMatch === false ? { ...i, analysis: undefined } : { ...i, analysis: { phase: 'matching', progress: 0 } };
      if (progress >= i.count) return { ...i, matched: i.count, analysis: undefined };
      return { ...i, matched: progress + 1, analysis: { phase, progress: progress + 1 } };
    })), 1400);
    return () => window.clearInterval(timer);
  }, []);
  const openInvoice = (invoice: Invoice) => {
    if (invoice.analysis) return;
    if (invoice.editor) { setAccessInvoice(invoice); return; }
    setReadOnly(false);
    setDetail(invoice);
  };
  const normalize = (text: string) => text.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).toLowerCase().trim();
  const filtered = invoices.filter(i => matchesFilter(i, filter) && normalize([i.id, i.buyer, i.phone, i.creator, ...i.products].join(' ')).includes(normalize(search)))
    .sort((a, b) => sort === 'amount' ? b.amount - a.amount : sort === 'match' ? (a.matched / Math.max(a.count, 1)) - (b.matched / Math.max(b.count, 1)) : b.id - a.id);
  const toggleStar = (id: number) => setInvoices(current => current.map(i => i.id === id ? recordInvoiceActivity(i, { ...i, starred: !i.starred }) : i));
  useEffect(() => { setPage(1); }, [filter, search, sort, pageSize]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const pageInvoices = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const addSubmission = (submission: InvoiceSubmission) => {
    const id = Math.max(...invoices.map(i => i.id), 116) + 1;
    const now = new Date();
    const fileType = /\.pdf$/i.test(submission.file.name) ? 'pdf' : /\.(png|jpg|jpeg|webp)$/i.test(submission.file.name) ? 'image' : 'voice';
    const invoice: Invoice = {
      id, buyer: 'درخواست جدید · اطلاعات خریدار ثبت نشده', phone: '—', creator: currentStaff.name,
      date: now.toLocaleDateString('fa-IR'), time: now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      amount: 0, file: fileType, matched: 0, count: 8, starred: false, mine: true,
      delivery: 'none', cancelled: false, stages: { sales: 'pending', finance: 'waiting', warehouse: 'waiting', supply: 'waiting' },
      products: ['در انتظار بررسی اقلام'], analysis: { phase: 'reading', progress: 0 }, submission,
      activities: [{ id: crypto.randomUUID(), actor: currentStaff.name, at: now.toISOString(), action: 'ایجاد فاکتور فروش', changes: [{ field: 'فایل ارسالی', before: '—', after: submission.file.name }] }],
    };
    setInvoices(current => [invoice, ...current]);
    setFilter('all'); setSearch(''); setSort('newest'); setPage(1);
    return id;
  };
  const addManualInvoice = () => {
    const now = new Date();
    const invoice: Invoice = {
      id: Math.max(...invoices.map(i => i.id), 116) + 1,
      buyer: '', phone: '', creator: currentStaff.name,
      date: now.toLocaleDateString('fa-IR'), time: now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      amount: 0, file: 'manual', matched: 0, count: 0, starred: false, mine: true,
      delivery: 'none', cancelled: false,
      stages: { sales: 'pending', finance: 'waiting', warehouse: 'waiting', supply: 'waiting' },
      products: [], lines: [], discount: 0, discountCategory: 'manual',
      address: { province: '', city: '', street: '', postal: '' },
      salesCommissions: [], messages: [],
      activities: [{ id: crypto.randomUUID(), actor: currentStaff.name, at: now.toISOString(), action: 'ایجاد پیش‌فاکتور دستی', changes: [{ field: 'روش ثبت', before: '—', after: 'دستی' }] }],
    };
    setInvoices(current => [invoice, ...current]);
    setFilter('all'); setSearch(''); setSort('newest'); setPage(1);
    setReadOnly(false);
    setDetail(invoice);
  };

  return (
    <div className="mx-auto w-full min-w-0 max-w-screen-2xl space-y-3 p-2.5 sm:space-y-4 sm:p-4 md:p-6" dir="rtl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative min-w-0 w-full sm:w-auto sm:flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input aria-label="جستجوی فاکتورها" value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی فاکتور، مشتری یا کالا…" className="h-10 rounded-xl border-border/70 bg-background pr-9 pl-8 text-xs sm:text-sm" />
          {search && <Button variant="ghost" size="icon" aria-label="پاک کردن جستجو" onClick={() => setSearch('')} className="absolute left-1 top-1 size-8"><X size={14} /></Button>}
        </div>
        <div className="flex w-full gap-2 sm:w-auto">
          <Button onClick={() => setCreateOpen(true)} className="h-10 flex-1 gap-1 rounded-xl bg-brand px-2 text-xs text-white shadow-md shadow-brand/15 hover:bg-brand/90 sm:flex-none sm:gap-2 sm:px-4 sm:text-sm"><Sparkles size={17} /> پیش‌فاکتور هوشمند</Button>
          <Button variant="outline" onClick={addManualInvoice} className="h-10 flex-1 gap-1 rounded-xl border-brand/25 px-2 text-xs text-brand hover:bg-brand/5 hover:text-brand sm:flex-none sm:gap-2 sm:px-4 sm:text-sm"><Plus size={17} /> پیش‌فاکتور دستی</Button>
        </div>
      </div>

      <div className="flex min-w-0 items-center gap-2 rounded-xl border border-border/60 bg-background p-2 shadow-sm">
        <div className="scrollbar-hidden flex min-w-0 flex-1 gap-1 overflow-x-auto">
          {filters.map(f => <Button key={f.id} variant="ghost" onClick={() => setFilter(f.id)} aria-pressed={filter === f.id} className={`h-8 rounded-lg px-2 text-xs font-normal ${filter === f.id ? 'bg-brand text-white shadow-sm hover:bg-brand/90 hover:text-white' : 'text-muted-foreground hover:bg-muted'}`}>
            {f.id === 'starred' && <Star size={13} />}{f.label}<span className={`rounded-md px-1.5 py-0.5 text-xs ${filter === f.id ? 'bg-white/20' : 'bg-muted'}`}>{fa(invoices.filter(i => matchesFilter(i, f.id)).length)}</span>
          </Button>)}
        </div>
        <div className="shrink-0 border-r border-border/60 pr-2">
          <Select value={sort} onValueChange={setSort}>
            <SelectTrigger aria-label="مرتب‌سازی فاکتورها" className="h-8 w-28 gap-1 rounded-lg px-2 text-xs sm:w-36"><SlidersHorizontal size={13} className="hidden sm:block" /><SelectValue /></SelectTrigger>
            <SelectContent dir="rtl"><SelectItem value="newest">جدیدترین ابتدا</SelectItem><SelectItem value="amount">بیشترین مبلغ</SelectItem><SelectItem value="match">کمترین تطبیق</SelectItem></SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <p><span className="font-medium text-foreground">{fa(filtered.length)}</span> فاکتور در این نما</p>
        <p className="flex items-center gap-1.5" title="فیلتر واحدها: فاکتورهای نیازمند اقدام"><span className="size-1.5 rounded-full bg-amber-500" /><span className="sm:hidden">نیازمند اقدام</span><span className="hidden sm:inline">فیلتر واحدها: فاکتورهای نیازمند اقدام</span></p>
      </div>
      <div className="space-y-2">
        {pageInvoices.map(invoice => {
          const file = fileConfig[invoice.file];
          const percent = Math.round(invoice.matched / Math.max(invoice.count, 1) * 100);
          const processing = Boolean(invoice.analysis);
          return <div key={invoice.id} role="button" tabIndex={processing ? -1 : 0} aria-disabled={processing} aria-label={`باز کردن فاکتور ${fa(invoice.id)}`} aria-busy={processing}
            onClick={event => { if (!(event.target as HTMLElement).closest('button')) openInvoice(invoice); }}
            onKeyDown={event => { if (event.target === event.currentTarget && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); openInvoice(invoice); } }}
            className={`group rounded-xl border bg-background px-3 py-2.5 shadow-sm transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 ${processing ? 'cursor-wait border-brand/20 bg-brand/5' : 'cursor-pointer hover:border-brand/25 hover:shadow-md'} ${invoice.cancelled ? 'border-destructive/15' : 'border-border/60'}`}>
            <div className="grid grid-cols-12 items-center gap-x-2 gap-y-1.5 sm:flex sm:flex-wrap sm:gap-x-3 sm:gap-y-2">
              <div title={file.label} className="col-span-1 flex size-6 shrink-0 items-center justify-center rounded-lg border border-brand/10 bg-gradient-to-br from-brand/10 to-background text-brand sm:size-9"><file.icon className="size-4 sm:size-5" /></div>
              <div className="col-span-9 min-w-0 sm:flex-1">
                <div className="flex min-w-0 items-center gap-x-1.5 gap-y-1 sm:flex-wrap sm:gap-x-2">
                  <Button variant="link" disabled={processing} onClick={() => openInvoice(invoice)} className="h-auto shrink-0 p-0 text-xs font-semibold text-brand sm:text-sm"><span className="hidden sm:inline">فاکتور </span>#{fa(invoice.id)}</Button>
                  <span title={invoice.buyer} className="truncate text-xs font-medium sm:text-sm">{invoice.buyer || 'خریدار تعیین نشده'}</span>
                  {invoice.cancelled && <span className="rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive">لغوشده</span>}
                  {invoice.delivery !== 'none' && <span className="rounded-md bg-emerald-50 px-2 py-1 text-xs text-emerald-700">{invoice.delivery === 'sent' ? 'ارسال‌شده' : 'تحویل‌شده'}</span>}
                </div>
                <div className="mt-1 flex gap-x-2 gap-y-1 overflow-hidden whitespace-nowrap text-xs text-muted-foreground sm:flex-wrap sm:gap-x-3"><span dir="ltr">{fa(invoice.phone)}</span><span>{invoice.date}<span className="hidden sm:inline"> · {invoice.time}</span></span><span className="hidden sm:inline">{fa(invoice.count)} ردیف کالا</span></div>
              </div>
              <div className="col-span-12 row-start-2 flex min-w-0 items-center justify-between gap-2 text-left sm:mr-auto sm:block"><p className="shrink-0 text-xs font-semibold text-foreground sm:text-sm">{money(invoice.amount)} <span className="text-xs font-normal text-muted-foreground">ریال</span></p><p title={`ثبت توسط ${invoice.creator}`} className="flex min-w-0 items-center justify-end gap-1 text-xs text-muted-foreground sm:mt-1"><UserRound size={12} className="shrink-0" /><span className="truncate"><span className="hidden sm:inline">ثبت توسط </span>{invoice.creator}</span></p></div>
              {invoice.editor && <div className="col-span-12 flex items-center gap-1.5 text-xs text-brand"><EditorAvatar editor={invoice.editor} /><span className="flex gap-2 sm:block"><span className="block">{invoice.editor.name}</span><span className="block text-muted-foreground">در حال کار</span></span></div>}
              <Button variant="ghost" size="icon" aria-label={invoice.starred ? 'حذف از ستاره‌دارها' : 'ستاره‌دار کردن'} aria-pressed={invoice.starred} onClick={() => toggleStar(invoice.id)} className={`col-span-2 col-start-11 row-start-1 justify-self-end size-8 rounded-lg ${invoice.starred ? 'text-amber-500 hover:text-amber-600' : 'text-muted-foreground/50'}`}><Star size={17} fill={invoice.starred ? 'currentColor' : 'none'} /></Button>
            </div>
            <div className="mt-1.5 grid grid-cols-12 items-center gap-x-2 gap-y-1.5 border-t border-border/40 pt-1.5 sm:mt-2 sm:flex sm:flex-wrap sm:gap-x-3 sm:gap-y-2 sm:pt-2">
              <div className="col-span-12 grid grid-cols-4 gap-1 sm:flex sm:flex-1 sm:flex-wrap sm:gap-1.5">
                {stages.map(stage => {
                  const status = invoice.stages[stage.key];
                  return <div key={stage.key} title={`${stage.label}: ${statusLabel[status]}`} className={`flex min-w-0 items-center justify-center gap-0.5 rounded-md border px-1 py-1 text-xs sm:justify-start sm:gap-1 sm:px-2 ${status === 'done' ? 'border-emerald-200/70 bg-emerald-50/70 text-emerald-700' : status === 'pending' && !invoice.cancelled ? 'border-amber-200 bg-amber-50 text-amber-700' : 'border-border/50 bg-muted/30 text-muted-foreground'}`}><stage.icon size={12} /><span>{stage.label}</span>{status === 'done' ? <Check size={12} /> : status === 'pending' ? <Clock size={12} /> : <span className="text-muted-foreground/60">—</span>}</div>;
                })}
              </div>
              {invoice.file === 'manual' ? <div className="col-span-7 flex items-center gap-1.5 text-xs text-muted-foreground sm:min-w-36"><ReceiptText size={13} />ثبت دستی · {fa(invoice.count)} ردیف کالا</div> : <div className="col-span-7 min-w-0 sm:min-w-36">
                <p className="mb-1 flex items-center justify-between gap-3 text-xs" role="status"><span className="flex items-center gap-1 text-muted-foreground">{processing ? <LoaderCircle size={12} className="animate-spin motion-reduce:animate-none text-brand" /> : <Sparkles size={12} />}
                  {invoice.analysis?.phase === 'reading' ? 'خواندن فایل' : invoice.analysis?.phase === 'detecting' ? 'شناسایی اقلام' : invoice.analysis?.phase === 'matching' ? `تطبیق ${fa(invoice.count)} قلم` : <><span className="sm:hidden">تطبیق</span><span className="hidden sm:inline">تطبیق هوشمند</span></>}
                </span>{(!processing || invoice.analysis?.phase === 'matching') && <span className={`font-medium ${percent === 100 ? 'text-emerald-600' : 'text-brand'}`}>{fa(percent)}٪ <span className="font-normal text-muted-foreground">({fa(invoice.matched)}/{fa(invoice.count)})</span></span>}</p>
                <div role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={processing && invoice.analysis?.phase !== 'matching' ? undefined : percent} className="flex h-1.5 gap-0.5 overflow-hidden rounded-full bg-muted" aria-label="پیشرفت تطبیق کالاها">{Array.from({ length: 20 }, (_, i) => <span key={i} className={`flex-1 ${processing && invoice.analysis?.phase !== 'matching' ? 'animate-pulse bg-brand/30 motion-reduce:animate-none' : i < Math.round(percent / 5) ? percent === 100 ? 'bg-emerald-500' : 'bg-brand' : 'bg-muted'}`} />)}</div>
              </div>}
              <div className="col-span-5 flex items-center justify-end gap-0.5 sm:gap-1 sm:border-r sm:border-border/60 sm:pr-3">
                <Button variant="ghost" disabled={processing} onClick={() => openInvoice(invoice)} className="h-8 rounded-lg text-xs text-brand hover:bg-brand/5 hover:text-brand">جزئیات<ArrowUpLeft size={14} /></Button>
                <Button variant="ghost" disabled={processing || Boolean(invoice.editor)} size="icon" aria-label={`حذف فاکتور ${fa(invoice.id)}`} onClick={() => setDeleting(invoice)} className="size-8 rounded-lg text-muted-foreground/60 hover:bg-destructive/5 hover:text-destructive"><Trash2 size={14} /></Button>
              </div>
            </div>
          </div>;
        })}
        {!filtered.length && <div className="rounded-2xl border border-dashed border-border bg-background p-12 text-center"><Search className="mx-auto mb-4 size-8 text-muted-foreground/50" /><p className="text-sm font-medium">فاکتوری پیدا نشد</p><p className="mt-2 text-xs text-muted-foreground">عبارت جستجو یا فیلتر انتخابی را تغییر دهید.</p><Button variant="outline" className="mt-5 rounded-xl" onClick={() => { setSearch(''); setFilter('all'); }}>نمایش همه فاکتورها</Button></div>}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-border/60 bg-background px-4 py-3 text-xs text-muted-foreground">
        <div className="flex flex-wrap items-center gap-3">
          <span>نمایش {fa(filtered.length ? (currentPage - 1) * pageSize + 1 : 0)} تا {fa(Math.min(currentPage * pageSize, filtered.length))} از {fa(filtered.length)}</span>
          <Select value={String(pageSize)} onValueChange={value => setPageSize(Number(value))}><SelectTrigger aria-label="تعداد فاکتور در هر صفحه" className="h-8 w-36 rounded-lg text-xs"><SelectValue /></SelectTrigger><SelectContent dir="rtl">{[5, 10, 20, 50].map(size => <SelectItem key={size} value={String(size)}>{fa(size)} فاکتور در صفحه</SelectItem>)}</SelectContent></Select>
        </div>
        <div className="flex items-center gap-2"><Button variant="outline" className="h-8 rounded-lg text-xs" disabled={currentPage === 1} onClick={() => setPage(currentPage - 1)}>صفحه قبل</Button><span className="px-2">صفحه {fa(currentPage)} از {fa(totalPages)}</span><Button variant="outline" className="h-8 rounded-lg text-xs" disabled={currentPage === totalPages} onClick={() => setPage(currentPage + 1)}>صفحه بعد</Button></div>
      </div>

      <CreateInvoiceDialog open={createOpen} onOpenChange={setCreateOpen} onSubmit={addSubmission} />

      <Dialog open={Boolean(accessInvoice)} onOpenChange={open => { if (!open) setAccessInvoice(null); }}>
        <DialogContent dir="rtl" className="rounded-2xl">
          <DialogHeader className="text-right"><DialogTitle>این فاکتور در حال بررسی است</DialogTitle><DialogDescription>{accessInvoice?.editor?.name} در حال کار روی فاکتور #{fa(accessInvoice?.id ?? '')} است. برای جلوگیری از تداخل، نحوه ورود را انتخاب کنید.</DialogDescription></DialogHeader>
          {accessInvoice?.editor && <div className="flex items-center gap-3 rounded-xl bg-brand/5 p-3"><EditorAvatar editor={accessInvoice.editor} /><p className="text-sm text-brand">{accessInvoice.editor.name}<span className="block text-xs text-muted-foreground">دسترسی ویرایش فعال</span></p></div>}
          {accessInvoice && requested.includes(accessInvoice.id) && <p role="status" className="text-xs text-brand">درخواست دسترسی ثبت شد؛ تا تأیید کاربر، فقط مشاهده امکان‌پذیر است.</p>}
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => { setReadOnly(true); setDetail(accessInvoice); setAccessInvoice(null); }}><Eye size={15} /> فقط مشاهده</Button>
            <Button className="bg-brand text-white hover:bg-brand/90" disabled={Boolean(accessInvoice && requested.includes(accessInvoice.id))} onClick={() => { if (accessInvoice) setRequested(current => [...current, accessInvoice.id]); }}><KeyRound size={15} /> درخواست دسترسی از کاربر</Button>
          </div>
        </DialogContent>
      </Dialog>

      {detail && <InvoiceDetailDialog key={detail.id} invoice={detail} kind={kind} readOnly={readOnly} onClose={() => setDetail(null)}
        onUpdate={updated => {
          const logged = recordInvoiceActivity(detail, updated);
          setInvoices(current => current.map(i => i.id === logged.id ? logged : i));
          setDetail(logged);
        }}
        onRegenerate={() => {
          setInvoices(current => current.map(i => i.id === detail.id ? recordInvoiceActivity(i, { ...i, matched: 0, analysis: { phase: 'reading', progress: 0 } }) : i));
          setDetail(null);
        }} />}
      <Dialog open={Boolean(deleting)} onOpenChange={open => { if (!open) setDeleting(null); }}>
        <DialogContent dir="rtl" className="rounded-2xl"><DialogHeader className="text-right"><DialogTitle>حذف فاکتور #{fa(deleting?.id ?? '')}؟</DialogTitle><DialogDescription>این فاکتور از فهرست حذف می‌شود. این عمل قابل بازگشت نیست.</DialogDescription></DialogHeader><div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setDeleting(null)}>انصراف</Button><Button variant="destructive" onClick={() => { setInvoices(current => current.filter(i => i.id !== deleting?.id)); setDeleting(null); }}>حذف فاکتور</Button></div></DialogContent>
      </Dialog>
    </div>
  );
}

export default DashboardOrders;
