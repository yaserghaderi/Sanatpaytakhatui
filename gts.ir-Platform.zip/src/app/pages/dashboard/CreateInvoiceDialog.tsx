import { useEffect, useRef, useState } from 'react';
import { Upload, Mic, Square, FileText, X, Sparkles, CheckCircle, Headphones } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Textarea } from '../../components/ui/textarea';
import { Checkbox } from '../../components/ui/checkbox';
import { Label } from '../../components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';

export type InvoiceSubmission = { file: File; prompt: string; autoMatch: boolean };

export default function CreateInvoiceDialog({ open, onOpenChange, onSubmit }: {
  open: boolean; onOpenChange: (open: boolean) => void; onSubmit: (submission: InvoiceSubmission) => number;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [prompt, setPrompt] = useState('');
  const [autoMatch, setAutoMatch] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState<number | null>(null);
  const [recording, setRecording] = useState(false);
  const [starting, setStarting] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [audioUrl, setAudioUrl] = useState('');
  const documentInput = useRef<HTMLInputElement>(null);
  const audioInput = useRef<HTMLInputElement>(null);
  const recorder = useRef<MediaRecorder | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const active = useRef(open);
  const stopCapture = () => {
    if (recorder.current?.state === 'recording') recorder.current.stop();
    stream.current?.getTracks().forEach(track => track.stop());
    stream.current = null;
    setRecording(false);
  };
  useEffect(() => {
    active.current = open;
    if (!open) stopCapture();
    return () => { active.current = false; stream.current?.getTracks().forEach(track => track.stop()); };
  }, [open]);
  useEffect(() => {
    if (!recording) return;
    const timer = window.setInterval(() => setSeconds(s => s + 1), 1000);
    return () => window.clearInterval(timer);
  }, [recording]);
  useEffect(() => {
    if (!file || !(/\.(mp3|m4a|wav|webm|ogg|aac)$/i.test(file.name) || file.type.startsWith('audio/'))) { setAudioUrl(''); return; }
    const url = URL.createObjectURL(file);
    setAudioUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  const chooseFile = (selected?: File) => {
    if (!selected) return;
    setError('');
    if (!/\.(pdf|png|jpg|jpeg|webp|mp3|m4a|wav|webm|ogg|aac)$/i.test(selected.name)) { setError('فرمت فایل پشتیبانی نمی‌شود. PDF، تصویر یا فایل صوتی انتخاب کنید.'); return; }
    if (selected.size > 25 * 1024 * 1024) { setError('حجم فایل باید کمتر از ۲۵ مگابایت باشد.'); return; }
    if (!selected.size) { setError('فایل انتخاب‌شده خالی است.'); return; }
    setFile(selected); setSuccess(null);
  };
  const startRecording = async () => {
    setError(''); setStarting(true);
    try {
      if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) throw new Error('unsupported');
      const capture = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!active.current) { capture.getTracks().forEach(track => track.stop()); return; }
      stream.current = capture;
      const media = new MediaRecorder(capture);
      recorder.current = media;
      const chunks: BlobPart[] = [];
      media.ondataavailable = event => { if (event.data.size) chunks.push(event.data); };
      media.onstop = () => {
        capture.getTracks().forEach(track => track.stop());
        if (active.current) {
          const type = media.mimeType || 'audio/webm';
          chooseFile(new File(chunks, `recording-${Date.now()}.${type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm'}`, { type }));
        }
      };
      media.start(); setSeconds(0); setRecording(true); setSuccess(null);
    } catch { stream.current?.getTracks().forEach(track => track.stop()); setError('ضبط صدا شروع نشد. دسترسی میکروفون را بررسی کنید یا فایل صوتی آپلود کنید.'); }
    finally { setStarting(false); }
  };
  const submit = () => {
    if (!file || recording || starting) return;
    const id = onSubmit({ file, prompt: prompt.trim(), autoMatch });
    setSuccess(id); setFile(null); setPrompt(''); setError('');
    if (documentInput.current) documentInput.current.value = '';
    if (audioInput.current) audioInput.current.value = '';
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
    <DialogContent dir="rtl" className="scrollbar-hidden max-h-[90vh] overflow-y-auto gap-3 rounded-2xl border-border p-0 sm:max-w-4xl lg:max-w-5xl [&>button]:right-auto [&>button]:left-4">
      <DialogHeader className="flex-row items-center gap-3 border-b border-brand/10 bg-gradient-to-l from-brand/10 to-background px-5 py-4 pl-12 text-right sm:text-right">
        <span className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-brand text-white"><Sparkles size={18} /></span>
        <div className="min-w-0 space-y-1">
          <DialogTitle className="text-base text-right">ساخت پیش‌فاکتور هوشمند</DialogTitle>
          <DialogDescription className="text-right text-xs">لیست خرید را ارسال کنید؛ استخراج و تطبیق کالاها در پس‌زمینه انجام می‌شود.</DialogDescription>
        </div>
      </DialogHeader>
      <div className="space-y-4 px-5 pb-5 text-right">
        {success && <div role="status" className="flex gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-800"><CheckCircle size={20} className="shrink-0" /><div><p className="text-sm font-medium">درخواست #{success.toLocaleString('fa-IR')} به صف اضافه شد</p><p className="mt-1 text-xs">می‌توانید بدون بستن این پنجره، فایل بعدی را ارسال کنید.</p></div></div>}
        <div className="grid gap-3 sm:grid-cols-2">
          <div onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); if (!recording && !starting) chooseFile(e.dataTransfer.files[0]); }} className="flex min-h-40 flex-col items-center justify-center rounded-xl border border-dashed border-brand/30 bg-brand/5 p-5 text-center">
            <div className="flex items-center gap-2"><Upload className="size-5 text-brand" /><p className="text-sm font-medium">تصویر یا فایل PDF</p></div><p className="mt-1 text-xs text-muted-foreground">فایل را اینجا رها کنید یا انتخاب کنید</p>
            <Button variant="outline" disabled={recording || starting} onClick={() => documentInput.current?.click()} className="mt-3 h-8 rounded-lg border-brand/20 text-brand">انتخاب فایل</Button>
            <Input ref={documentInput} type="file" aria-label="انتخاب تصویر یا PDF" accept=".pdf,.png,.jpg,.jpeg,.webp" className="hidden" onChange={e => { chooseFile(e.target.files?.[0]); e.target.value = ''; }} />
          </div>
          <div onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); if (!recording && !starting) chooseFile(e.dataTransfer.files[0]); }} className="flex min-h-40 flex-col items-center justify-center rounded-xl border border-border bg-muted/30 p-5 text-center">
            <div className="flex items-center gap-2"><Headphones className="size-5 text-brand" /><p className="text-sm font-medium">لیست خرید صوتی</p></div><p className="mt-1 text-xs text-muted-foreground">{recording ? `در حال ضبط · ${seconds.toLocaleString('fa-IR')} ثانیه` : 'فایل صوتی انتخاب کنید یا همین‌جا ضبط کنید'}</p>
            <div className="mt-3 flex gap-2"><Button variant="outline" disabled={recording || starting} onClick={() => audioInput.current?.click()} className="h-8 rounded-lg">آپلود صدا</Button><Button disabled={starting} onClick={recording ? stopCapture : startRecording} className={`h-8 rounded-lg text-white ${recording ? 'bg-destructive hover:bg-destructive/90' : 'bg-brand hover:bg-brand/90'}`}>{recording ? <Square size={14} /> : <Mic size={14} />}{recording ? 'پایان ضبط' : starting ? 'اتصال…' : 'ضبط صدا'}</Button></div>
            <Input ref={audioInput} type="file" aria-label="انتخاب فایل صوتی" accept=".mp3,.m4a,.wav,.webm,.ogg,.aac,audio/*" className="hidden" onChange={e => { chooseFile(e.target.files?.[0]); e.target.value = ''; }} />
          </div>
        </div>
        <p className="text-xs text-muted-foreground">هر درخواست یک فایل · حداکثر ۲۵ مگابایت · PDF، JPG، PNG، WEBP، MP3، M4A، WAV، WEBM، OGG، AAC</p>
        {file && <div className="rounded-xl border border-brand/20 bg-brand/5 p-3"><div className="flex items-center gap-3"><FileText size={20} className="shrink-0 text-brand" /><div className="min-w-0 flex-1"><p className="truncate text-sm" dir="auto">{file.name}</p><p className="mt-1 text-xs text-muted-foreground">{(file.size / 1024 / 1024).toLocaleString('fa-IR', { maximumFractionDigits: 2 })} مگابایت</p></div><Button variant="ghost" size="icon" aria-label="حذف فایل انتخاب‌شده" onClick={() => setFile(null)}><X size={16} /></Button></div>{audioUrl && <audio controls src={audioUrl} className="mt-3 w-full" />}</div>}
        <div className="grid items-start gap-3 md:grid-cols-3">
          <div className="space-y-2 md:col-span-2"><Label htmlFor="invoice-prompt">راهنمای اختصاصی برای تحلیل <span className="text-xs text-muted-foreground">(اختیاری)</span></Label><Textarea id="invoice-prompt" value={prompt} maxLength={2000} onChange={e => setPrompt(e.target.value)} placeholder="مثلاً منظور از لوله سفید، لوله پنج‌لایه نیوپایپ است…" className="h-24 min-h-24 field-sizing-fixed rounded-xl border-border bg-background text-right" /><p className="text-xs text-muted-foreground">این توضیح فقط همراه همین درخواست نگهداری می‌شود.</p></div>
          <div className="flex items-start gap-2 rounded-xl border border-border bg-muted/20 p-3 md:mt-6"><Checkbox id="auto-match" checked={autoMatch} onCheckedChange={checked => setAutoMatch(checked === true)} className="mt-0.5 data-[state=checked]:bg-brand data-[state=checked]:border-brand" /><Label htmlFor="auto-match" className="flex-1 cursor-pointer"><span className="block">تطبیق خودکار با کالاهای سایت</span><span className="mt-1 block text-xs font-normal leading-relaxed text-muted-foreground">پیدا کردن کالاهای مشابه بعد از استخراج</span></Label></div>
        </div>
        {error && <p role="alert" className="rounded-xl bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}
        <div className="flex items-center gap-3 border-t border-border pt-3"><Button disabled={!file || recording || starting} onClick={submit} className="h-10 flex-1 rounded-xl bg-brand text-white hover:bg-brand/90"><Sparkles size={17} /> تحلیل و افزودن به صف</Button><Button variant="outline" onClick={() => onOpenChange(false)} className="h-10 rounded-xl">بستن</Button></div>

      </div>
    </DialogContent>
  </Dialog>;
}
