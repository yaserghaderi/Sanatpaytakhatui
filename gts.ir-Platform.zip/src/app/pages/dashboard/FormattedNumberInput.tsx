import { useEffect, useRef, useState, type ComponentProps } from 'react';
import { Input } from '../../components/ui/input';
import { groupedNumber, numericText } from '../../data/numberFormatting';

type Props = Omit<ComponentProps<typeof Input>, 'value' | 'onChange' | 'type'> & {
  value: number | string;
  onValueChange: (value: string) => void;
  allowDecimal?: boolean;
};

export default function FormattedNumberInput({ value, onValueChange, allowDecimal = false, onFocus, onBlur, onKeyDown, ...props }: Props) {
  const [draft, setDraft] = useState(() => numericText(value));
  const focused = useRef(false);
  useEffect(() => {
    const normalized = numericText(value);
    setDraft(current => focused.current && typeof value === 'number' && ((current === '' && value === 0) || Number(current) === value) ? current : normalized);
  }, [value]);
  return <Input {...props} type="text" inputMode={allowDecimal ? 'decimal' : 'numeric'} value={groupedNumber(draft)}
    onFocus={event => { focused.current = true; onFocus?.(event); }}
    onBlur={event => { focused.current = false; setDraft(numericText(value)); onBlur?.(event); }}
    onKeyDown={event => {
      onKeyDown?.(event);
      if (event.defaultPrevented) return;
      const field = event.currentTarget;
      const position = field.selectionStart;
      if (position == null || position !== field.selectionEnd) return;
      if (event.key === 'Backspace' && field.value[position - 1] === '٬') field.setSelectionRange(Math.max(0, position - 2), position);
      if (event.key === 'Delete' && field.value[position] === '٬') field.setSelectionRange(position, position + 2);
    }}
    onChange={event => {
      const field = event.currentTarget;
      const raw = field.value;
      const normalized = numericText(raw);
      if (!(allowDecimal ? /^\d*(?:\.\d*)?$/ : /^\d*$/).test(normalized)) return;
      const left = numericText(raw.slice(0, field.selectionStart ?? raw.length)).length;
      const formatted = groupedNumber(normalized);
      let position = 0;
      let digits = 0;
      while (position < formatted.length && digits < left) {
        if (formatted[position] !== '٬') digits++;
        position++;
      }
      setDraft(normalized);
      onValueChange(normalized);
      requestAnimationFrame(() => {
        if (field.isConnected && document.activeElement === field) field.setSelectionRange(position, position);
      });
    }} />;
}
