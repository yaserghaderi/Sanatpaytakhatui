import { useState } from 'react';
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, Cell, RadarChart, Radar, PolarGrid, PolarAngleAxis
} from 'recharts';
import { TrendingDown, AlertTriangle, Snowflake, Brain, Calendar, BarChart3 } from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};
const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

// ── Mock BI data ───────────────────────────────────────────────────────────────

const topProducts = [
  { name: 'شیر توپی', sales: 312, profit: 28, views: 3200, convRate: 9.7 },
  { name: 'پمپ استخر', sales: 234, profit: 42, views: 2800, convRate: 8.4 },
  { name: 'لوله PE100', sales: 203, profit: 18, views: 1900, convRate: 10.7 },
  { name: 'فیلتر شنی', sales: 167, profit: 55, views: 2100, convRate: 7.9 },
  { name: 'چسب PVC', sales: 145, profit: 22, views: 1200, convRate: 12.1 },
  { name: 'فلنج DN100', sales: 98, profit: 31, views: 1800, convRate: 5.4 },
];

const deadStock = [
  { name: 'لرزه‌گیر DN150', stock: 84, daysSinceSale: 112, blockedCapital: 40320000, risk: 'بالا' },
  { name: 'جت جکوزی ۱"', stock: 45, daysSinceSale: 98, blockedCapital: 71100000, risk: 'بالا' },
  { name: 'عایق ۴۰×۱۹mm', stock: 210, daysSinceSale: 75, blockedCapital: 11550000, risk: 'متوسط' },
  { name: 'بست U شکل ۶۳mm', stock: 380, daysSinceSale: 65, blockedCapital: 8360000, risk: 'متوسط' },
];

const seasonalData = {
  'پمپ استخر': [
    { month: 'فروردین', pct: 15 }, { month: 'اردیبهشت', pct: 22 }, { month: 'خرداد', pct: 28 },
    { month: 'تیر', pct: 32 }, { month: 'مرداد', pct: 18 }, { month: 'شهریور', pct: 12 },
    { month: 'مهر', pct: 6 }, { month: 'آبان', pct: 4 }, { month: 'آذر', pct: 5 },
    { month: 'دی', pct: 8 }, { month: 'بهمن', pct: 10 }, { month: 'اسفند', pct: 13 },
  ],
  'شیر توپی': [
    { month: 'فروردین', pct: 7 }, { month: 'اردیبهشت', pct: 10 }, { month: 'خرداد', pct: 12 },
    { month: 'تیر', pct: 9 }, { month: 'مرداد', pct: 8 }, { month: 'شهریور', pct: 9 },
    { month: 'مهر', pct: 8 }, { month: 'آبان', pct: 9 }, { month: 'آذر', pct: 10 },
    { month: 'دی', pct: 9 }, { month: 'بهمن', pct: 5 }, { month: 'اسفند', pct: 4 },
  ],
};

const aiInsights = [
  { type: 'forecast', icon: Brain, text: 'احتمالاً در ۳۰ روز آینده فروش پمپ استخر ۲۵٪ افزایش خواهد یافت.', color: '#156394' },
  { type: 'alert', icon: AlertTriangle, text: 'موجودی فعلی فیلتر شنی ۵۰۰mm تا ۱۸ روز دیگر به اتمام می‌رسد.', color: '#ef4444' },
  { type: 'opportunity', icon: TrendingDown, text: 'جت جکوزی ۱" — ۳۰۰۰ بازدید، ۱۸۵ درخواست قیمت، فقط ۱۳ فروش. احتمالاً قیمت رقابتی نیست.', color: '#F2B524' },
  { type: 'dead', icon: Snowflake, text: 'لرزه‌گیر DN150: ۱۱۲ روز بدون فروش، ۸۴ عدد موجودی. پیشنهاد: تخفیف فروش یا کمپین.', color: '#8b5cf6' },
];

const salesPeopleData = [
  { name: 'احمد رضایی', quotations: 28, sales: 18, convRate: 64, revenue: 124 },
  { name: 'مریم صادقی', quotations: 35, sales: 20, convRate: 57, revenue: 98 },
  { name: 'علی محمدی', quotations: 22, sales: 16, convRate: 72, revenue: 156 },
  { name: 'زهرا کریمی', quotations: 18, sales: 9, convRate: 50, revenue: 62 },
];

export function DashboardAnalytics() {
  const [selectedProduct, setSelectedProduct] = useState<keyof typeof seasonalData>('پمپ استخر');
  const [activeTab, setActiveTab] = useState<'products' | 'dead' | 'seasonal' | 'ai' | 'team'>('products');

  const tabs = [
    { key: 'products', label: 'تحلیل محصولات', icon: BarChart3 },
    { key: 'dead', label: 'کالاهای خوابیده', icon: Snowflake },
    { key: 'seasonal', label: 'تحلیل فصلی', icon: Calendar },
    { key: 'ai', label: 'هوش مصنوعی', icon: Brain },
    { key: 'team', label: 'عملکرد تیم', icon: BarChart3 },
  ] as const;

  return (
    <div className="p-6 space-y-5">
      {/* Tabs */}
      <div className="flex gap-2 flex-wrap">
        {tabs.map(t => {
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs transition-all border
                ${activeTab === t.key ? 'bg-[#156394] text-white border-[#156394] shadow-md' : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394] hover:text-[#156394]'}`}>
              <Icon size={13} />
              {t.label}
            </button>
          );
        })}
      </div>

      {/* Products Analysis */}
      {activeTab === 'products' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            <div className="bg-white rounded-2xl border border-gray-100 p-5">
              <h2 className="text-sm text-gray-700 mb-4">رتبه‌بندی فروش محصولات</h2>
              <div dir="ltr">
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={topProducts} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" horizontal={false} />
                    <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                    <YAxis type="category" dataKey="name" width={80} tick={{ fontSize: 11, fill: '#6b7280' }} />
                    <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                    <Bar dataKey="sales" name="فروش" radius={[0, 6, 6, 0]}>
                      {topProducts.map((_, i) => (
                        <Cell key={i} fill={i < 3 ? '#156394' : i < 5 ? '#1a7bb3' : '#93c5fd'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white rounded-2xl border border-gray-100 p-5">
              <h2 className="text-sm text-gray-700 mb-4">بازدید vs فروش (نرخ تبدیل)</h2>
              <div className="space-y-3">
                {topProducts.map((p, i) => (
                  <div key={i}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-600">{p.name}</span>
                      <span className="text-xs text-gray-500">نرخ تبدیل: {toPersianNumber(p.convRate.toFixed(1))}٪</span>
                    </div>
                    <div className="flex gap-2 items-center">
                      <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div className="bg-[#156394] h-full rounded-full" style={{ width: `${(p.sales / 312) * 100}%` }} />
                      </div>
                      <span className="text-[10px] text-gray-400 w-12 text-left">{toPersianNumber(p.views)} بازدید</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-5">
            <div className="flex items-start gap-3">
              <AlertTriangle size={16} className="text-yellow-600 mt-0.5 shrink-0" />
              <div>
                <p className="text-sm text-yellow-800 mb-1">تحلیل سایت + حسابداری</p>
                <p className="text-xs text-yellow-700">
                  <strong>جت جکوزی ۱"</strong> — ۳۰۰۰ بازدید ماهانه، ۱۸۵ درخواست قیمت، اما فقط ۱۳ فروش (نرخ تبدیل ۰.۴٪).
                  سیستم تشخیص می‌دهد: احتمالاً قیمت یا موجودی این محصول رقابتی نیست.
                  <strong> پیشنهاد: بررسی قیمت‌گذاری یا اجرای کمپین فروش.</strong>
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dead stock */}
      {activeTab === 'dead' && (
        <div className="space-y-4">
          <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 flex items-center gap-3">
            <Snowflake size={16} className="text-purple-500 shrink-0" />
            <p className="text-sm text-purple-700">کالاهایی که بیش از ۶۰ روز فروش نداشته‌اند و موجودی بالا دارند — سرمایه بلوکه شده.</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {deadStock.map((d, i) => (
              <div key={i} className="bg-white rounded-2xl border border-gray-100 p-5">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-sm text-gray-800">{d.name}</h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full ${d.risk === 'بالا' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-700'}`}>
                    ریسک {d.risk}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="bg-gray-50 rounded-xl p-2">
                    <p className="text-lg text-gray-900">{toPersianNumber(d.stock)}</p>
                    <p className="text-[10px] text-gray-500">عدد موجودی</p>
                  </div>
                  <div className="bg-red-50 rounded-xl p-2">
                    <p className="text-lg text-red-600">{toPersianNumber(d.daysSinceSale)}</p>
                    <p className="text-[10px] text-gray-500">روز بی‌فروش</p>
                  </div>
                  <div className="bg-orange-50 rounded-xl p-2">
                    <p className="text-sm text-orange-600">{formatPrice(d.blockedCapital / 1000000)}م</p>
                    <p className="text-[10px] text-gray-500">سرمایه بلوکه</p>
                  </div>
                </div>
                <button className="mt-3 w-full py-2 border border-purple-200 text-purple-600 rounded-xl text-xs hover:bg-purple-50 transition-colors">
                  پیشنهاد تخفیف و کمپین
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Seasonal */}
      {activeTab === 'seasonal' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            {Object.keys(seasonalData).map(k => (
              <button key={k} onClick={() => setSelectedProduct(k as any)}
                className={`px-4 py-2 rounded-xl text-xs border transition-all
                  ${selectedProduct === k ? 'bg-[#156394] text-white border-[#156394]' : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394]'}`}>
                {k}
              </button>
            ))}
          </div>
          <div className="bg-white rounded-2xl border border-gray-100 p-5">
            <h2 className="text-sm text-gray-700 mb-1">توزیع فروش ماهانه — {selectedProduct}</h2>
            <p className="text-xs text-gray-400 mb-4">بهترین زمان تأمین موجودی: ماه‌های قبل از پیک فروش</p>
            <div dir="ltr">
              <ResponsiveContainer width="100%" height={240}>
                <LineChart data={seasonalData[selectedProduct]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f3f4f6" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} unit="٪" />
                  <Tooltip formatter={(v) => `${v}٪`} contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                  <Line type="monotone" dataKey="pct" name="درصد فروش" stroke="#156394" strokeWidth={2.5}
                    dot={{ fill: '#156394', r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 p-3 bg-[#f0f7ff] rounded-xl border border-[#156394]/20">
              <p className="text-xs text-[#156394]">
                <strong>توصیه سیستم:</strong> برای {selectedProduct}، بهترین زمان خرید و تامین موجودی <strong>اردیبهشت</strong> است.
                موجودی‌گیری ۶ هفته قبل از پیک (تیر ماه) توصیه می‌شود.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* AI insights */}
      {activeTab === 'ai' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-[#0f2744] to-[#156394] rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-2">
              <Brain size={18} className="text-[#F2B524]" />
              <span className="text-white">تحلیل هوشمند کسب‌وکار</span>
            </div>
            <p className="text-white/70 text-sm">بر اساس ترکیب داده‌های سایت، حسابداری و CRM</p>
          </div>
          <div className="space-y-3">
            {aiInsights.map((ins, i) => {
              const Icon = ins.icon;
              return (
                <div key={i} className="bg-white rounded-2xl border border-gray-100 p-5 flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: ins.color + '18' }}>
                    <Icon size={18} style={{ color: ins.color }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-700 leading-relaxed">{ins.text}</p>
                  </div>
                  <button className="shrink-0 px-3 py-1.5 rounded-xl text-xs border border-gray-200 text-gray-600 hover:bg-gray-50 transition-colors">
                    اقدام
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Team performance */}
      {activeTab === 'team' && (
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
            <div className="px-5 py-4 border-b border-gray-100">
              <h2 className="text-sm text-gray-700">عملکرد کارشناسان فروش</h2>
            </div>
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50/70 text-xs text-gray-500 border-b border-gray-100">
                  {['رتبه', 'کارشناس', 'پیش‌فاکتورها', 'فروش موفق', 'نرخ تبدیل', 'درآمد (م)'].map(h => (
                    <th key={h} className="px-5 py-3 text-right">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...salesPeopleData].sort((a, b) => b.revenue - a.revenue).map((s, i) => (
                  <tr key={i} className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors">
                    <td className="px-5 py-4">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs
                        ${i === 0 ? 'bg-[#F2B524] text-gray-900' : i === 1 ? 'bg-gray-300 text-gray-700' : i === 2 ? 'bg-amber-600/30 text-amber-700' : 'bg-gray-100 text-gray-500'}`}>
                        {toPersianNumber(i + 1)}
                      </div>
                    </td>
                    <td className="px-5 py-4 text-sm text-gray-800">{s.name}</td>
                    <td className="px-5 py-4 text-xs text-gray-600">{toPersianNumber(s.quotations)}</td>
                    <td className="px-5 py-4 text-xs text-gray-600">{toPersianNumber(s.sales)}</td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                          <div className="h-full bg-[#156394] rounded-full" style={{ width: `${s.convRate}%` }} />
                        </div>
                        <span className="text-xs text-gray-600">{toPersianNumber(s.convRate)}٪</span>
                      </div>
                    </td>
                    <td className="px-5 py-4 text-xs text-[#156394]">{toPersianNumber(s.revenue)} م</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
