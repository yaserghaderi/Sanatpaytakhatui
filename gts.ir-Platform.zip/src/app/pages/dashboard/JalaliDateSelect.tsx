import { CalendarDays } from 'lucide-react';
import { Label } from '../../components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { jalaliMonthDays, normalizeDigits } from '../../data/invoiceFinance';

const months = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
const fa = (value: number) => value.toLocaleString('fa-IR', { useGrouping: false });
const currentYear = Number(new Intl.DateTimeFormat('en-US-u-ca-persian', { year: 'numeric' }).formatToParts(new Date()).find(part => part.type === 'year')?.value);

export default function JalaliDateSelect({ id, value, onChange, disabled, label }: {
  id: string; value: string; onChange: (value: string) => void; disabled: boolean; label: string;
}) {
  const [year = '', month = '', day = ''] = normalizeDigits(value).split(/[/-]/);
  const count = month ? jalaliMonthDays(Number(year) || currentYear, Number(month)) : 31;
  const years = [...new Set([...Array.from({ length: 16 }, (_, index) => currentYear - 5 + index), ...(year ? [Number(year)] : [])])].sort((a, b) => a - b);
  const change = (part: 'year' | 'month' | 'day', selected: string) => {
    const next = { year, month, day, [part]: selected };
    if (next.day && next.month && Number(next.day) > jalaliMonthDays(Number(next.year) || currentYear, Number(next.month))) next.day = '';
    onChange([next.year, next.month.padStart(2, '0'), next.day.padStart(2, '0')].join('/').replace(/\/00/g, '/'));
  };
  return <div className="space-y-1.5"><Label htmlFor={`${id}-day`} className="text-xs"><CalendarDays size={12} />سررسید شمسی</Label><div className="grid grid-cols-3 gap-1.5">
    <Select value={day ? String(Number(day)) : ''} onValueChange={selected => change('day', selected)} disabled={disabled}><SelectTrigger id={`${id}-day`} aria-label={`روز ${label}`} className="h-8 w-full min-w-0 rounded-lg border-border bg-muted/20 px-2 text-xs"><SelectValue placeholder="روز" /></SelectTrigger><SelectContent dir="rtl">{Array.from({ length: count }, (_, index) => index + 1).map(item => <SelectItem key={item} value={String(item)}>{fa(item)}</SelectItem>)}</SelectContent></Select>
    <Select value={month ? String(Number(month)) : ''} onValueChange={selected => change('month', selected)} disabled={disabled}><SelectTrigger aria-label={`ماه ${label}`} className="h-8 w-full min-w-0 rounded-lg border-border bg-muted/20 px-2 text-xs"><SelectValue placeholder="ماه" /></SelectTrigger><SelectContent dir="rtl">{months.map((name, index) => <SelectItem key={name} value={String(index + 1)}>{fa(index + 1)} · {name}</SelectItem>)}</SelectContent></Select>
    <Select value={year} onValueChange={selected => change('year', selected)} disabled={disabled}><SelectTrigger aria-label={`سال ${label}`} className="h-8 w-full min-w-0 rounded-lg border-border bg-muted/20 px-2 text-xs"><SelectValue placeholder="سال" /></SelectTrigger><SelectContent dir="rtl">{years.map(item => <SelectItem key={item} value={String(item)}>{fa(item)}</SelectItem>)}</SelectContent></Select>
  </div></div>;
}
