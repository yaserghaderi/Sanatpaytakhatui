import { useState } from 'react';
import { Search, Wallet, ArrowDownLeft, ArrowUpRight, ReceiptText } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Input } from '../../components/ui/input';
import { Button } from '../../components/ui/button';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '../../components/ui/table';
import { accountBalance, availableCredit, type CustomerAccount } from '../../data/invoiceFinance';

const money = (value: number) => value.toLocaleString('fa-IR');
export default function CustomerAccountDialog({ open, onOpenChange, buyer, account }: {
  open: boolean; onOpenChange: (value: boolean) => void; buyer: string; account?: CustomerAccount;
}) {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const balance = account ? accountBalance(account) : 0;
  let running = 0;
  const rows = (account?.transactions ?? []).map(entry => ({ ...entry, balance: running += entry.debit - entry.credit }));
  const filtered = rows.filter(entry => (filter === 'all' || (filter === 'debit' ? entry.debit > 0 : entry.credit > 0)) && `${entry.description} ${entry.reference} ${entry.date}`.includes(search.trim()));
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent dir="rtl" className="flex max-h-[90dvh] flex-col overflow-hidden rounded-2xl p-0 sm:max-w-4xl">
    <DialogHeader className="shrink-0 border-b border-border/60 p-5 text-right sm:text-right"><DialogTitle className="flex items-center gap-2"><Wallet size={19} className="text-brand" />صورت‌حساب مشتری</DialogTitle><DialogDescription>{buyer || 'خریدار تعیین نشده'} · مبالغ به ریال</DialogDescription></DialogHeader>
    <div className="min-h-0 space-y-4 overflow-y-auto p-4 sm:p-5">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[{ label: 'وضعیت حساب', value: account ? `${money(Math.abs(balance))} ${balance > 0 ? 'بدهکار' : balance < 0 ? 'بستانکار' : 'تسویه'}` : 'در دسترس نیست', icon: Wallet },
          { label: 'جمع بدهکار', value: account ? money(rows.reduce((sum, row) => sum + row.debit, 0)) : '—', icon: ArrowUpRight },
          { label: 'جمع بستانکار', value: account ? money(rows.reduce((sum, row) => sum + row.credit, 0)) : '—', icon: ArrowDownLeft }].map(item => <div key={item.label} className="rounded-xl border border-border/60 bg-muted/20 p-4"><span className="flex items-center gap-2 text-xs text-muted-foreground"><item.icon size={15} />{item.label}</span><span className="mt-3 block text-sm font-semibold">{item.value}</span></div>)}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-brand/5 px-4 py-3 text-xs text-brand"><span>سقف اعتبار: {account ? money(account.creditLimit) : '—'}</span><span>اعتبار قابل استفاده: <span className="font-semibold">{account ? money(availableCredit(account)) : '—'}</span></span></div>
      <div className="flex flex-wrap items-center justify-between gap-3"><div className="relative w-full sm:w-64"><Search size={15} className="absolute right-3 top-3 text-muted-foreground" /><Input aria-label="جستجو در تراکنش‌ها" value={search} onChange={event => setSearch(event.target.value)} placeholder="شرح، شماره سند یا تاریخ…" className="h-9 rounded-lg pr-9" /></div><div className="flex gap-1 rounded-lg bg-muted p-1">{[{ id: 'all', label: 'همه تراکنش‌ها' }, { id: 'debit', label: 'بدهکار' }, { id: 'credit', label: 'بستانکار' }].map(item => <Button key={item.id} variant="ghost" aria-pressed={filter === item.id} onClick={() => setFilter(item.id)} className={`h-7 rounded-md px-2 text-xs ${filter === item.id ? 'bg-background text-brand shadow-sm' : 'text-muted-foreground'}`}>{item.label}</Button>)}</div></div>
      <div className="overflow-hidden rounded-xl border border-border/60"><Table className="text-xs"><TableHeader><TableRow className="bg-muted/30 [&>th]:text-right">{['تاریخ', 'شرح تراکنش', 'شماره سند', 'بدهکار', 'بستانکار', 'مانده حساب'].map(label => <TableHead key={label}>{label}</TableHead>)}</TableRow></TableHeader><TableBody>{filtered.map(entry => <TableRow key={entry.id}><TableCell>{entry.date}</TableCell><TableCell>{entry.description}</TableCell><TableCell><span dir="ltr">{entry.reference}</span></TableCell><TableCell>{entry.debit ? money(entry.debit) : '—'}</TableCell><TableCell>{entry.credit ? money(entry.credit) : '—'}</TableCell><TableCell className="font-medium">{money(Math.abs(entry.balance))}<span className="mr-1 text-muted-foreground">{entry.balance > 0 ? 'بدهکار' : entry.balance < 0 ? 'بستانکار' : 'تسویه'}</span></TableCell></TableRow>)}</TableBody></Table>{!filtered.length && <div className="flex flex-col items-center gap-2 py-8 text-xs text-muted-foreground"><ReceiptText size={24} />{account ? 'تراکنشی پیدا نشد.' : 'اطلاعات حساب این مشتری در دسترس نیست.'}</div>}</div>
    </div>
    <div className="flex shrink-0 justify-end border-t border-border/60 px-5 py-3"><Button variant="outline" className="rounded-lg" onClick={() => onOpenChange(false)}>بستن صورت‌حساب</Button></div>
  </DialogContent></Dialog>;
}
