import { useEffect, useState } from 'react';
import { Star, MessageSquare, Ban, FileText, RotateCw, Download, X, ChevronDown, Check, ArrowRight, Plus, Sparkles, Save, Eye, ReceiptText, Wallet, Package, Truck, ArrowLeftRight, AlertCircle } from 'lucide-react';
import { Toaster, toast } from 'sonner';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import LocalizedNumberInput from '../../components/LocalizedNumberInput';
import { Label } from '../../components/ui/label';
import { Checkbox } from '../../components/ui/checkbox';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '../../components/ui/dialog';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '../../components/ui/collapsible';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../../components/ui/tabs';
import { Popover, PopoverContent, PopoverTrigger } from '../../components/ui/popover';
import { Command, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem } from '../../components/ui/command';
import AddressSelect from './AddressSelect';
import InvoiceItemsTable, { sampleCatalog } from './InvoiceItemsTable';
import { addressOptions } from '../../data/addressOptions';
import { discountPolicies } from '../../data/discountPolicies';
import { currentStaff, salesExperts } from '../../data/staff';
import InvoiceChatDialog from './InvoiceChatDialog';
import InvoiceActivityLog from './InvoiceActivityLog';
import CancelInvoiceDialog from './CancelInvoiceDialog';
import ConvertInvoiceDialog from './ConvertInvoiceDialog';
import InvoiceSettlementPanel from './InvoiceSettlementPanel';
import { approveInvoiceStage, emptySettlement, settlementFingerprint, validateSettlement, type SettlementApprovals } from '../../data/invoiceFinance';
import type { Invoice, InvoiceLine } from './DashboardOrders';

const fa = (n: number | string) => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[+d]);
const money = (n: number) => n.toLocaleString('fa-IR', { maximumFractionDigits: 0 });
const workflowStages = [
  { key: 'sales' as const, label: 'بررسی فروش', icon: ReceiptText },
  { key: 'finance' as const, label: 'تأیید مالی', icon: Wallet },
  { key: 'warehouse' as const, label: 'آماده‌سازی انبار', icon: Package },
  { key: 'supply' as const, label: 'تأمین کالا', icon: Truck },
];
const makeLines = (invoice: Invoice): InvoiceLine[] => invoice.lines?.map(line => ({ ...line, discount: line.discount ?? invoice.discount ?? 0 })) ?? invoice.products.map((name, index, products) => ({
  id: `${invoice.id}-${index}`, name, code: `SP-${invoice.id}${index}`, specs: 'واحد: عدد',
  qty: 1, price: Math.floor(invoice.amount / products.length) + (index === 0 ? invoice.amount % products.length : 0),
  cost: 0, note: '', aiText: name, unit: 'عدد', discount: invoice.discount ?? 0,
}));

export default function InvoiceDetailDialog({ invoice, readOnly, onClose, onUpdate, onRegenerate, kind = 'sales' }: {
  invoice: Invoice; readOnly: boolean; onClose: () => void; onUpdate: (invoice: Invoice) => void; onRegenerate: () => void; kind?: 'sales' | 'purchase';
}) {
  const workflow = workflowStages.map(stage => kind === 'purchase' && stage.key === 'sales' ? { ...stage, label: 'بررسی خرید' } : stage);
  const [buyer, setBuyer] = useState(invoice.buyer);
  const [phone, setPhone] = useState(invoice.phone);
  const [address, setAddress] = useState(invoice.address ?? { province: '', city: '', street: '', postal: '' });
  const [buyerOpen, setBuyerOpen] = useState(true);
  const [customerType, setCustomerType] = useState(invoice.customerType ?? '');
  const [official, setOfficial] = useState(invoice.official ?? false);
  const [convertOpen, setConvertOpen] = useState(false);
  const [settlement, setSettlement] = useState(() => invoice.settlement ?? emptySettlement());
  const [settlementApprovals, setSettlementApprovals] = useState<SettlementApprovals>(invoice.settlementApprovals ?? {});
  const [financeError, setFinanceError] = useState('');
  const [salesCommissions, setSalesCommissions] = useState(invoice.salesCommissions ?? []);
  const [commissionError, setCommissionError] = useState('');
  const [lines, setLines] = useState(() => makeLines(invoice));
  const [discount, setDiscount] = useState(invoice.discount ?? 0);
  const [discountInput, setDiscountInput] = useState(String(invoice.discount ?? 0));
  const [discountCategory, setDiscountCategory] = useState(invoice.discountCategory ?? 'manual');
  const [deletingLine, setDeletingLine] = useState<InvoiceLine | null>(null);
  const feedbackId = `invoice-feedback-${invoice.id}`;
  const notifyError = (message: string) => toast.error(message, { id: feedbackId, duration: 5500 });
  useEffect(() => () => { toast.dismiss(feedbackId); }, [feedbackId]);
  const [workflowOpen, setWorkflowOpen] = useState(invoice.stages.sales === 'done');
  const [workflowTab, setWorkflowTab] = useState<string>(() => workflowStages.find(stage => invoice.stages[stage.key] !== 'done')?.key ?? 'supply');
  const [itemsOpen, setItemsOpen] = useState(invoice.stages.sales !== 'done');
  const [chatOpen, setChatOpen] = useState(false);
  const [fileOpen, setFileOpen] = useState(false);
  const [fileUrl, setFileUrl] = useState('');
  const [confirm, setConfirm] = useState<'cancel' | 'regenerate' | null>(null);
  const [editing, setEditing] = useState<InvoiceLine | null>(null);
  const [showNotes, setShowNotes] = useState(false);
  const [showAi, setShowAi] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const effectiveRate = discountInput.trim() === '' ? NaN : Number(discountInput);
  const selectDiscount = (category: string) => {
    setDiscountCategory(category);
    if (category !== 'manual') setDiscountInput(discountPolicies[category]?.rate?.toString() ?? '');
  };
  const locked = readOnly || invoice.cancelled;
  const subtotal = lines.reduce((sum, line) => sum + line.qty * line.price, 0);
  const total = lines.reduce((sum, line) => sum + Math.round(line.qty * line.price * (1 - (line.discount ?? 0) / 100)), 0);
  const fingerprint = settlementFingerprint(settlement, total);
  const salesSettlementApproved = settlementApprovals.sales?.fingerprint === fingerprint;
  const financeSettlementApproved = settlementApprovals.finance?.fingerprint === fingerprint;
  const stageIndex = workflow.findIndex(s => invoice.stages[s.key] !== 'done');
  const firstStage = stageIndex === 0;
  useEffect(() => { setItemsOpen(firstStage); setWorkflowOpen(!firstStage); }, [firstStage]);
  useEffect(() => { setWorkflowTab(workflowStages[stageIndex < 0 ? workflowStages.length - 1 : stageIndex].key); }, [stageIndex]);
  useEffect(() => {
    if (!invoice.submission) return;
    const url = URL.createObjectURL(invoice.submission.file);
    setFileUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [invoice.submission]);
  const persist = (nextLines = lines, nextDiscount = discount, patch: Partial<Invoice> = {}, message = 'تغییرات ذخیره شد.') => {
    if (locked) return false;
    const amount = nextLines.reduce((sum, l) => sum + Math.round(l.qty * l.price * (1 - (l.discount ?? 0) / 100)), 0);
    if (salesCommissions.some(entry => !Number.isFinite(entry.rate) || entry.rate < 0 || entry.rate > 100) || salesCommissions.reduce((sum, entry) => sum + entry.rate, 0) > 100) {
      setCommissionError('درصد هر کارشناس و مجموع کمیسیون‌ها باید بین صفر و صد باشد.');
      notifyError('درصد هر کارشناس و مجموع کمیسیون‌ها باید بین صفر و صد باشد.');
      return false;
    }
    setCommissionError('');
    const nextFingerprint = settlementFingerprint(settlement, amount);
    const approvals: SettlementApprovals = {
      sales: settlementApprovals.sales?.fingerprint === nextFingerprint ? settlementApprovals.sales : undefined,
      finance: settlementApprovals.finance?.fingerprint === nextFingerprint ? settlementApprovals.finance : undefined,
    };
    const stages = settlementApprovals.finance && !approvals.finance
      ? { ...invoice.stages, finance: invoice.stages.sales === 'done' ? 'pending' as const : 'waiting' as const, warehouse: 'waiting' as const, supply: 'waiting' as const }
      : invoice.stages;
    setSettlementApprovals(patch.settlementApprovals ?? approvals);
    onUpdate({ ...invoice, buyer, phone, address, customerType, official, settlement, settlementApprovals: approvals, stages, salesCommissions, lines: nextLines, products: nextLines.map(l => l.name), count: nextLines.length,
      matched: Math.min(invoice.matched, nextLines.length), discount: nextDiscount, amount, ...patch });
    toast.success(message, { id: feedbackId, duration: 3500 });
    return true;
  };
  const saveBuyer = () => {
    if (!buyer.trim() || (phone !== '—' && !/^[۰-۹0-9+\s-]{7,15}$/.test(phone))) { notifyError('نام خریدار و شماره تماس معتبر وارد کنید.'); return; }
    persist(lines, discount, {}, 'اطلاعات خریدار ذخیره شد.');
  };
  const applyDiscount = () => {
    if (locked) return;
    const value = effectiveRate;
    if (!Number.isFinite(value) || value < 0 || value > 100) { notifyError('تخفیف باید بین صفر و صد درصد باشد.'); return; }
    const next = lines.map(line => ({ ...line, discount: value }));
    setLines(next); setDiscount(value);
    if (editing) setEditing({ ...editing, discount: value });
    persist(next, value, { discountCategory }, 'تخفیف روی همه کالاها اعمال و ذخیره شد.');
  };
  const saveLine = (candidate: InvoiceLine, finish: boolean) => {
    if (locked) return false;
    if (!candidate.name.trim() || !Number.isFinite(candidate.qty) || candidate.qty <= 0 || !Number.isFinite(candidate.price) || candidate.price < 0 || !Number.isFinite(candidate.cost) || candidate.cost < 0 || !Number.isFinite(candidate.discount ?? 0) || (candidate.discount ?? 0) < 0 || (candidate.discount ?? 0) > 100) { notifyError('نام، تعداد و قیمت معتبر وارد کنید؛ تخفیف باید بین صفر و صد باشد.'); return false; }
    const saved: InvoiceLine = { ...candidate, status: !candidate.code.trim() ? 'unmatched' : candidate.price > 0 ? 'priced' : 'unpriced' };
    const next = lines.some(l => l.id === candidate.id) ? lines.map(l => l.id === candidate.id ? saved : l) : [saved, ...lines];
    if (!persist(next, discount, {}, 'تغییرات کالا ذخیره شد.')) return false;
    setLines(next); setEditing(finish ? null : saved);
    return true;
  };
  const startNewLine = () => {
    if (locked) return;
    setItemsOpen(true);
    setEditing({ id: crypto.randomUUID(), name: '', code: '', specs: '', qty: 1, price: 0, cost: 0, unit: 'عدد', discount, note: '', aiText: '' });
  };
  const confirmSettlement = (role: 'sales' | 'finance') => {
    if (locked || invoice.stages.finance === 'done') return;
    const error = validateSettlement(settlement, total, invoice.customerAccount);
    setFinanceError(error ?? '');
    if (error) { notifyError(error); return; }
    if (role === 'finance' && !salesSettlementApproved) {
      const message = 'ابتدا تسویه را توسط عامل فروش تأیید و ذخیره کنید.';
      setFinanceError(message); notifyError(message); return;
    }
    const approval = { by: currentStaff.name, at: new Date().toISOString(), fingerprint };
    persist(lines, discount, {
      settlementApprovals: role === 'sales' ? { sales: approval } : { ...settlementApprovals, finance: approval },
      stages: role === 'finance' ? approveInvoiceStage(invoice.stages, 'finance') : { ...invoice.stages, finance: 'pending' },
    }, role === 'sales' ? 'تسویه توسط عامل فروش تأیید شد؛ آماده بررسی واحد مالی است.' : 'تسویه توسط واحد مالی تأیید نهایی شد.');
  };
  const advance = () => {
    if (locked || stageIndex < 0) return;
    const key = workflow[stageIndex].key;
    if (key === 'finance') { confirmSettlement('finance'); return; }
    persist(lines, discount, { stages: approveInvoiceStage(invoice.stages, key), history: [...(invoice.history ?? []), `${workflow[stageIndex].label} تأیید شد · ${new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}`] }, `${workflow[stageIndex].label} با موفقیت تأیید شد.`);
  };
  const goBack = (fromIndex = stageIndex < 0 ? workflow.length : stageIndex) => {
    if (locked || fromIndex <= 0 || fromIndex > workflow.length) return;
    const previous = fromIndex - 1;
    const statuses = { ...invoice.stages };
    workflow.forEach((s, i) => { if (i >= previous) statuses[s.key] = i === previous ? 'pending' : 'waiting'; });
    if (persist(lines, discount, { stages: statuses, ...(statuses.finance !== 'done' ? { settlementApprovals: { sales: salesSettlementApproved ? settlementApprovals.sales : undefined } } : {}), history: [...(invoice.history ?? []), `بازگشت به ${workflow[previous].label}`] }, `بازگشت به ${workflow[previous].label} ثبت شد.`)) {
      setWorkflowTab(workflow[previous].key);
      setWorkflowOpen(true);
    }
  };
  const exportPdf = async () => {
    setExporting(true);
    try {
      await document.fonts.ready;
      const { jsPDF } = await import('jspdf');
      const pdf = new jsPDF();
      // Render Persian with the browser's font shaping, then embed as an image.
      for (let start = 0; start < Math.max(lines.length, 1); start += 14) {
        if (start) pdf.addPage();
        const canvas = document.createElement('canvas');
        canvas.width = 1200; canvas.height = 1697;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('canvas');
        ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.direction = 'rtl'; ctx.textAlign = 'right'; ctx.fillStyle = '#156394'; ctx.font = 'bold 32px IRANSans, sans-serif';
        ctx.fillText(`پیش‌فاکتور #${fa(invoice.id)}`, 1120, 90);
        ctx.fillStyle = '#334155'; ctx.font = '24px IRANSans, sans-serif';
        ctx.fillText(`${buyer} · ${fa(phone)}`, 1120, 150);
        ctx.fillText(`${invoice.date} · ${invoice.time}`, 1120, 200);
        ctx.fillText(`${address.province} ${address.city} ${address.street}`, 1120, 250, 1040);
        lines.slice(start, start + 14).forEach((line, index) => {
          const y = 340 + index * 80;
          ctx.fillText(`${fa(start + index + 1)}. ${line.name}`, 1120, y, 1000);
          ctx.font = '20px IRANSans, sans-serif';
          ctx.fillText(`${fa(line.qty)} ${line.unit || 'عدد'} × ${money(line.price)} · تخفیف ${fa(line.discount ?? 0)}٪ · ${money(Math.round(line.qty * line.price * (1 - (line.discount ?? 0) / 100)))} ریال`, 1120, y + 32, 1000);
          ctx.font = '24px IRANSans, sans-serif';
        });
        ctx.fillText(`جمع تخفیف: ${money(subtotal - total)} ریال · مبلغ نهایی: ${money(total)} ریال`, 1120, 1550);
        pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, 210, 297);
      }
      pdf.save(`invoice-${invoice.id}.pdf`);
    } catch { notifyError('ساخت PDF ناموفق بود؛ دوباره تلاش کنید.'); }
    finally { setExporting(false); }
  };
  const tools = [
    { label: 'تبدیل', icon: ArrowLeftRight, action: () => setConvertOpen(true), disabled: locked },
    { label: 'گفت‌وگو', icon: MessageSquare, action: () => setChatOpen(true), disabled: false },
    { label: 'لغو فاکتور', icon: Ban, action: () => setConfirm('cancel'), disabled: locked },
    { label: invoice.starred ? 'حذف ستاره' : 'ستاره‌دار', icon: Star, action: () => !locked && onUpdate({ ...invoice, starred: !invoice.starred }), disabled: locked },
    { label: 'فایل ارسالی', icon: FileText, action: () => setFileOpen(true), disabled: invoice.file === 'manual' },
    { label: 'بازتولید', icon: RotateCw, action: () => setConfirm('regenerate'), disabled: locked || !invoice.submission },
    { label: 'دانلود PDF', icon: Download, action: exportPdf, disabled: exporting },
  ];
  const itemsSection = (
          <Collapsible open={itemsOpen} onOpenChange={setItemsOpen} className="overflow-hidden rounded-2xl border border-border/60 bg-background">
            <div className="flex flex-wrap items-center justify-between gap-2 p-3 sm:p-4">
              <CollapsibleTrigger asChild><Button variant="ghost" className="h-auto min-w-0 flex-1 justify-start gap-3 px-1 py-1 text-right hover:bg-transparent"><Package size={18} className="shrink-0 text-brand" /><span className="text-sm font-semibold">کالاهای پیش‌فاکتور <span className="text-xs font-normal text-muted-foreground">({fa(lines.length)} ردیف)</span></span><ChevronDown size={16} className={`mr-auto shrink-0 transition-transform ${itemsOpen ? 'rotate-180' : ''}`} /></Button></CollapsibleTrigger>
              <div className="flex flex-wrap gap-2"><Button variant="outline" disabled={locked} onClick={() => setSearchOpen(true)} className="h-8 rounded-lg text-xs text-brand"><Sparkles size={14} /> جستجوی تکمیلی</Button><Button variant="outline" disabled={locked} onClick={() => { if (editing && editing.name.trim() && !saveLine(editing, true)) return; startNewLine(); }} className="h-8 rounded-lg text-xs"><Plus size={14} /> افزودن کالا</Button></div>
            </div>
            <CollapsibleContent className="border-t border-border/60">
            <div className="flex flex-wrap items-center justify-between gap-3 bg-muted/20 px-3 py-2">
              <div className="flex gap-3 text-xs"><Label className="flex items-center gap-1.5"><Checkbox checked={showNotes} onCheckedChange={v => setShowNotes(v === true)} /> توضیحات</Label><Label className="flex items-center gap-1.5"><Checkbox checked={showAi} onCheckedChange={v => setShowAi(v === true)} /> متن AI</Label></div>
              <div className="mr-auto flex flex-wrap items-center gap-2"><Label htmlFor="discount" className="text-xs">تخفیف همه</Label>
                <Select value={discountCategory} onValueChange={selectDiscount} disabled={locked}><SelectTrigger aria-label="دسته تخفیف" className="h-8 w-36 rounded-lg text-xs"><SelectValue /></SelectTrigger><SelectContent dir="rtl"><SelectItem value="manual">تخفیف دستی</SelectItem>{Object.entries(discountPolicies).map(([key, policy]) => <SelectItem key={key} value={key}>{policy.label}</SelectItem>)}</SelectContent></Select>
                <LocalizedNumberInput id="discount" aria-label="درصد تخفیف درخواست" allowDecimal groupThousands={false} disabled={locked} value={discountInput} placeholder="۰" onValueChange={setDiscountInput} onKeyDown={e => { if (e.key === 'Enter') applyDiscount(); }} className="h-8 w-16 rounded-lg border-brand/30 bg-background" /><span className="text-xs text-muted-foreground">٪</span><Button variant="outline" disabled={locked || !lines.length} onClick={applyDiscount} className="h-8 rounded-lg text-xs">اعمال روی همه</Button>
              </div>
            </div>
            <InvoiceItemsTable lines={lines} editing={editing} setEditing={setEditing} locked={locked} showNotes={showNotes} showAi={showAi} onSave={saveLine} onDelete={line => setDeletingLine(line)} onNewLine={startNewLine} />
            {!lines.length && !editing && <p className="p-8 text-center text-sm text-muted-foreground">هنوز کالایی ثبت نشده است.</p>}
            </CollapsibleContent>
          </Collapsible>
  );
  const workflowSection = (
          <Collapsible open={workflowOpen} onOpenChange={setWorkflowOpen} className="overflow-hidden rounded-2xl border border-border/60 bg-background">
            <CollapsibleTrigger asChild><Button variant="ghost" className="h-auto w-full justify-between rounded-none px-4 py-3 text-right hover:bg-muted/30"><span className="flex flex-col gap-1"><span className="text-sm font-semibold">{kind === 'purchase' ? 'گردش کار فاکتور خرید' : 'گردش کار فاکتور فروش'}</span><span className="text-xs font-normal text-muted-foreground">{stageIndex < 0 ? 'تمام مراحل تأیید شده‌اند' : `مرحله فعلی: ${workflow[stageIndex].label}`}</span></span><ChevronDown size={16} className={`transition-transform ${workflowOpen ? 'rotate-180' : ''}`} /></Button></CollapsibleTrigger>
            <CollapsibleContent className="border-t border-border/60 p-3 sm:p-4">
              <Tabs dir="rtl" value={workflowTab} onValueChange={setWorkflowTab} className="gap-4">
                <TabsList className="grid h-auto w-full grid-cols-2 gap-1 rounded-xl p-1 sm:grid-cols-4">{workflow.map(stage => <TabsTrigger key={stage.key} value={stage.key} className="gap-2 rounded-lg py-2.5 text-xs data-[state=active]:text-brand"><stage.icon size={15} />{stage.label}{invoice.stages[stage.key] === 'done' && <Check size={13} className="text-emerald-600" />}</TabsTrigger>)}</TabsList>
                {workflow.map((stage, index) => <TabsContent key={stage.key} value={stage.key} className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3"><span className="flex items-center gap-2 text-sm font-medium"><stage.icon size={17} className="text-brand" />{stage.label}</span><span className={`rounded-full px-3 py-1 text-xs ${invoice.stages[stage.key] === 'done' ? 'bg-emerald-50 text-emerald-700' : index === stageIndex ? 'bg-brand/10 text-brand' : 'bg-muted text-muted-foreground'}`}>{invoice.stages[stage.key] === 'done' ? 'تأیید شده' : stage.key === 'finance' ? salesSettlementApproved ? 'در انتظار تأیید واحد مالی' : 'آماده ثبت تسویه' : index === stageIndex ? 'در انتظار اقدام' : 'در انتظار مرحله قبل'}</span></div>
                  {stage.key !== 'finance' && <div className="grid grid-cols-2 gap-3 rounded-xl bg-muted/30 p-3 text-xs sm:grid-cols-3">{(stage.key === 'sales' ? [['خریدار', buyer], ['نوع مشتری', customerType || 'تعیین نشده'], ['کارشناسان فروش', salesCommissions.map(entry => salesExperts.find(expert => expert.id === entry.staffId)?.name).filter(Boolean).join('، ') || 'تعیین نشده']] : stage.key === 'warehouse' ? [['تعداد ردیف', fa(lines.length)], ['تعداد کالا', fa(lines.reduce((sum, line) => sum + line.qty, 0))], ['وضعیت تحویل', { none: 'ارسال نشده', sent: 'ارسال شده', delivered: 'تحویل شده' }[invoice.delivery]]] : [['اقلام تطبیق‌یافته', fa(invoice.matched)], ['اقلام بدون قیمت', fa(lines.filter(line => !line.price).length)], ['مقصد', [address.province, address.city].filter(Boolean).join('، ') || 'تعیین نشده']]).map(([label, value]) => <div key={label} className="space-y-2"><span className="block text-muted-foreground">{label}</span><span className="block leading-relaxed font-medium">{value}</span></div>)}</div>}
                  {stage.key === 'finance' && <InvoiceSettlementPanel total={total} buyer={buyer} account={invoice.customerAccount} value={settlement} onChange={next => { setSettlement(next); if (settlementFingerprint(next, total) !== fingerprint) setSettlementApprovals({}); setFinanceError(''); }} onSalesConfirm={() => confirmSettlement('sales')} onFinanceConfirm={() => confirmSettlement('finance')} salesApproval={salesSettlementApproved ? settlementApprovals.sales : undefined} financeApproval={financeSettlementApproved ? settlementApprovals.finance : undefined} locked={locked || invoice.stages.finance === 'done'} error={financeError} />}
                  {(index > 0 || index === stageIndex) && <div className="flex flex-wrap justify-end gap-2">
                    {index > 0 && <Button variant="outline" disabled={locked || invoice.stages[stage.key] === 'waiting'} onClick={() => goBack(index)} className="h-9 rounded-lg text-xs"><ArrowRight size={14} />بازگشت به {workflow[index - 1].label}</Button>}
                    {index === stageIndex && stage.key !== 'finance' && <Button disabled={locked || !lines.length} onClick={advance} className="h-9 rounded-lg bg-brand text-xs text-white hover:bg-brand/90"><Check size={14} /> تأیید {stage.label}</Button>}
                  </div>}
                </TabsContent>)}
              </Tabs>
              {stageIndex < 0 && <Button variant="outline" disabled={locked} onClick={() => goBack()} className="mt-3 h-8 text-xs"><ArrowRight size={14} />بازگشایی مرحله {workflow[workflow.length - 1].label}</Button>}
            </CollapsibleContent>
          </Collapsible>
  );
  return <Dialog open onOpenChange={open => { if (!open) onClose(); }}>
    <DialogContent dir="rtl" className="inset-0 top-0 left-0 flex h-dvh w-screen max-w-none translate-x-0 translate-y-0 flex-col gap-0 overflow-hidden rounded-none border-0 p-0 sm:max-w-none [&>button]:hidden">
      <Toaster position="top-center" dir="rtl" theme="light" closeButton visibleToasts={1} className="!top-20"
        containerAriaLabel="اعلان‌های درخواست"
        icons={{
          success: <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600"><Check size={17} /></span>,
          error: <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-destructive/10 text-destructive"><AlertCircle size={17} /></span>,
        }}
        toastOptions={{ closeButtonAriaLabel: 'بستن اعلان', classNames: {
          toast: '!gap-3 !rounded-2xl !border-border !bg-background !p-4 !text-foreground !shadow-xl',
          title: '!text-sm !font-semibold !leading-relaxed',
          success: '!border-emerald-200',
          error: '!border-destructive/25',
          icon: '!size-8 !shrink-0',
          closeButton: '!border-border !bg-background !text-muted-foreground',
        } }} />
      <DialogHeader className="flex-row items-center gap-2 shrink-0 border-b border-brand bg-brand px-3 py-2 text-right shadow-sm sm:gap-4 sm:px-5 sm:text-right">
        <DialogTitle className="shrink-0 whitespace-nowrap text-sm text-white">درخواست #{fa(invoice.id)}{invoice.cancelled && <span className="mr-1 rounded bg-white/15 px-1 text-xs font-normal text-white">لغوشده</span>}</DialogTitle>
        <DialogDescription className="sr-only md:not-sr-only md:shrink-0 md:whitespace-nowrap md:text-xs md:text-white/75">{invoice.date} · {invoice.time}<span className="hidden xl:inline"> · {invoice.creator}</span></DialogDescription>
        <div className="scrollbar-hidden flex min-w-0 flex-1 gap-1 overflow-x-auto">{tools.map(tool => <Button key={tool.label} variant="ghost" disabled={tool.disabled} aria-label={tool.icon === MessageSquare ? `گفت‌وگو، ${fa(invoice.messages?.length ?? 0)} پیام` : tool.label} title={tool.label === 'بازتولید' && !invoice.submission ? 'فایل اصلی موجود نیست' : tool.label} onClick={tool.action} className={`h-8 shrink-0 rounded-lg px-2 text-xs font-normal hover:bg-white/25 hover:text-white ${tool.icon === Star && invoice.starred ? 'bg-amber-100 text-amber-800' : 'bg-white/10 text-white'}`}><tool.icon size={14} fill={tool.icon === Star && invoice.starred ? 'currentColor' : 'none'} /><span className="hidden lg:inline">{tool.label}</span>{tool.icon === MessageSquare && Boolean(invoice.messages?.length) && <span className="flex min-w-4 items-center justify-center rounded-full bg-white px-1 text-xs font-semibold text-brand">{fa(invoice.messages?.length ?? 0)}</span>}</Button>)}</div>
        <Button variant="ghost" size="icon" onClick={onClose} aria-label="بستن جزئیات فاکتور" className="size-8 shrink-0 rounded-lg bg-white/15 text-white hover:bg-white/25 hover:text-white"><X size={17} /></Button>
      </DialogHeader>
      <div className="scrollbar-hidden min-h-0 flex-1 overflow-y-auto bg-muted/20">
        <div className="mx-auto max-w-screen-2xl space-y-4 p-3 sm:p-6">
          {readOnly && <p className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-xs text-amber-700"><Eye size={14} /> فقط مشاهده؛ دسترسی ویرایش در اختیار {invoice.editor?.name} است.</p>}
          {invoice.cancellation && <div className="rounded-xl border border-destructive/20 bg-destructive/5 p-3 text-xs"><p className="font-medium text-destructive">لغو: {invoice.cancellation.reason}</p><p className="mt-1 whitespace-pre-wrap break-words text-muted-foreground">{invoice.cancellation.explanation}</p><p className="mt-2 text-muted-foreground">{invoice.cancellation.by} · {invoice.cancellation.at}</p></div>}
          {!firstStage && workflowSection}
          {firstStage && itemsSection}
          <Collapsible open={buyerOpen} onOpenChange={setBuyerOpen} className="overflow-hidden rounded-2xl border border-border/60 bg-background">
            <CollapsibleTrigger asChild><Button variant="ghost" className="h-auto w-full justify-between rounded-none px-4 py-3 text-right hover:bg-muted/30"><span className="flex min-w-0 flex-col gap-1"><span className="text-sm font-semibold">اطلاعات خریدار</span><span className="truncate text-xs font-normal text-muted-foreground">{buyer || 'خریدار جدید'}{customerType && ` · ${customerType}`}{salesCommissions.length > 0 && ` · ${fa(salesCommissions.length)} کارشناس فروش`}</span></span><ChevronDown size={16} className={`shrink-0 transition-transform ${buyerOpen ? 'rotate-180' : ''}`} /></Button></CollapsibleTrigger>
            <CollapsibleContent className="space-y-4 border-t border-border/60 p-4">
              <Label className="w-fit cursor-pointer gap-2 rounded-lg border border-brand/15 bg-brand/5 px-3 py-2 text-xs"><Checkbox id="official-request" disabled={locked} checked={official} onCheckedChange={value => setOfficial(value === true)} />درخواست رسمی</Label>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div className="space-y-1.5"><Label htmlFor="buyer-name" className="text-xs text-muted-foreground">نام خریدار</Label><Input id="buyer-name" disabled={locked} value={buyer} onChange={e => setBuyer(e.target.value)} className="h-9 rounded-lg" /></div>
                <div className="space-y-1.5"><Label htmlFor="buyer-phone" className="text-xs text-muted-foreground">شماره تماس</Label><Input id="buyer-phone" disabled={locked} value={phone} onChange={e => setPhone(e.target.value)} dir="ltr" className="h-9 rounded-lg text-right" /></div>
                <div className="space-y-1.5"><Label className="text-xs text-muted-foreground" htmlFor="customer-type">نوع مشتری</Label><Select value={customerType} onValueChange={setCustomerType} disabled={locked}><SelectTrigger id="customer-type" className="h-9 w-full rounded-lg"><SelectValue placeholder="انتخاب نوع مشتری" /></SelectTrigger><SelectContent dir="rtl">{['مصرف کننده', 'همکار', 'شرکت مجری', 'مهندس پروژه'].map(type => <SelectItem value={type} key={type}>{type}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-1.5"><Label htmlFor="buyer-province" className="text-xs text-muted-foreground">استان</Label><AddressSelect id="buyer-province" label="استان" value={address.province} options={Object.keys(addressOptions)} disabled={locked} onChange={province => setAddress(current => ({ ...current, province, city: '' }))} /></div>
                <div className="space-y-1.5"><Label htmlFor="buyer-city" className="text-xs text-muted-foreground">شهر</Label><AddressSelect id="buyer-city" label="شهر" value={address.city} options={addressOptions[address.province] ?? []} disabled={locked || !address.province} onChange={city => setAddress(current => ({ ...current, city }))} /></div>
                <div className="space-y-1.5"><Label htmlFor="buyer-street" className="text-xs text-muted-foreground">نشانی کامل</Label><Input id="buyer-street" disabled={locked} value={address.street} onChange={e => setAddress(current => ({ ...current, street: e.target.value }))} className="h-9 rounded-lg" /></div>
                <div className="space-y-1.5"><Label htmlFor="buyer-postal" className="text-xs text-muted-foreground">کد پستی</Label><Input id="buyer-postal" disabled={locked} value={address.postal} onChange={e => setAddress(current => ({ ...current, postal: e.target.value }))} className="h-9 rounded-lg" /></div>
              </div>
              <div className="space-y-3 rounded-xl border border-border/60 bg-muted/20 p-3">
                <div className="flex flex-wrap items-center justify-between gap-2"><Label className="text-xs font-medium">کارشناسان فروش</Label>
                  <Popover modal><PopoverTrigger asChild><Button variant="outline" disabled={locked} className="h-8 gap-2 rounded-lg bg-background text-xs"><Plus size={14} /> انتخاب کارشناسان {salesCommissions.length > 0 && `(${fa(salesCommissions.length)})`}</Button></PopoverTrigger><PopoverContent dir="rtl" align="end" className="w-64 p-0"><Command><CommandInput aria-label="جستجوی کارشناس فروش" placeholder="جستجوی کارشناس فروش…" /><CommandList><CommandEmpty>کارشناسی پیدا نشد.</CommandEmpty><CommandGroup>{salesExperts.map(expert => <CommandItem key={expert.id} value={expert.name} disabled={locked} onSelect={() => setSalesCommissions(current => current.some(entry => entry.staffId === expert.id) ? current.filter(entry => entry.staffId !== expert.id) : [...current, { staffId: expert.id, rate: 0 }])} className="gap-2 py-2.5 text-xs"><span className={`flex size-4 items-center justify-center rounded border ${salesCommissions.some(entry => entry.staffId === expert.id) ? 'border-brand bg-brand text-white' : 'border-border'}`}>{salesCommissions.some(entry => entry.staffId === expert.id) && <Check size={12} />}</span>{expert.name}</CommandItem>)}</CommandGroup></CommandList></Command></PopoverContent></Popover>
                </div>
                {salesCommissions.length > 0 ? <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{salesCommissions.map(entry => <div key={entry.staffId} className="flex flex-wrap items-center gap-2 rounded-lg border border-border/60 bg-background p-2"><span className="min-w-0 flex-1 text-xs font-medium">{salesExperts.find(expert => expert.id === entry.staffId)?.name ?? entry.staffId}</span><Label htmlFor={`commission-${entry.staffId}`} className="sr-only">درصد کمیسیون از سود فاکتور</Label><LocalizedNumberInput id={`commission-${entry.staffId}`} allowDecimal groupThousands={false} disabled={locked} value={entry.rate} onValueChange={value => setSalesCommissions(current => current.map(item => item.staffId === entry.staffId ? { ...item, rate: Number(value) } : item))} className="h-8 w-16 rounded-md text-center" /><span className="text-xs text-muted-foreground">٪ از سود</span><Button variant="ghost" size="icon" disabled={locked} aria-label="حذف کارشناس" className="size-7 text-muted-foreground" onClick={() => setSalesCommissions(current => current.filter(item => item.staffId !== entry.staffId))}><X size={13} /></Button></div>)}</div> : <span className="text-xs text-muted-foreground">کارشناسی انتخاب نشده است.</span>}
                {commissionError && <span role="alert" className="block text-xs text-destructive">{commissionError}</span>}
              </div>
              <div className="flex items-center justify-end rounded-xl bg-brand/5 p-3"><Button disabled={locked} onClick={saveBuyer} className="h-9 rounded-lg bg-brand text-xs text-white shadow-sm hover:bg-brand/90"><Save size={14} /> ذخیره اطلاعات</Button></div>
            </CollapsibleContent>
          </Collapsible>
          {firstStage && workflowSection}
          <InvoiceActivityLog activities={invoice.activities} />
          {!firstStage && itemsSection}

        </div>
      </div>
      <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 border-t border-border bg-background px-4 py-3 sm:px-6"><div className="flex gap-4 text-xs text-muted-foreground"><span>جمع: {money(subtotal)}</span><span>تخفیف: {money(subtotal - total)} ریال</span></div><p className="text-sm font-semibold">مبلغ نهایی <span className="mr-2 text-base text-brand">{money(total)}</span> <span className="text-xs font-normal text-muted-foreground">ریال</span></p></div>
      <Dialog open={Boolean(deletingLine)} onOpenChange={open => { if (!open) setDeletingLine(null); }}><DialogContent dir="rtl" className="rounded-2xl"><DialogHeader className="text-right sm:text-right"><DialogTitle>حذف این ردیف کالا؟</DialogTitle><DialogDescription>«{deletingLine?.name || 'کالای جدید'}» حذف می‌شود و مبلغ فاکتور دوباره محاسبه خواهد شد.</DialogDescription></DialogHeader><div className="flex gap-2"><Button variant="outline" onClick={() => setDeletingLine(null)}>انصراف</Button><Button variant="destructive" disabled={locked} onClick={() => { if (locked || !deletingLine) return; const next = lines.filter(line => line.id !== deletingLine.id); setLines(next); if (editing?.id === deletingLine.id) setEditing(null); persist(next); setDeletingLine(null); }}>حذف کالا</Button></div></DialogContent></Dialog>
      <ConvertInvoiceDialog open={convertOpen} onOpenChange={setConvertOpen} />
      <InvoiceChatDialog open={chatOpen} onOpenChange={setChatOpen} invoice={invoice} locked={locked} onUpdate={onUpdate} />
      <CancelInvoiceDialog open={confirm === 'cancel'} onOpenChange={open => { if (!open) setConfirm(null); }} disabled={locked} onConfirm={(reason, explanation) => {
        if (locked || !reason || !explanation.trim()) return;
        onUpdate({ ...invoice, cancelled: true, cancellation: { reason, explanation, by: currentStaff.name, at: new Date().toLocaleString('fa-IR') } });
        setConfirm(null);
      }} />
      <Dialog open={fileOpen} onOpenChange={setFileOpen}><DialogContent dir="rtl" className="max-h-[90vh] overflow-auto rounded-2xl sm:max-w-3xl"><DialogHeader className="text-right sm:text-right"><DialogTitle>فایل ارسالی</DialogTitle><DialogDescription>{invoice.submission?.file.name ?? 'فایل ارسالی موجود نیست.'}</DialogDescription></DialogHeader>{fileUrl && (invoice.file === 'image' ? <img src={fileUrl} alt="فایل تصویر ارسالی" className="max-h-96 w-full object-contain" /> : invoice.file === 'voice' ? <audio controls src={fileUrl} className="w-full" /> : <iframe title="فایل PDF ارسالی" src={fileUrl} className="h-96 w-full rounded-lg border border-border" />)}</DialogContent></Dialog>
      <Dialog open={confirm === 'regenerate'} onOpenChange={open => { if (!open) setConfirm(null); }}><DialogContent dir="rtl" className="rounded-2xl"><DialogHeader className="text-right sm:text-right"><DialogTitle>بازتولید تحلیل فایل؟</DialogTitle><DialogDescription>تحلیل فایل از ابتدا آغاز می‌شود. تغییرات دستی ردیف‌ها حفظ می‌شوند.</DialogDescription></DialogHeader><div className="flex gap-2"><Button variant="outline" onClick={() => setConfirm(null)}>انصراف</Button><Button disabled={locked} onClick={() => { if (locked) return; setConfirm(null); onRegenerate(); }}>شروع مجدد</Button></div></DialogContent></Dialog>
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}><DialogContent dir="rtl" className="rounded-2xl"><DialogHeader className="text-right sm:text-right"><DialogTitle>جستجوی تکمیلی کالا</DialogTitle><DialogDescription>کالا را با نام یا کد جستجو کنید.</DialogDescription></DialogHeader><Input aria-label="جستجو در کاتالوگ" value={query} onChange={e => setQuery(e.target.value)} placeholder="نام کالا…" />{sampleCatalog.filter(product => `${product.name} ${product.code}`.includes(query)).map(product => <Button key={product.code} variant="outline" disabled={locked} className="justify-between" onClick={() => { setEditing({ id: crypto.randomUUID(), ...product, qty: 1, price: 0, cost: 0, discount, note: '', aiText: '' }); setSearchOpen(false); setItemsOpen(true); }}> {product.name}<Plus size={14} /></Button>)}</DialogContent></Dialog>
    </DialogContent>
  </Dialog>;
}
