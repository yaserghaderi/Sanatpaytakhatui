import { useEffect, useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Package, ReceiptText, Newspaper,
  Users, BarChart3, Settings, Menu, X, UserRound,
  Bell, ChevronDown, WalletCards, LogOut, Tags, Layers, SlidersHorizontal,
  Sparkles, FileInput, FileText, PenLine, FolderKanban, ChartNoAxesCombined,
  Boxes, Link, Coins, ListTodo, MessageSquare, Keyboard, ShoppingCart
} from 'lucide-react';
import logo from '../../../assets/e2bf7b3e45975301863221e28611d21b5c7fdd37.png';
import { Button } from '../../components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '../../components/ui/avatar';
import { currentStaff } from '../../data/staff';
import { loadShortcuts, shortcutFromEvent } from '../../data/shortcuts';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '../../components/ui/collapsible';

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

const submenuIcons = {
  'مشاهده همه محصولات': Package,
  'دسته‌بندی‌ها': Layers,
  'برندها': Tags,
  'ویژگی‌ها': SlidersHorizontal,
  'گروه‌بندی هوشمند': Sparkles,
  'ورود لیست قیمت': FileInput,
  'همه مطالب': FileText,
  'دسته‌بندی مطالب': Layers,
  'برچسب‌ها': Tags,
  'نویسنده‌ها': PenLine,
  'همه مشتریان': Users,
  'دسته‌بندی مشتریان': Layers,
  'پروژه‌ها': FolderKanban,
  'تحلیل انبار': Boxes,
  'عملکرد پرسنل': ChartNoAxesCombined,
  'گزارش فروش': BarChart3,
  'اتصال انبار': Link,
  'نرخ ارز': Coins,
  'مدیریت پرسنل': Users,
  'تسک‌های بک‌اند': ListTodo,
  'پیامک ها': MessageSquare,
};

const navItems = [
  { id: 'dashboard', path: '/dashboard', label: 'داشبورد', icon: LayoutDashboard },
  { id: 'invoices', path: '/dashboard/orders', label: 'فاکتورهای فروش', icon: ReceiptText },
  { id: 'purchases', path: '/dashboard/purchases', label: 'فاکتورهای خرید', icon: ShoppingCart },
  {
    id: 'inventory',
    label: 'کالا و انبار',
    icon: Package,
    children: [
      { path: '/dashboard/products', label: 'مشاهده همه محصولات' },
      { path: '/dashboard/products?section=categories', label: 'دسته‌بندی‌ها' },
      { path: '/dashboard/products?section=brands', label: 'برندها' },
      { path: '/dashboard/products?section=attributes', label: 'ویژگی‌ها' },
      { path: '/dashboard/products?section=smart-groups', label: 'گروه‌بندی هوشمند' },
      { path: '/dashboard/products?section=price-list', label: 'ورود لیست قیمت' },
    ],
  },
  {
    id: 'blog',
    label: 'بلاگ',
    icon: Newspaper,
    children: [
      { path: '/dashboard?section=blog-posts', label: 'همه مطالب' },
      { path: '/dashboard?section=blog-categories', label: 'دسته‌بندی مطالب' },
      { path: '/dashboard?section=blog-tags', label: 'برچسب‌ها' },
      { path: '/dashboard?section=blog-authors', label: 'نویسنده‌ها' },
    ],
  },
  {
    id: 'crm',
    label: 'مشتریان (CRM)',
    icon: Users,
    children: [
      { path: '/dashboard/customers', label: 'همه مشتریان' },
      { path: '/dashboard/customers?section=categories', label: 'دسته‌بندی مشتریان' },
      { path: '/dashboard/customers?section=projects', label: 'پروژه‌ها', soon: true },
    ],
  },
  {
    id: 'reports',
    label: 'گزارش‌ها',
    icon: BarChart3,
    children: [
      { path: '/dashboard/analytics', label: 'تحلیل انبار' },
      { path: '/dashboard/analytics?section=staff', label: 'عملکرد پرسنل' },
      { path: '/dashboard/analytics?section=sales', label: 'گزارش فروش' },
    ],
  },
  { id: 'earnings', path: '/dashboard/analytics?section=earnings', label: 'درآمدهای من', icon: WalletCards },
  {
    id: 'settings',
    label: 'تنظیمات',
    icon: Settings,
    children: [
      { path: '/dashboard/sync', label: 'اتصال انبار' },
      { path: '/dashboard/sync?section=currency', label: 'نرخ ارز' },
      { path: '/dashboard/sync?section=staff', label: 'مدیریت پرسنل' },
      { path: '/dashboard/sync?section=backend-tasks', label: 'تسک‌های بک‌اند' },
      { path: '/dashboard/sync?section=sms', label: 'پیامک ها' },
    ],
  },
];

export function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (event.defaultPrevented || event.isComposing || event.repeat) return;
      const binding = loadShortcuts().shortcuts;
      const keys = shortcutFromEvent(event);
      if (keys !== binding && !(binding === 'Ctrl+K' && keys === 'Meta+K')) return;
      event.preventDefault();
      setProfileOpen(false);
      navigate('/dashboard/shortcuts');
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [navigate]);
  const [sidebarOpen, setSidebarOpen] = useState(() => window.matchMedia('(min-width: 768px)').matches);
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({
    inventory: true,
  });

  const isPathActive = (path: string) => {
    const currentPath = `${location.pathname}${location.search}`;
    return currentPath === path;
  };

  const getPageTitle = () => {
    for (const item of navItems) {
      if ('path' in item && item.path && isPathActive(item.path)) {
        return item.label;
      }

      if ('children' in item && item.children) {
        const activeChild = item.children.find(child => isPathActive(child.path));
        if (activeChild) return activeChild.label;
      }
    }

    if (location.pathname === '/dashboard/quotations') return 'پیش‌فاکتورهای هوشمند';
    if (location.pathname === '/dashboard/shortcuts') return 'منوی شورتکات‌ها';
    return 'داشبورد';
  };

  return (
    <div className="flex min-h-screen bg-gray-50" dir="rtl">
      {/* Sidebar */}
      {sidebarOpen && <Button variant="ghost" aria-label="بستن منوی پنل" onClick={() => setSidebarOpen(false)} className="fixed inset-0 z-20 h-full w-full rounded-none bg-black/30 hover:bg-black/30 md:hidden" />}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 256, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed top-0 right-0 z-30 flex h-full flex-col overflow-hidden border-l border-border bg-gradient-to-b from-background via-sidebar to-muted shadow-xl shadow-black/5"
            style={{ minWidth: 256 }}
          >
            <div className="pointer-events-none absolute -right-20 top-28 h-52 w-52 rounded-full bg-background/80 blur-3xl" />
            <div className="pointer-events-none absolute -left-20 bottom-20 h-48 w-48 rounded-full bg-sidebar-accent/60 blur-3xl" />

            {/* Logo */}
            <div className="relative flex h-16 shrink-0 items-center justify-center border-b border-border bg-background px-5">
              <Button
                variant="ghost"
                onClick={() => navigate('/')}
                className="h-auto rounded-2xl px-4 py-2 hover:bg-muted"
                aria-label="بازگشت به صفحه اصلی"
              >
                <img src={logo} alt="جهان موج" className="h-10 md:h-11 w-auto" />
              </Button>
            </div>

            {/* Nav */}
            <nav className="scrollbar-hidden relative flex-1 space-y-1 overflow-y-auto px-3 py-4">
              {navItems.map(item => {
                const Icon = item.icon;
                const active = 'path' in item && item.path
                  ? isPathActive(item.path)
                  : item.children?.some(child => isPathActive(child.path));

                if ('children' in item && item.children) {
                  const isOpen = Boolean(openMenus[item.id]);

                  return (
                    <Collapsible
                      key={item.id}
                      open={isOpen}
                      onOpenChange={(open) => setOpenMenus(current => ({ ...current, [item.id]: open }))}
                    >
                      <CollapsibleTrigger asChild>
                        <Button
                          variant="ghost"
                          className={`h-auto w-full justify-start rounded-xl px-4 py-3 text-right font-normal
                            ${active
                              ? 'bg-gradient-to-l from-brand/15 to-background text-brand ring-1 ring-brand/20 shadow-sm hover:bg-brand/10 hover:text-brand'
                              : 'text-muted-foreground hover:bg-background/80 hover:text-sidebar-foreground'}`}
                        >
                          <span className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${active ? 'bg-brand text-white shadow-sm' : 'bg-muted text-muted-foreground'}`}>
                            <Icon size={16} />
                          </span>
                          <span className="flex-1">{item.label}</span>
                          <ChevronDown
                            size={14}
                            className={`transition-transform ${isOpen ? 'rotate-180' : ''}`}
                          />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="mt-1 space-y-0.5 border-r border-sidebar-border">
                        {item.children.map(child => {
                          const childActive = isPathActive(child.path);
                          const ChildIcon = submenuIcons[child.label as keyof typeof submenuIcons];

                          return (
                            <Button
                              key={child.path}
                              variant="ghost"
                              disabled={child.soon}
                              onClick={() => navigate(child.path)}
                              className={`h-auto w-full justify-start rounded-lg py-2.5 pr-9 pl-3 text-right text-xs font-normal
                                ${childActive
                                  ? 'bg-brand/10 text-brand shadow-sm hover:bg-brand/15 hover:text-brand'
                                  : 'text-muted-foreground hover:bg-background/70 hover:text-sidebar-foreground'}
                                ${child.soon ? 'cursor-not-allowed opacity-60' : ''}`}
                            >
                              <ChildIcon size={14} className={`shrink-0 ${childActive ? 'text-brand' : 'text-muted-foreground/70'}`} />
                              <span className="flex-1">{child.label}</span>
                              {child.soon && (
                                <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
                                  به زودی
                                </span>
                              )}
                            </Button>
                          );
                        })}
                      </CollapsibleContent>
                    </Collapsible>
                  );
                }

                return (
                  <Button
                    key={item.id}
                    variant="ghost"
                    onClick={() => item.path && navigate(item.path)}
                    className={`h-auto w-full justify-start rounded-xl px-4 py-3 text-right font-normal
                      ${active
                        ? 'bg-gradient-to-l from-brand/15 to-background text-brand ring-1 ring-brand/20 shadow-sm hover:bg-brand/10 hover:text-brand'
                        : 'text-muted-foreground hover:bg-background/80 hover:text-sidebar-foreground'}`}
                  >
                    <span className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${active ? 'bg-brand text-white shadow-sm' : 'bg-muted text-muted-foreground'}`}>
                      <Icon size={16} />
                    </span>
                    <span className="flex-1">{item.label}</span>
                    {active && <span className="h-1.5 w-1.5 rounded-full bg-brand" />}
                  </Button>
                );
              })}
            </nav>

          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className={`min-w-0 flex-1 flex flex-col transition-all duration-200 ${sidebarOpen ? 'md:mr-64' : 'mr-0'}`}>
        {/* Top bar */}
        <header className="sticky top-0 z-20 h-16 shrink-0 bg-background border-b border-border flex items-center gap-2 px-3 md:gap-4 md:px-6 shadow-sm">
          <Button
            variant="outline"
            size="icon"
            onClick={() => setSidebarOpen(v => !v)}
            className="rounded-xl text-gray-500"
          >
            {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </Button>
          <div>
            <p className="text-[10px] text-gray-400">پنل مدیریت</p>
            <p className="text-base font-semibold text-slate-800">{getPageTitle()}</p>
          </div>
          <div className="flex-1" />

          {/* Notifs */}
          <div className="relative">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setNotifOpen(v => !v)}
              className="relative rounded-xl text-gray-500"
            >
              <Bell size={16} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </Button>
            <AnimatePresence>
              {notifOpen && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="absolute left-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-50">
                  <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <span className="text-sm text-gray-700">اعلان‌ها</span>
                    <span className="text-xs text-[#156394]">{toPersianNumber(3)} جدید</span>
                  </div>
                  {[
                    { text: 'موجودی شیر توپی برنجی به پایان رسید', time: '۵ دقیقه پیش', type: 'warn' },
                    { text: 'پیش‌فاکتور جدید از مشتری احمدی', time: '۲۰ دقیقه پیش', type: 'info' },
                    { text: 'خطا در اتصال به حسابداری رفع شد', time: '۱ ساعت پیش', type: 'success' },
                  ].map((n, i) => (
                    <div key={i} className="px-4 py-3 border-b border-gray-50 hover:bg-gray-50 cursor-pointer">
                      <p className="text-xs text-gray-700 mb-1">{n.text}</p>
                      <p className="text-[10px] text-gray-400">{n.time}</p>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Profile */}
          <div
            className="relative"
            onMouseEnter={() => setProfileOpen(true)}
            onMouseLeave={() => setProfileOpen(false)}
          >
            <Button
              variant="ghost"
              className="h-auto rounded-xl px-2 py-1.5 hover:bg-slate-50"
              onClick={() => setProfileOpen(open => !open)}
            >
              <Avatar className="size-9 rounded-xl border border-brand/15 shadow-sm">
                <AvatarImage src={currentStaff.avatar} alt={currentStaff.name} />
                <AvatarFallback className="rounded-xl bg-brand/10 text-brand"><UserRound size={17} /></AvatarFallback>
              </Avatar>
              <span className="hidden text-right sm:block">
                <span className="block text-xs font-medium text-slate-700">مدیریت سایت</span>
                <span className="block text-[10px] font-normal text-slate-400">مدیر سیستم</span>
              </span>
              <ChevronDown size={13} className={`text-slate-400 transition-transform ${profileOpen ? 'rotate-180' : ''}`} />
            </Button>
            <AnimatePresence>
              {profileOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="absolute left-0 top-full w-56 pt-2"
                >
                  <div className="overflow-hidden rounded-2xl border border-gray-100 bg-white p-2 shadow-2xl">
                    <div className="border-b border-gray-100 px-3 py-2.5">
                      <p className="text-xs font-medium text-slate-700">مدیریت سایت</p>
                      <p className="mt-0.5 text-[10px] text-slate-400">admin@sanatpaytakhat.com</p>
                    </div>
                    <Button
                      variant="ghost"
                      onClick={() => navigate('/account')}
                      className="mt-1 w-full justify-start rounded-xl text-xs font-normal text-slate-600"
                    >
                      <UserRound size={14} />
                      مشاهده پروفایل
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => { setProfileOpen(false); navigate('/dashboard/shortcuts'); }}
                      className="w-full justify-start rounded-xl text-xs font-normal text-slate-600"
                    >
                      <Keyboard size={14} />
                      منوی شورتکات‌ها
                      <span dir="ltr" className="mr-auto rounded border border-border px-1.5 py-0.5 text-xs text-muted-foreground">{loadShortcuts().shortcuts || '—'}</span>
                    </Button>
                    <Button
                      variant="ghost"
                      onClick={() => navigate('/')}
                      className="w-full justify-start rounded-xl text-xs font-normal text-red-500 hover:bg-red-50 hover:text-red-600"
                    >
                      <LogOut size={14} />
                      خروج از حساب
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
