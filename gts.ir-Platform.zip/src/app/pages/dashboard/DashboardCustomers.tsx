import { useState } from 'react';
import { motion } from 'motion/react';
import {
  Users, Phone, Mail, Star, AlertTriangle, TrendingUp,
  Search, Plus, MoreVertical, ChevronDown, Award, Clock
} from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};
const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

type Stage = 'new' | 'follow' | 'quoted' | 'won' | 'lost' | 'at_risk';

interface Customer {
  id: number; name: string; phone: string; company?: string;
  totalPurchase: number; orderCount: number; lastPurchase: string;
  stage: Stage; source: string; daysInactive: number; score: number;
  category: string;
}

const CUSTOMERS: Customer[] = [
  { id: 1, name: 'مهندس علی احمدی', phone: '09123456789', company: 'شرکت ساخت و ساز آینده', totalPurchase: 142000000, orderCount: 12, lastPurchase: '۵ روز پیش', stage: 'won', source: 'گوگل', daysInactive: 5, score: 95, category: 'VIP' },
  { id: 2, name: 'استخر فروشی رضایی', phone: '09351234567', company: undefined, totalPurchase: 89500000, orderCount: 8, lastPurchase: '۱۲ روز پیش', stage: 'follow', source: 'اینستاگرام', daysInactive: 12, score: 80, category: 'فعال' },
  { id: 3, name: 'پروژه دماوند', phone: '02144445555', company: 'گروه ساختمانی دماوند', totalPurchase: 285000000, orderCount: 22, lastPurchase: '۶۲ روز پیش', stage: 'at_risk', source: 'معرفی', daysInactive: 62, score: 40, category: 'در خطر ریزش' },
  { id: 4, name: 'محمد علی‌زاده', phone: '09209876543', company: undefined, totalPurchase: 14200000, orderCount: 3, lastPurchase: '۳ روز پیش', stage: 'quoted', source: 'تبلیغات', daysInactive: 3, score: 65, category: 'فعال' },
  { id: 5, name: 'شرکت پارس ساخت', phone: '02166667777', company: 'پارس ساخت و تجهیز', totalPurchase: 412000000, orderCount: 34, lastPurchase: '۸ روز پیش', stage: 'won', source: 'گوگل', daysInactive: 8, score: 98, category: 'VIP' },
  { id: 6, name: 'حسن محمدپور', phone: '09181234321', company: undefined, totalPurchase: 8500000, orderCount: 2, lastPurchase: '۹۰ روز پیش', stage: 'at_risk', source: 'سایت', daysInactive: 90, score: 25, category: 'در خطر ریزش' },
  { id: 7, name: 'مجتمع مسکونی سبز', phone: '02188889999', company: 'سازه‌های سبز ایران', totalPurchase: 0, orderCount: 0, lastPurchase: '—', stage: 'new', source: 'اینستاگرام', daysInactive: 0, score: 50, category: 'جدید' },
  { id: 8, name: 'تأسیسات صادقی', phone: '09141112233', company: undefined, totalPurchase: 32000000, orderCount: 5, lastPurchase: '۴۵ روز پیش', stage: 'lost', source: 'تبلیغات', daysInactive: 45, score: 20, category: 'از دست رفته' },
];

const stageCfg: Record<Stage, { label: string; color: string; bg: string }> = {
  new:      { label: 'جدید',              color: 'text-blue-600',   bg: 'bg-blue-50 border-blue-200' },
  follow:   { label: 'در حال پیگیری',    color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  quoted:   { label: 'پیش‌فاکتور ارسال', color: 'text-purple-600', bg: 'bg-purple-50 border-purple-200' },
  won:      { label: 'خرید انجام شد',    color: 'text-green-600',  bg: 'bg-green-50 border-green-200' },
  lost:     { label: 'از دست رفته',      color: 'text-gray-500',   bg: 'bg-gray-50 border-gray-200' },
  at_risk:  { label: 'در خطر ریزش',      color: 'text-red-600',    bg: 'bg-red-50 border-red-200' },
};

function ScoreBar({ score }: { score: number }) {
  const color = score >= 80 ? '#10b981' : score >= 50 ? '#F2B524' : '#ef4444';
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${score}%`, background: color }} />
      </div>
      <span className="text-[10px] text-gray-500 w-6">{toPersianNumber(score)}</span>
    </div>
  );
}

export function DashboardCustomers() {
  const [search, setSearch] = useState('');
  const [stageFilter, setStageFilter] = useState<Stage | 'all'>('all');

  const filtered = CUSTOMERS.filter(c => {
    const s = stageFilter === 'all' || c.stage === stageFilter;
    const q = !search || c.name.includes(search) || c.phone.includes(search);
    return s && q;
  });

  const atRisk = CUSTOMERS.filter(c => c.stage === 'at_risk').length;
  const vipCount = CUSTOMERS.filter(c => c.category === 'VIP').length;
  const totalValue = CUSTOMERS.reduce((s, c) => s + c.totalPurchase, 0);

  return (
    <div className="p-6 space-y-5">
      <div className="flex items-center justify-end">
        <button className="flex items-center gap-2 px-4 py-2.5 bg-[#156394] text-white rounded-xl text-sm hover:bg-[#0d4a6f] transition-colors shadow-md">
          <Plus size={15} /> افزودن مشتری
        </button>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'کل مشتریان', value: toPersianNumber(CUSTOMERS.length), icon: Users, color: '#156394' },
          { label: 'مشتریان VIP', value: toPersianNumber(vipCount), icon: Award, color: '#F2B524' },
          { label: 'در خطر ریزش', value: toPersianNumber(atRisk), icon: AlertTriangle, color: '#ef4444' },
          { label: 'ارزش کل خریدها', value: formatPrice(totalValue / 1000000) + ' م', icon: TrendingUp, color: '#10b981' },
        ].map((k, i) => {
          const Icon = k.icon;
          return (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: k.color + '18' }}>
                <Icon size={18} style={{ color: k.color }} />
              </div>
              <div>
                <p className="text-xs text-gray-500">{k.label}</p>
                <p className="text-xl text-gray-900">{k.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* At-risk alert */}
      {atRisk > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl px-5 py-3 flex items-center gap-3">
          <AlertTriangle size={16} className="text-red-500 shrink-0" />
          <p className="text-sm text-red-700">
            <strong>{toPersianNumber(atRisk)} مشتری</strong> بیش از ۶۰ روز خرید نکرده‌اند. توصیه: ارسال پیشنهاد ویژه یا تماس پیگیری.
          </p>
          <button className="mr-auto px-3 py-1.5 bg-red-500 text-white rounded-xl text-xs hover:bg-red-600 transition-colors shrink-0">
            پیگیری
          </button>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-xs">
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی مشتری..."
            className="w-full pr-9 pl-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
          <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {[['all', 'همه'], ['at_risk', 'در خطر ریزش'], ['won', 'خریدار'], ['new', 'جدید'], ['lost', 'از دست رفته']].map(([k, l]) => (
            <button key={k} onClick={() => setStageFilter(k as any)}
              className={`px-3 py-1.5 rounded-full text-xs transition-all border
                ${stageFilter === k ? 'bg-[#156394] text-white border-[#156394]' : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394] hover:text-[#156394]'}`}>
              {l}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50/70 border-b border-gray-100 text-xs text-gray-500">
                {['مشتری', 'تماس', 'منبع ورود', 'جمع خرید', 'سفارشات', 'آخرین خرید', 'امتیاز', 'مرحله فروش'].map(h => (
                  <th key={h} className="px-4 py-3 text-right">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => {
                const st = stageCfg[c.stage];
                return (
                  <motion.tr key={c.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors cursor-pointer">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs text-white shrink-0
                          ${c.category === 'VIP' ? 'bg-[#F2B524]' : c.stage === 'at_risk' ? 'bg-red-400' : 'bg-[#156394]'}`}>
                          {c.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-xs text-gray-800">{c.name}</p>
                          {c.company && <p className="text-[10px] text-gray-400">{c.company}</p>}
                        </div>
                        {c.category === 'VIP' && <Award size={12} className="text-[#F2B524]" />}
                        {c.stage === 'at_risk' && <AlertTriangle size={12} className="text-red-400" />}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-gray-500">{c.phone}</td>
                    <td className="px-4 py-3.5">
                      <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-[10px]">{c.source}</span>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-[#156394]">{formatPrice(c.totalPurchase)} ت</td>
                    <td className="px-4 py-3.5 text-xs text-gray-600">{toPersianNumber(c.orderCount)} سفارش</td>
                    <td className="px-4 py-3.5 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        {c.daysInactive > 60 && <Clock size={11} className="text-red-400" />}
                        {c.lastPurchase}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 w-28">
                      <ScoreBar score={c.score} />
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-[10px] border ${st.bg} ${st.color}`}>
                        {st.label}
                      </span>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
