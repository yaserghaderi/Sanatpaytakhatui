import { useEffect, useRef, useState, type KeyboardEvent, type FocusEvent as ReactFocusEvent, type MouseEvent as ReactMouseEvent } from 'react';
import { flushSync } from 'react-dom';
import { Check, Pencil, Trash2, X } from 'lucide-react';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import LocalizedNumberInput from '../../components/LocalizedNumberInput';
import { Popover, PopoverAnchor, PopoverContent } from '../../components/ui/popover';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../../components/ui/table';
import type { InvoiceLine } from './DashboardOrders';
import FormattedNumberInput from './FormattedNumberInput';
import { groupedNumber } from '../../data/numberFormatting';

export const sampleCatalog = [
  { name: 'شیر توپی برنجی', code: 'SP-1001', specs: 'سایز ۱/۲ اینچ · برنجی', unit: 'عدد' },
  { name: 'لوله پلی‌اتیلن PE100', code: 'SP-1002', specs: 'قطر ۲۵ میلی‌متر · PE100', unit: 'متر' },
  { name: 'فلنج گلودار DN100', code: 'SP-1003', specs: 'DN100 · PN16', unit: 'عدد' },
  { name: 'پمپ سیرکولاتور', code: 'SP-1004', specs: 'توان ۱ اسب بخار', unit: 'دستگاه' },
  { name: 'زانو PVC', code: 'SP-1005', specs: 'زاویه ۹۰ درجه · قطر ۵۰', unit: 'عدد' },
];
const fa = groupedNumber;
const money = (n: number) => n.toLocaleString('fa-IR', { maximumFractionDigits: 0 });
const statusLabel = { priced: 'قیمت‌دار', unpriced: 'بدون قیمت', unmatched: 'پیدا نشد' };
const normalize = (text: string) => text.replace(/ي/g, 'ی').replace(/ك/g, 'ک').trim().toLowerCase();
export default function InvoiceItemsTable({ lines, editing, setEditing, locked, showNotes, showAi, onSave, onDelete, onNewLine }: {
  lines: InvoiceLine[]; editing: InvoiceLine | null; setEditing: (line: InvoiceLine | null) => void; locked: boolean;
  showNotes: boolean; showAi: boolean; onSave: (line: InvoiceLine, finish: boolean) => boolean; onDelete: (line: InvoiceLine) => void;
  onNewLine: () => void;
}) {
  const [suggestions, setSuggestions] = useState(false);
  const pendingFocus = useRef<{ rowId: string; field: string } | null>(null);
  const focusField = (rowId: string, key: string) => {
    const name = document.getElementById(`product-name-${rowId}`) as HTMLInputElement | null;
    const field = name?.closest('tr')?.querySelector<HTMLInputElement>(`input[data-edit-field="${key}"]`) ?? name;
    field?.focus();
    field?.select();
  };
  const finishEditing = () => {
    if (!editing || locked) return true;
    const original = lines.find(line => line.id === editing.id);
    if (original && JSON.stringify({ ...original, discount: original.discount ?? 0 }) === JSON.stringify(editing)) {
      setEditing(null);
      return true;
    }
    if (!original && !editing.name.trim() && editing.qty === 1 && editing.price === 0 && !editing.note && !editing.aiText && !editing.code) {
      setEditing(null);
      return true;
    }
    return onSave(editing, true);
  };
  useEffect(() => {
    if (!editing || locked) return;
    const handleOutsideClick = (event: MouseEvent) => {
      const target = event.target;
      if (!(target instanceof Element) || target.closest(`[data-invoice-row="${editing.id}"]`)) return;
      let saved = false;
      // Finish before the destination's click handler reads the invoice state.
      flushSync(() => { saved = finishEditing(); });
      if (!saved) { event.preventDefault(); event.stopImmediatePropagation(); }
    };
    document.addEventListener('click', handleOutsideClick, true);
    return () => document.removeEventListener('click', handleOutsideClick, true);
  }, [editing, lines, locked, onSave]);
  useEffect(() => {
    if (!editing || locked) return;
    const frame = requestAnimationFrame(() => {
      const target = pendingFocus.current;
      pendingFocus.current = null;
      focusField(editing.id, target?.rowId === editing.id ? target.field : 'name');
    });
    return () => cancelAnimationFrame(frame);
  }, [editing?.id, locked]);
  const moveNext = (field: HTMLInputElement) => {
    const fields = Array.from(field.closest('tr')?.querySelectorAll<HTMLInputElement>('input:not(:disabled)') ?? []);
    const next = fields[fields.indexOf(field) + 1];
    if (next) { next.focus(); next.select(); }
    else if (editing) onSave(editing, true);
  };
  const handleEnter = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key !== 'Enter' || event.nativeEvent.isComposing || !editing) return;
    event.preventDefault();
    setSuggestions(false);
    if (event.shiftKey) {
      if (onSave(editing, true)) onNewLine();
    } else moveNext(event.currentTarget);
  };
  const update = (key: keyof InvoiceLine, value: string | number) => { if (editing) setEditing({ ...editing, [key]: value }); };
  const candidates = sampleCatalog.filter(product => normalize(`${product.name} ${product.code}`).includes(normalize(editing?.name ?? '')));
  const choose = (product: typeof sampleCatalog[number]) => {
    if (!editing) return;
    const next = { ...editing, ...product, status: 'unpriced' as const, price: 0 };
    setEditing(next); setSuggestions(false); onSave(next, false);
    requestAnimationFrame(() => (document.getElementById(`product-name-${next.id}`) as HTMLInputElement | null)?.closest('tr')?.querySelector<HTMLInputElement>('[aria-label="تعداد"]')?.focus());
  };
  const input = (key: 'qty' | 'unit' | 'price' | 'discount' | 'note' | 'aiText', numeric = false) => {
    const props = {
      'data-edit-field': key,
      'aria-label': { qty: 'تعداد', unit: 'واحد', price: 'قیمت واحد', discount: 'درصد تخفیف', note: 'توضیحات', aiText: 'متن AI' }[key],
      onFocus: (event: ReactFocusEvent<HTMLInputElement>) => event.currentTarget.select(),
      onClick: (event: ReactMouseEvent<HTMLInputElement>) => event.currentTarget.select(),
      onKeyDown: handleEnter,
      className: `h-8 rounded-md border-brand/40 bg-background px-2 text-xs shadow-sm focus-visible:border-brand focus-visible:ring-brand/25 ${key === 'price' ? 'w-32' : numeric ? 'w-20' : key === 'note' || key === 'aiText' ? 'w-full' : 'w-24'}`,
    };
    return numeric
      ? <LocalizedNumberInput {...props} value={Number(editing?.[key] ?? 0)} allowDecimal={key !== 'price'} groupThousands={key !== 'discount'} onValueChange={value => update(key, Number(value))} />
      : <Input {...props} value={editing?.[key] ?? (key === 'unit' ? 'عدد' : '')} onChange={event => update(key, event.target.value)} />;
  };
  const rendered = editing && !lines.some(l => l.id === editing.id) ? [editing, ...lines] : lines;
  return <div className="overflow-visible">
    <Table className="text-xs"><TableHeader><TableRow className="bg-muted/30 [&>th]:h-9 [&>th]:px-2 [&>th]:text-right">
      <TableHead scope="col" className="w-10 !text-center text-xs text-muted-foreground">ردیف</TableHead>
      {['کالا', 'مشخصات', 'تعداد', 'واحد', 'وضعیت', 'قیمت واحد', 'تخفیف', 'مبلغ نهایی', 'عملیات'].map(label => <TableHead key={label}>{label}</TableHead>)}
    </TableRow></TableHeader><TableBody>{rendered.map((line, index) => {
      const isEditing = editing?.id === line.id && !locked;
      const value = isEditing ? editing : line;
      const status = !value.code.trim() ? 'unmatched' : value.price > 0 ? 'priced' : 'unpriced';
      return <TableRow key={line.id} data-invoice-row={line.id}
        onClick={event => {
          const target = event.target as Element;
          if (locked || target.closest('button, input, [role="option"]')) return;
          const field = target.closest<HTMLElement>('[data-edit-field]')?.dataset.editField ?? 'name';
          if (isEditing) { focusField(line.id, field); return; }
          if (!finishEditing()) return;
          pendingFocus.current = { rowId: line.id, field };
          setEditing({ ...line, discount: line.discount ?? 0 });
          setSuggestions(false);
        }}
        className={`[&>td]:px-2 [&>td]:py-1.5 ${!locked ? 'cursor-pointer' : ''} ${isEditing ? 'bg-brand/10 ring-1 ring-inset ring-brand/25' : ''}`}>
        <TableCell className="w-10 text-center text-xs tabular-nums text-muted-foreground">{fa(index + 1)}</TableCell>
        <TableCell data-edit-field="name"><div className="min-w-56 max-w-80">{isEditing ? <Popover open={suggestions} onOpenChange={setSuggestions}>
          <PopoverAnchor asChild><div><Input data-edit-field="name" id={`product-name-${line.id}`} aria-label="جستجوی نام یا کد محصول" role="combobox" aria-expanded={suggestions} aria-controls={`product-results-${line.id}`} value={editing.name} onFocus={e => { e.currentTarget.select(); setSuggestions(true); }} onClick={e => e.currentTarget.select()} onChange={e => { update('name', e.target.value); setSuggestions(true); }}
            onKeyDown={e => { if (e.nativeEvent.isComposing) return; handleEnter(e); if (e.key === 'ArrowDown') { e.preventDefault(); document.getElementById(`product-option-${line.id}-0`)?.focus(); } }}
            className="h-8 w-56 rounded-md border-brand/40 bg-background px-2 text-xs shadow-sm focus-visible:border-brand focus-visible:ring-brand/25" /></div></PopoverAnchor>
          <PopoverContent data-invoice-row={line.id} dir="rtl" align="start" onOpenAutoFocus={e => e.preventDefault()} onCloseAutoFocus={e => e.preventDefault()} className="w-72 p-1">
            <p className="px-2 py-1 text-xs text-muted-foreground">انتخاب محصول</p><div role="listbox" id={`product-results-${line.id}`}>{candidates.map((product, i) => <Button id={`product-option-${line.id}-${i}`} role="option" aria-selected={editing.code === product.code} key={product.code} variant="ghost" onClick={() => choose(product)} className="h-auto w-full justify-between px-2 py-2 text-xs font-normal"><span>{product.name}</span><span className="text-muted-foreground">{product.code}</span></Button>)}{!candidates.length && <p className="p-3 text-xs text-muted-foreground">محصولی پیدا نشد.</p>}</div>
          </PopoverContent>
        </Popover> : <span title={line.name} className="block max-w-64 truncate font-medium">{line.name}</span>}
          {showNotes && <div data-edit-field="note" className="mt-1.5 flex items-center gap-1 text-xs text-muted-foreground"><span className="shrink-0">توضیح:</span>{isEditing ? input('note') : <span className="whitespace-normal break-words">{line.note || 'ثبت نشده'}</span>}</div>}
          {showAi && <div data-edit-field="aiText" className="mt-1.5 flex items-center gap-1 text-xs text-brand"><span className="shrink-0">AI:</span>{isEditing ? input('aiText') : <span className="whitespace-normal break-words">{line.aiText || 'ورود دستی'}</span>}</div>}
          {(showNotes || showAi) && <div className="mt-1.5 text-xs text-muted-foreground">کد کالا: <span dir="ltr">{value.code || '—'}</span></div>}
        </div></TableCell>
        <TableCell><span title={value.specs} className="block max-w-44 truncate text-muted-foreground">{value.specs || '—'}</span></TableCell>
        <TableCell data-edit-field="qty">{isEditing ? input('qty', true) : fa(line.qty)}</TableCell>
        <TableCell data-edit-field="unit">{isEditing ? input('unit') : line.unit || 'عدد'}</TableCell>
        <TableCell><span title="وضعیت کالا" className={`rounded-md px-1.5 py-1 text-xs ${status === 'priced' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>{statusLabel[status]}</span></TableCell>
        <TableCell data-edit-field="price">{isEditing ? input('price', true) : money(line.price)}</TableCell>
        <TableCell data-edit-field="discount">{isEditing ? input('discount', true) : `${fa(line.discount ?? 0)}٪`}</TableCell>
        <TableCell className="font-medium text-brand">{money(Math.round(value.qty * value.price * (1 - (value.discount ?? 0) / 100)))}</TableCell>
        <TableCell><div className="flex gap-0.5">{isEditing ? <><Button variant="ghost" disabled={locked} size="icon" aria-label="ذخیره و پایان ویرایش" onClick={() => { setSuggestions(false); onSave(editing, true); }} className="size-8 text-brand"><Check size={14} /></Button><Button variant="ghost" size="icon" aria-label="پایان ویرایش" onClick={() => { setEditing(null); setSuggestions(false); }} className="size-8"><X size={14} /></Button></> : <Button variant="ghost" disabled={locked} size="icon" aria-label={`ویرایش ${line.name}`} onClick={() => { setEditing({ ...line, discount: line.discount ?? 0 }); setSuggestions(false); }} className="size-8"><Pencil size={14} /></Button>}<Button variant="ghost" disabled={locked} size="icon" aria-label={`حذف ${line.name}`} onClick={() => onDelete(line)} className="size-8 text-destructive"><Trash2 size={14} /></Button></div></TableCell>
      </TableRow>;
    })}</TableBody></Table>
  </div>;
}
