import DashboardOrders from './DashboardOrders';

export default function DashboardPurchases() {
  return <DashboardOrders key="purchase" kind="purchase" />;
}
