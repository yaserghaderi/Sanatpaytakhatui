import { createContext, useContext, useState } from 'react';

interface SmartOrderContextType {
  isOpen: boolean;
  openSmartOrder: () => void;
  closeSmartOrder: () => void;
}

const SmartOrderContext = createContext<SmartOrderContextType>({
  isOpen: false,
  openSmartOrder: () => {},
  closeSmartOrder: () => {},
});

export function SmartOrderProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <SmartOrderContext.Provider value={{ isOpen, openSmartOrder: () => setIsOpen(true), closeSmartOrder: () => setIsOpen(false) }}>
      {children}
    </SmartOrderContext.Provider>
  );
}

export const useSmartOrder = () => useContext(SmartOrderContext);
