
  # Design New Homepage

  This is a code bundle for Design New Homepage. The original project is available at https://www.figma.com/design/XrIwuLyYvOZcIbPpLNpx8M/Design-New-Homepage.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  