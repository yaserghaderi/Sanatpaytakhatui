import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Brands } from './components/Brands';
import { FeaturedProducts } from './components/FeaturedProducts';
import { CategoryProducts } from './components/CategoryProducts';
import { AboutUs } from './components/AboutUs';
import { Clients } from './components/Clients';
import { Features } from './components/Features';
import { FAQ } from './components/FAQ';
import { PoolCalculator } from './components/PoolCalculator';
import { Footer } from './components/Footer';
import { CartProvider, useCart } from './contexts/CartContext';
import { Toaster } from 'sonner';
import { CartDrawer } from './components/CartDrawer';
import { FloatingQuoteButton } from './components/FloatingQuoteButton';

function AppContent() {
  const { isCartOpen, closeCart } = useCart();

  return (
    <div className="min-h-screen bg-white" dir="rtl">
      <Toaster position="top-center" richColors />
      <Header />
      <main>
        <Hero />
        <FeaturedProducts />
        <CategoryProducts 
          category="لوله و اتصالات"
          title="لوله و اتصالات"
          description="محصولات با کیفیت برای سیستم‌های آب‌رسانی و لوله‌کشی صنعتی"
          bgGradient="from-white via-gray-50 to-white"
        />
        <CategoryProducts 
          category="استخر و جکوزی"
          title="استخر و جکوزی"
          description="تجهیزات کامل برای ساخت و نگهداری استخر و جکوزی"
          bgGradient="from-blue-50/30 via-white to-blue-50/30"
        />
        <AboutUs />
        <Clients />
        <Brands />
        <Features />
        <FAQ />
        <PoolCalculator />
      </main>
      <Footer />
      <CartDrawer isOpen={isCartOpen} onClose={closeCart} />
      <FloatingQuoteButton />
    </div>
  );
}

export default function App() {
  return (
    <CartProvider>
      <AppContent />
    </CartProvider>
  );
}