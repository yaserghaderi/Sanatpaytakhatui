import { useState, useEffect } from 'react';
import { Search, ShoppingCart, User, Menu, X, ChevronDown, Droplets, Wrench, Link2, Layers, Sparkles, Box, Plus, FileText } from 'lucide-react';
import { Button } from './ui/button';
import logo from 'figma:asset/e2bf7b3e45975301863221e28611d21b5c7fdd37.png';
import SolarCodeScanBold from '../../imports/SolarCodeScanBold';
import { useCart } from '../contexts/CartContext';
import { CartDrawer } from './CartDrawer';
import { toast } from 'sonner';

// تبدیل اعداد به فارسی
const toPersianNumber = (num: number | string) => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (digit) => persianDigits[parseInt(digit)]);
};

const categories = [
  { 
    name: 'لوله و اتصالات',
    href: '#',
    icon: Link2,
    color: 'from-blue-500 to-cyan-500',
    subcategories: [
      'لوله PVC',
      'لوله پلی‌اتیلن',
      'لوله مسی',
      'اتصالات فلزی',
      'اتصالات پلاستیکی',
      'سه‌راهی و چهارراهی'
    ]
  },
  { 
    name: 'شیرآلات',
    href: '#',
    icon: Droplets,
    color: 'from-purple-500 to-pink-500',
    subcategories: [
      'شیر توپی',
      'شیر برقی',
      'شیر فشار شکن',
      'شیر یکطرفه',
      'شیر کشویی',
      'شیر پروانه‌ای'
    ]
  },
  { 
    name: 'فلنج و متعلقات',
    href: '#',
    icon: Layers,
    color: 'from-orange-500 to-red-500',
    subcategories: [
      'فلنج گلودار',
      'فلنج ساده',
      'فلنج کور',
      'پیچ و مهره فلنج',
      'واشر فلنج',
      'گسکت'
    ]
  },
  { 
    name: 'استخر و جکوزی',
    href: '#',
    icon: Sparkles,
    color: 'from-cyan-500 to-blue-500',
    subcategories: [
      'پمپ استخر',
      'فیلتر شنی',
      'جت‌های جکوزی',
      'نورپردازی استخر',
      'سیستم تصفیه',
      'لوازم نگهداری'
    ]
  },
  { 
    name: 'چسب',
    href: '#',
    icon: Box,
    color: 'from-green-500 to-emerald-500',
    subcategories: [
      'چسب PVC',
      'چسب پلی‌اتیلن',
      'چسب دوجزئی',
      'چسب سیلیکونی',
      'نوار تفلون',
      'مواد آب‌بندی'
    ]
  },
  { 
    name: 'ابزار لوله‌کشی',
    href: '#',
    icon: Wrench,
    color: 'from-amber-500 to-yellow-500',
    subcategories: [
      'آچار لوله',
      'برش‌زن لوله',
      'پرس لوله',
      'دستگاه جوش',
      'رزوه‌زن',
      'خم‌کن لوله'
    ]
  },
];

const allProducts = [
  { 
    id: 1,
    name: 'شیر توپی سنگین', 
    category: 'شیرآلات', 
    price: 7500000,
    image: 'https://images.unsplash.com/photo-1759148414485-5f624fe9d1ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwdmFsdmV8ZW58MXx8fHwxNzY2MzQxOTQwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '1/4"', price: 4200000 },
      { size: '3/8"', price: 5100000 },
      { size: '1/2"', price: 6500000 },
      { size: '3/4"', price: 7500000 },
      { size: '1"', price: 8500000 },
      { size: '1.25"', price: 9500000 },
      { size: '1.5"', price: 10500000 },
      { size: '2"', price: 13500000 },
      { size: '2.5"', price: 16500000 },
      { size: '3"', price: 21500000 }
    ]
  },
  { 
    id: 2,
    name: 'سیستم فیلتراسیون استخر', 
    category: 'استخر و جکوزی', 
    price: 52000000,
    image: 'https://images.unsplash.com/photo-1561722504-1c2e7d7952e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzd2ltbWluZyUyMHBvb2wlMjBmaWx0ZXJ8ZW58MXx8fHwxNzY2MzQxOTQwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: 'کوچک 300mm', price: 38000000 },
      { size: 'کوچک 400mm', price: 45000000 },
      { size: 'متوسط 500mm', price: 52000000 },
      { size: 'متوسط 600mm', price: 58000000 },
      { size: 'بزرگ 750mm', price: 65000000 },
      { size: 'بزرگ 900mm', price: 75000000 },
      { size: 'صنعتی 1050mm', price: 89000000 },
      { size: 'صنعتی 1200mm', price: 105000000 }
    ]
  },
  { 
    id: 3,
    name: 'ست لوله PVC صنعتی', 
    category: 'لوله و اتصالات', 
    price: 10000000,
    image: 'https://images.unsplash.com/photo-1729169927271-7826d8aae360?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdmMlMjBwaXBlc3xlbnwxfHx8fDE3NjYzNDE5NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '16mm', price: 6500000 },
      { size: '20mm', price: 8000000 },
      { size: '25mm', price: 10000000 },
      { size: '32mm', price: 12000000 },
      { size: '40mm', price: 15000000 },
      { size: '50mm', price: 19000000 },
      { size: '63mm', price: 24000000 },
      { size: '75mm', price: 28000000 },
      { size: '90mm', price: 35000000 },
      { size: '110mm', price: 45000000 }
    ]
  },
  { 
    id: 4,
    name: 'آچار لوله حرفه‌ای', 
    category: 'ابزار لوله‌کشی', 
    price: 3200000,
    image: 'https://images.unsplash.com/photo-1761074342668-c38fc2e62e67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwaXBlJTIwd3JlbmNoJTIwdG9vbHxlbnwxfHx8fDE3NjYzNDE5NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '6"', price: 1800000 },
      { size: '8"', price: 2200000 },
      { size: '10"', price: 2800000 },
      { size: '12"', price: 3200000 },
      { size: '14"', price: 3800000 },
      { size: '18"', price: 4800000 },
      { size: '24"', price: 6500000 },
      { size: '36"', price: 9200000 }
    ]
  },
  { 
    id: 5,
    name: 'کیت فلنج پرمیوم', 
    category: 'فلنج و متعلقات', 
    price: 14000000,
    image: 'https://images.unsplash.com/photo-1759668987649-a2057d0a9f35?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwZmxhbmdlfGVufDF8fHx8MTc2NjM0MTk0MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: 'DN25', price: 8500000 },
      { size: 'DN32', price: 10000000 },
      { size: 'DN40', price: 11500000 },
      { size: 'DN50', price: 12000000 },
      { size: 'DN65', price: 13000000 },
      { size: 'DN80', price: 14000000 },
      { size: 'DN100', price: 18000000 },
      { size: 'DN125', price: 22000000 },
      { size: 'DN150', price: 28000000 },
      { size: 'DN200', price: 38000000 }
    ]
  },
  { 
    id: 6,
    name: 'ست جت‌های جکوزی لوکس', 
    category: 'استخر و جکوزی', 
    price: 36000000,
    image: 'https://images.unsplash.com/photo-1700692883566-c1941832499f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYWN1enppJTIwamV0c3xlbnwxfHx8fDE3NjYzNDE5NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '2 عددی', price: 18000000 },
      { size: '4 عددی', price: 28000000 },
      { size: '6 عددی', price: 36000000 },
      { size: '8 عددی', price: 48000000 },
      { size: '10 عددی', price: 58000000 },
      { size: '12 عددی', price: 68000000 }
    ]
  },
  { 
    id: 7,
    name: 'لوله مسی صنعتی', 
    category: 'لوله و اتصالات', 
    price: 6400000,
    image: 'https://images.unsplash.com/photo-1725278484798-4d412a512e8d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3BwZXIlMjBwaXBlJTIwaW5kdXN0cmlhbHxlbnwxfHx8fDE3NjYzNDE5NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '1/4"', price: 5200000 },
      { size: '3/8"', price: 6400000 },
      { size: '1/2"', price: 7800000 },
      { size: '5/8"', price: 8900000 },
      { size: '3/4"', price: 10200000 },
      { size: '7/8"', price: 12500000 },
      { size: '1"', price: 14800000 },
      { size: '1.25"', price: 18500000 }
    ]
  },
  { 
    id: 8,
    name: 'شیر برقی', 
    category: 'شیرآلات', 
    price: 9200000,
    image: 'https://images.unsplash.com/photo-1657183421041-a2e0d4983683?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpYyUyMHZhbHZlfGVufDF8fHx8MTc2NjM0MTk0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '1/2"', price: 8200000 },
      { size: '3/4"', price: 9200000 },
      { size: '1"', price: 11500000 },
      { size: '1.25"', price: 14200000 },
      { size: '1.5"', price: 16800000 },
      { size: '2"', price: 21500000 },
      { size: '2.5"', price: 27800000 },
      { size: '3"', price: 35500000 }
    ]
  },
  { 
    id: 9,
    name: 'چسب PVC', 
    category: 'چسب', 
    price: 1400000,
    image: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdmMlMjBnbHVlJTIwYWRoZXNpdmV8ZW58MXx8fHwxNzY2MzQxOTQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '100 گرم', price: 850000 },
      { size: '250 گرم', price: 1200000 },
      { size: '500 گرم', price: 1400000 },
      { size: '750 گرم', price: 1800000 },
      { size: '1 کیلو', price: 2200000 },
      { size: '2 کیلو', price: 3800000 },
      { size: '5 کیلو', price: 8500000 }
    ]
  },
  { 
    id: 10,
    name: 'پمپ استخر', 
    category: 'استخر و جکوزی', 
    price: 24000000,
    image: 'https://images.unsplash.com/photo-1640244444726-42ba973d2d0b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwb29sJTIwcHVtcCUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NjYyNzg3OTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    sizes: [
      { size: '0.25HP', price: 15000000 },
      { size: '0.5HP', price: 18000000 },
      { size: '0.75HP', price: 21000000 },
      { size: '1HP', price: 24000000 },
      { size: '1.5HP', price: 32000000 },
      { size: '2HP', price: 38000000 },
      { size: '3HP', price: 52000000 },
      { size: '5HP', price: 78000000 }
    ]
  },
];

const popularSearches = [
  'شیر توپی',
  'پمپ استخر',
  'لوله PVC',
  'فیلتر شنی',
  'چسب لوله',
  'اتصالات فلزی',
];

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [selectedSizes, setSelectedSizes] = useState<{[key: string]: number}>({});
  
  const { getTotalItems, toggleCart, addToCart } = useCart();

  // Scroll detection
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Filter products and categories based on search
  const filteredProducts = searchQuery.trim()
    ? allProducts.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const filteredCategories = searchQuery.trim()
    ? categories.filter(cat =>
        cat.name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const showSearchResults = isSearchFocused && searchQuery.trim() && (filteredProducts.length > 0 || filteredCategories.length > 0);

  return (
    <>
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'backdrop-blur-xl bg-white/90 border-b border-gray-200/50 shadow-sm' 
          : 'backdrop-blur-md md:bg-white/20 bg-white/80 border-b border-white/10'
      }`}>
        {/* Main Header */}
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center gap-8">
            {/* Logo */}
            <div className="flex items-center">
              <img src={logo} alt="جهان موج" className="h-10 md:h-11 w-auto" />
            </div>

            {/* Navigation - Desktop */}
            <nav className="hidden lg:flex items-center gap-2 flex-1">
              {/* Categories Button */}
              <button
                onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
                className="flex items-center gap-3 px-5 py-2.5 text-gray-700 hover:text-[#156394] transition-colors rounded-full bg-gray-100"
              >
                <div className="w-6 h-6 text-gray-700">
                  <SolarCodeScanBold />
                </div>
                <span className="text-lg">دسته‌بندی محصولات</span>
              </button>

              {/* Search Box - Desktop */}
              <div className="relative">
                <input
                  type="text"
                  placeholder="جستجو در محصولات و دسته‌بندی‌ها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  className="w-[416px] pr-10 pl-4 py-2.5 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-[#156394]/20 focus:bg-white transition-all"
                />
                <Search className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                
                {/* Close Search Button */}
                {isSearchFocused && (
                  <button
                    onClick={() => {
                      setIsSearchFocused(false);
                      setSearchQuery('');
                    }}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                {/* Live Search Results */}
                {showSearchResults && (
                  <div className="absolute top-full right-0 left-0 mt-2 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden max-h-96 overflow-y-auto">
                    {/* Categories Results */}
                    {filteredCategories.length > 0 && (
                      <div className="p-4 border-b border-gray-100">
                        <h4 className="text-xs text-gray-500 mb-2 px-2">دسته‌بندی‌ها</h4>
                        <div className="space-y-1">
                          {filteredCategories.map((cat) => (
                            <a
                              key={cat.name}
                              href={cat.href}
                              className="block px-4 py-2 text-gray-700 hover:text-[#156394] hover:bg-gradient-to-l hover:from-[#156394]/5 hover:to-[#F2B524]/5 rounded-2xl transition-all"
                            >
                              📂 {cat.name}
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Products Results */}
                    {filteredProducts.length > 0 && (
                      <div className="p-4">
                        <h4 className="text-xs text-gray-500 mb-2 px-2">محصولات</h4>
                        <div className="space-y-4">
                          {filteredProducts.slice(0, 6).map((product) => {
                            const productKey = `product-${product.id}`;
                            const selectedSizeIndex = selectedSizes[productKey] || 0;
                            const selectedSize = product.sizes[selectedSizeIndex];
                            
                            return (
                              <div
                                key={product.id}
                                className="px-3 py-3 hover:bg-gradient-to-l hover:from-[#156394]/5 hover:to-[#F2B524]/5 rounded-2xl transition-all"
                              >
                                <div className="flex items-start gap-3 mb-3">
                                  <img 
                                    src={product.image} 
                                    alt={product.name}
                                    className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                                  />
                                  <div className="flex-1 min-w-0">
                                    <div className="text-gray-900 hover:text-[#156394] mb-1 font-medium">{product.name}</div>
                                    <div className="text-xs text-gray-500 mb-2">{product.category}</div>
                                    
                                    {/* Selected Size Price */}
                                    <div className="text-sm font-semibold text-[#156394]">
                                      {toPersianNumber(selectedSize.price.toLocaleString())} تومان
                                    </div>
                                  </div>
                                </div>
                                
                                {/* Size Selection Row */}
                                <div className="flex items-center gap-2">
                                  {/* Scrollable Size Buttons */}
                                  <div className="flex-1 overflow-x-auto scrollbar-hide">
                                    <div className="flex gap-1.5 pb-1">
                                      {product.sizes.map((sizeOption, sizeIndex) => (
                                        <button
                                          key={sizeIndex}
                                          onClick={() => {
                                            setSelectedSizes(prev => ({
                                              ...prev,
                                              [productKey]: sizeIndex
                                            }));
                                          }}
                                          className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all whitespace-nowrap ${
                                            selectedSizeIndex === sizeIndex
                                              ? 'bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white shadow-md'
                                              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                          }`}
                                        >
                                          {sizeOption.size}
                                        </button>
                                      ))}
                                    </div>
                                  </div>
                                  
                                  {/* Add Button */}
                                  <button
                                    onClick={(e) => {
                                      e.preventDefault();
                                      addToCart({
                                        productId: product.id,
                                        productName: product.name,
                                        productCategory: product.category,
                                        productImage: product.image,
                                        size: selectedSize.size,
                                        price: selectedSize.price,
                                        discount: product.discount,
                                      });
                                      toast.success(`${product.name} (${selectedSize.size}) به پیش‌فاکتور اضافه شد`, {
                                        duration: 2000,
                                      });
                                    }}
                                    className="flex-shrink-0 p-2 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white rounded-full hover:shadow-lg hover:scale-105 transition-all"
                                  >
                                    <Plus className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* No Results */}
                    {filteredProducts.length === 0 && filteredCategories.length === 0 && (
                      <div className="p-6 text-center text-gray-500">
                        نتیجه‌ای یافت نشد
                      </div>
                    )}
                  </div>
                )}

                {/* Popular Searches - When focused but empty */}
                {isSearchFocused && !searchQuery.trim() && (
                  <div className="absolute top-full right-0 left-0 mt-2 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden p-4">
                    <h4 className="text-xs text-gray-500 mb-3 px-2">جستجوهای محبوب</h4>
                    <div className="flex flex-wrap gap-2">
                      {popularSearches.map((search) => (
                        <button
                          key={search}
                          onClick={() => setSearchQuery(search)}
                          className="px-4 py-2 bg-gradient-to-l from-[#156394]/5 to-[#F2B524]/5 text-gray-700 hover:from-[#156394]/10 hover:to-[#F2B524]/10 hover:text-[#156394] rounded-full transition-all text-sm border border-transparent hover:border-[#156394]/20"
                        >
                          {search}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-3 mr-auto lg:mr-0">
              {/* Search Button - Mobile */}
              <Button 
                variant="ghost" 
                size="icon" 
                className={`md:hidden rounded-full transition-colors ${
                  isScrolled 
                    ? 'text-gray-600 hover:text-[#156394] hover:bg-gray-100' 
                    : 'text-gray-700 hover:text-[#F2B524] hover:bg-gray-100'
                }`}
                onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
              >
                <Search className="w-5 h-5" />
              </Button>

              {/* Menu Button - Mobile */}
              <Button
                variant="ghost"
                size="icon"
                className={`lg:hidden rounded-full transition-colors ${
                  isScrolled 
                    ? 'text-gray-600' 
                    : 'md:text-white text-gray-700'
                }`}
                onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
              >
                {isMegaMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </Button>
              
              {/* User Button - اول */}
              <Button 
                variant="ghost" 
                size="icon" 
                className={`rounded-full transition-colors ${
                  isScrolled 
                    ? 'text-gray-600 hover:text-[#156394] hover:bg-gray-100' 
                    : 'md:text-white text-gray-700 hover:text-[#F2B524] md:hover:text-[#F2B524] hover:bg-gray-100 md:hover:bg-white/20'
                }`}
              >
                <User className="w-6 h-6" />
              </Button>

              {/* Invoice Button - بعد از User */}
              <button
                onClick={() => toggleCart()}
                className={`relative flex items-center gap-2 px-4 py-2.5 transition-colors rounded-full ${
                  isScrolled 
                    ? 'text-gray-700 hover:text-[#156394] bg-gray-100' 
                    : 'md:text-white text-gray-700 md:bg-white/20 bg-gray-100 hover:text-[#F2B524] md:hover:text-[#F2B524]'
                }`}
              >
                <FileText className="w-5 h-5" />
                <span className="hidden sm:inline">پیش‌فاکتور</span>
                {/* Badge */}
                <span className="absolute -top-1 -right-1 bg-[#F2B524] text-gray-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-lg">
                  {toPersianNumber(getTotalItems())}
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu - Categories */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white/95 backdrop-blur-xl border-t border-gray-200/50 max-h-[70vh] overflow-y-auto">
            <nav className="p-6 space-y-2">
              <button
                className="w-full text-right px-4 py-3 text-gray-700 hover:text-[#156394] hover:bg-gray-100 rounded-2xl transition-all flex items-center gap-2"
                onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
              >
                <div className="w-5 h-5">
                  <SolarCodeScanBold />
                </div>
                <span>دسته‌بندی محصولات</span>
                <ChevronDown className={`w-4 h-4 mr-auto transition-transform ${isMegaMenuOpen ? 'rotate-180' : ''}`} />
              </button>
            </nav>
          </div>
        )}

        {/* Mobile Search */}
        {isMobileSearchOpen && (
          <div className="lg:hidden bg-white/95 backdrop-blur-xl border-t border-gray-200/50 max-h-[70vh] overflow-y-auto">
            <div className="p-6">
              <div className="relative">
                <input
                  type="text"
                  placeholder="جستجو در محصولات و دسته‌بندی‌ها..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setIsSearchFocused(true)}
                  className="w-full pr-10 pl-10 py-3 bg-gray-100 rounded-full focus:outline-none focus:ring-2 focus:ring-[#156394]/20 focus:bg-white transition-all"
                />
                <Search className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2" />
                
                {/* Close Search Button */}
                {isSearchFocused && (
                  <button
                    onClick={() => {
                      setIsSearchFocused(false);
                      setSearchQuery('');
                      setIsMobileSearchOpen(false);
                    }}
                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Mobile Popular Searches - When focused but empty */}
              {isSearchFocused && !searchQuery.trim() && (
                <div className="mt-4">
                  <h4 className="text-xs text-gray-500 mb-3">جستجوهای محبوب</h4>
                  <div className="flex flex-wrap gap-2">
                    {popularSearches.map((search) => (
                      <button
                        key={search}
                        onClick={() => setSearchQuery(search)}
                        className="px-4 py-2 bg-gradient-to-l from-[#156394]/5 to-[#F2B524]/5 text-gray-700 hover:from-[#156394]/10 hover:to-[#F2B524]/10 hover:text-[#156394] rounded-full transition-all text-sm border border-transparent hover:border-[#156394]/20"
                      >
                        {search}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Mobile Search Results */}
              {isSearchFocused && searchQuery.trim() && (filteredProducts.length > 0 || filteredCategories.length > 0) && (
                <div className="mt-3 bg-white rounded-2xl border border-gray-100 overflow-hidden max-h-[60vh] overflow-y-auto">
                  {/* Categories Results */}
                  {filteredCategories.length > 0 && (
                    <div className="p-4 border-b border-gray-100">
                      <h4 className="text-xs text-gray-500 mb-2 px-2">دسته‌بندی‌ها</h4>
                      <div className="space-y-1">
                        {filteredCategories.map((cat) => (
                          <a
                            key={cat.name}
                            href={cat.href}
                            className="block px-4 py-2 text-gray-700 hover:text-[#156394] hover:bg-gradient-to-l hover:from-[#156394]/5 hover:to-[#F2B524]/5 rounded-2xl transition-all"
                          >
                            📂 {cat.name}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Products Results */}
                  {filteredProducts.length > 0 && (
                    <div className="p-4">
                      <h4 className="text-xs text-gray-500 mb-2 px-2">محصولات</h4>
                      <div className="space-y-4">
                        {filteredProducts.slice(0, 6).map((product) => {
                          const productKey = `product-${product.id}`;
                          const selectedSizeIndex = selectedSizes[productKey] || 0;
                          const selectedSize = product.sizes[selectedSizeIndex];
                          
                          return (
                            <div
                              key={product.id}
                              className="px-3 py-3 hover:bg-gradient-to-l hover:from-[#156394]/5 hover:to-[#F2B524]/5 rounded-2xl transition-all"
                            >
                              <div className="flex items-start gap-3 mb-3">
                                <img 
                                  src={product.image} 
                                  alt={product.name}
                                  className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                                />
                                <div className="flex-1 min-w-0">
                                  <div className="text-gray-900 hover:text-[#156394] mb-1 font-medium">{product.name}</div>
                                  <div className="text-xs text-gray-500 mb-2">{product.category}</div>
                                  
                                  {/* Selected Size Price */}
                                  <div className="text-sm font-semibold text-[#156394]">
                                    {toPersianNumber(selectedSize.price.toLocaleString())} تومان
                                  </div>
                                </div>
                              </div>
                              
                              {/* Size Selection Row */}
                              <div className="flex items-center gap-2">
                                {/* Scrollable Size Buttons */}
                                <div className="flex-1 overflow-x-auto scrollbar-hide">
                                  <div className="flex gap-1.5 pb-1">
                                    {product.sizes.map((sizeOption, sizeIndex) => (
                                      <button
                                        key={sizeIndex}
                                        onClick={() => {
                                          setSelectedSizes(prev => ({
                                            ...prev,
                                            [productKey]: sizeIndex
                                          }));
                                        }}
                                        className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all whitespace-nowrap ${
                                          selectedSizeIndex === sizeIndex
                                            ? 'bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white shadow-md'
                                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                        }`}
                                      >
                                        {sizeOption.size}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                                
                                {/* Add Button */}
                                <button
                                  onClick={(e) => {
                                    e.preventDefault();
                                    addToCart({
                                      productId: product.id,
                                      productName: product.name,
                                      productCategory: product.category,
                                      productImage: product.image,
                                      size: selectedSize.size,
                                      price: selectedSize.price,
                                      discount: product.discount,
                                    });
                                    toast.success(`${product.name} (${selectedSize.size}) به پیش‌فاکتور اضافه شد`, {
                                      duration: 2000,
                                    });
                                  }}
                                  className="flex-shrink-0 p-2 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white rounded-full hover:shadow-lg hover:scale-105 transition-all"
                                >
                                  <Plus className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {/* No Results */}
                  {filteredProducts.length === 0 && filteredCategories.length === 0 && (
                    <div className="p-6 text-center text-gray-500">
                      نتیجه‌ای یافت نشد
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </header>

      {/* Mega Menu Overlay - Full Screen with Creative Design */}
      <div
        className={`fixed inset-0 z-[60] transition-all duration-700 ease-out ${
          isMegaMenuOpen 
            ? 'opacity-100 pointer-events-auto' 
            : 'opacity-0 pointer-events-none'
        }`}
      >
        {/* Animated Background with Gradient */}
        <div 
          className={`absolute inset-0 bg-gradient-to-br from-[#156394]/95 via-[#1a7bb3]/95 to-[#F2B524]/95 backdrop-blur-xl transition-all duration-700 ${
            isMegaMenuOpen ? 'scale-100' : 'scale-95'
          }`}
          onClick={() => setIsMegaMenuOpen(false)}
        >
          {/* Floating Shapes Animation */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-20 right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-20 left-20 w-96 h-96 bg-[#F2B524]/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
            <div className="absolute top-1/2 left-1/3 w-72 h-72 bg-white/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
          </div>
        </div>

        {/* Mega Menu Content */}
        <div
          className={`absolute inset-0 overflow-y-auto transition-all duration-700 ease-out ${
            isMegaMenuOpen 
              ? 'translate-y-0 opacity-100' 
              : '-translate-y-full opacity-0'
          }`}
        >
          <div className="min-h-screen relative">
            {/* Close Button - Fixed Position */}
            <button
              onClick={() => setIsMegaMenuOpen(false)}
              className="fixed top-8 left-8 z-[70] p-3 bg-white/20 backdrop-blur-md text-white hover:bg-white/30 rounded-full transition-all hover:rotate-90 duration-300"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="max-w-7xl mx-auto px-6 py-16 pb-24">
              {/* Title Section */}
              <div className="mb-16 text-center">
                <h2 className="text-5xl md:text-6xl text-white mb-4 animate-fadeIn">
                  دسته‌بندی محصولات
                </h2>
                <div className="h-1 w-32 bg-gradient-to-r from-transparent via-[#F2B524] to-transparent mx-auto mb-4"></div>
                <p className="text-xl text-white/90 max-w-2xl mx-auto">
                  کامل‌ترین مجموعه تجهیزات صنعت ساخت استخر و لوله‌کشی
                </p>
              </div>

              {/* Categories Grid - Creative Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
                {categories.map((category, index) => {
                  const Icon = category.icon;
                  return (
                    <div
                      key={category.name}
                      className="group"
                      style={{
                        animation: isMegaMenuOpen ? `slideUp 0.6s ease-out ${index * 0.1}s both` : 'none'
                      }}
                    >
                      <div className="relative bg-white/10 backdrop-blur-lg p-8 rounded-3xl border border-white/20 hover:bg-white/20 hover:border-white/40 transition-all duration-500 hover:scale-105 hover:shadow-2xl overflow-hidden">
                        {/* Animated Gradient Background */}
                        <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500`}></div>
                        
                        {/* Icon */}
                        <div className="relative mb-6 flex items-center gap-4">
                          <div className={`p-4 bg-gradient-to-br ${category.color} rounded-2xl group-hover:scale-110 transition-transform duration-300`}>
                            <Icon className="w-8 h-8 text-white" />
                          </div>
                          <h3 className="text-2xl text-white group-hover:text-[#F2B524] transition-colors duration-300">
                            {category.name}
                          </h3>
                        </div>

                        {/* Subcategories */}
                        <ul className="relative space-y-2 mb-6">
                          {category.subcategories.map((sub) => (
                            <li key={sub}>
                              <a
                                href="#"
                                className="block px-4 py-2.5 text-white/80 hover:text-white hover:bg-white/10 rounded-xl transition-all backdrop-blur-sm"
                              >
                                <span className="text-[#F2B524] ml-2">•</span>
                                {sub}
                              </a>
                            </li>
                          ))}
                        </ul>

                        {/* View All Link */}
                        <a
                          href={category.href}
                          className="relative inline-flex items-center gap-2 px-6 py-3 bg-white/20 hover:bg-white/30 text-white rounded-full transition-all backdrop-blur-md group-hover:gap-4"
                        >
                          <span>مشاهده همه</span>
                          <span className="group-hover:translate-x-1 transition-transform">←</span>
                        </a>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom CTA Section */}
              <div 
                className="bg-white/10 backdrop-blur-lg rounded-3xl p-12 border border-white/20 text-center"
                style={{
                  animation: isMegaMenuOpen ? 'slideUp 0.6s ease-out 0.6s both' : 'none'
                }}
              >
                <h3 className="text-3xl text-white mb-4">نیاز به مشاوره تخصصی دارید؟</h3>
                <p className="text-white/90 mb-8 text-lg max-w-2xl mx-auto">
                  تیم متخصص ما آماده است تا در انتخاب بهترین تجهیزات برای پروژه شما راهنمایی کند
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <button className="px-8 py-4 bg-white text-[#156394] rounded-full hover:bg-[#F2B524] hover:text-white hover:scale-105 transition-all duration-300 shadow-lg">
                    تماس با کارشناسان
                  </button>
                  <button className="px-8 py-4 bg-white/20 backdrop-blur-md text-white border-2 border-white/40 rounded-full hover:bg-white/30 hover:scale-105 transition-all duration-300">
                    درخواست لیست قیمت
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: scale(0.95);
          }
          to {
            opacity: 1;
            transform: scale(1);
          }
        }

        .scrollbar-hide {
          scrollbar-width: thin;
          scrollbar-color: #156394 transparent;
        }

        .scrollbar-hide::-webkit-scrollbar {
          height: 4px;
        }

        .scrollbar-hide::-webkit-scrollbar-track {
          background: transparent;
          margin: 0 8px;
        }

        .scrollbar-hide::-webkit-scrollbar-thumb {
          background: linear-gradient(to left, #156394, #1a7bb3);
          border-radius: 10px;
        }

        .scrollbar-hide::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(to left, #1a7bb3, #156394);
        }
      `}</style>
    </>
  );
}