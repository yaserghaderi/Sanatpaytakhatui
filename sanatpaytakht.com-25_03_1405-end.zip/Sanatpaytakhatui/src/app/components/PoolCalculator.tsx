import { useState } from 'react';
import { Calculator, Droplets, Zap, Filter, Waves, Settings2, ShoppingCart, ChevronRight, Search, X, Trash2, Star, CheckCircle, Flame, Shield, Lightbulb, Cpu, Clock, Cable } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner';
import { ImageWithFallback } from './figma/ImageWithFallback';

// Import pump images
import pump1Img from 'figma:asset/ddd44cbc51835044f65e293902f67a9ae467eff6.png';
import pump2Img from 'figma:asset/9e70313291e12df81858277ce8d22b7155aa6f48.png';
import pump3Img from 'figma:asset/18b9d5e7076bb971f3794721f452abcd84b84a2f.png';

// Import filter images
import filter1Img from 'figma:asset/b9e851bd74387b2f7a21d709a50c90fb855ede51.png';
import filter2Img from 'figma:asset/3b2f6edfac4b30391f607d26998490115864eb66.png';
import filter3Img from 'figma:asset/4e11627d845b72dbb0ccfe328733e869ae2ba7f7.png';

// Import chlorinator image
import chlorinatorImg from 'figma:asset/2ff93dbf5f8997041ff59f4fbbfd5080168f028c.png';

// Import pipes and fittings images
import pipeImg1 from 'figma:asset/ad07a41c56511a2936e013d68b02825c29863bc7.png';
import pipeImg2 from 'figma:asset/a4a73c7c32c7c99f5a9c4242d25267677e7cd744.png';
import pipeImg3 from 'figma:asset/ac8779e204b0c4b8717a017b50d27eb58d229d32.png';

interface PoolDimensions {
  length: string;
  width: string;
  depth: string;
}

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
  specs: string;
  minVolume?: number;
  maxVolume?: number;
  sizes?: { size: string; price: number }[];
}

interface SelectedProduct extends Product {
  quantity: number;
  sectionId: string;
  selectedSize?: string;
}

interface Recommendation {
  sectionId: string;
  message: string;
  quantity: number;
  suggestedProducts: string[]; // product ids
}

export function PoolCalculator() {
  const [step, setStep] = useState<'input' | 'results'>('input');
  const [dimensions, setDimensions] = useState<PoolDimensions>({
    length: '',
    width: '',
    depth: ''
  });
  const [volume, setVolume] = useState(0);
  const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([]);
  const [searchTerms, setSearchTerms] = useState<Record<string, string>>({
    pump: '',
    filter: '',
    chlorinator: '',
    pipes: '',
    strainer: '',
    electrical: '',
    timer: '',
    heating: '',
    safety: '',
    lighting: '',
  });
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const { addToCart, getTotalPrice: getCartTotal } = useCart();

  // محصولات واقعی با سایزبندی
  const allProducts: Record<string, Product[]> = {
    pump: [
      { 
        id: 'pump1', 
        name: 'پمپ آکوا', 
        category: 'پمپ', 
        price: 9800000, 
        image: pump1Img, 
        description: 'دبی 8 m³/h', 
        specs: '0.5 اسب', 
        minVolume: 20, 
        maxVolume: 40,
        sizes: [
          { size: '0.5 اسب', price: 9800000 },
        ]
      },
      { 
        id: 'pump2', 
        name: 'پمپ هایواتر', 
        category: 'پمپ', 
        price: 14200000, 
        image: pump2Img, 
        description: 'دبی 12 m³/h', 
        specs: '0.75 اسب', 
        minVolume: 40, 
        maxVolume: 70,
        sizes: [
          { size: '0.75 اسب', price: 14200000 },
        ]
      },
      { 
        id: 'pump3', 
        name: 'پمپ ایمکس', 
        category: 'پمپ', 
        price: 18500000, 
        image: pump3Img, 
        description: 'دبی 16 m³/h', 
        specs: '1 اسب', 
        minVolume: 70, 
        maxVolume: 100,
        sizes: [
          { size: '1 اسب', price: 18500000 },
        ]
      },
      { 
        id: 'pump4', 
        name: 'پمپ استار', 
        category: 'پمپ', 
        price: 24800000, 
        image: pump2Img, 
        description: 'دبی 22 m³/h', 
        specs: '1.5 اسب', 
        minVolume: 100, 
        maxVolume: 150,
        sizes: [
          { size: '1.5 اسب', price: 24800000 },
        ]
      },
      { 
        id: 'pump5', 
        name: 'پمپ پنتیر', 
        category: 'پمپ', 
        price: 32500000, 
        image: pump3Img, 
        description: 'دبی 28 m³/h', 
        specs: '2 اسب', 
        minVolume: 150, 
        maxVolume: 999,
        sizes: [
          { size: '2 اسب', price: 32500000 },
          { size: '3 اسب', price: 42500000 },
        ]
      },
    ],
    filter: [
      { 
        id: 'filter1', 
        name: 'فیلتر ایمکس', 
        category: 'فیلتر', 
        price: 6500000, 
        image: filter1Img, 
        description: '25kg شن', 
        specs: '400mm (16")', 
        minVolume: 0, 
        maxVolume: 40,
        sizes: [
          { size: '400mm (16")', price: 6500000 },
        ]
      },
      { 
        id: 'filter2', 
        name: 'فیلتر هایواتر', 
        category: 'فیلتر', 
        price: 9200000, 
        image: filter2Img, 
        description: '50kg شن', 
        specs: '500mm (20")', 
        minVolume: 40, 
        maxVolume: 75,
        sizes: [
          { size: '500mm (20")', price: 9200000 },
        ]
      },
      { 
        id: 'filter3', 
        name: 'فیلتر استار', 
        category: 'فیلتر', 
        price: 13500000, 
        image: filter3Img, 
        description: '100kg شن', 
        specs: '600mm (24")', 
        minVolume: 75, 
        maxVolume: 120,
        sizes: [
          { size: '600mm (24")', price: 13500000 },
        ]
      },
      { 
        id: 'filter4', 
        name: 'فیلتر پنتیر', 
        category: 'فیلتر', 
        price: 19800000, 
        image: 'https://images.unsplash.com/photo-1550242706-904901501006?w=300', 
        description: '175kg شن', 
        specs: '750mm (30")', 
        minVolume: 120, 
        maxVolume: 999,
        sizes: [
          { size: '750mm (30")', price: 19800000 },
          { size: '900mm (36")', price: 28500000 },
        ]
      },
    ],
    chlorinator: [
      { 
        id: 'chlor1', 
        name: 'کلرزن نمکی آکوا', 
        category: 'کلرزن', 
        price: 14500000, 
        image: chlorinatorImg, 
        description: 'تولید کلر از نمک', 
        specs: '16 گرم/ساعت', 
        minVolume: 0, 
        maxVolume: 50,
        sizes: [
          { size: '16 گرم/ساعت', price: 14500000 },
        ]
      },
      { 
        id: 'chlor2', 
        name: 'کلرزن نمکی هایواتر', 
        category: 'کلرزن', 
        price: 21500000, 
        image: chlorinatorImg, 
        description: 'سیستم خودکار', 
        specs: '25 گرم/ساعت', 
        minVolume: 50, 
        maxVolume: 100,
        sizes: [
          { size: '25 گرم/ساعت', price: 21500000 },
        ]
      },
      { 
        id: 'chlor3', 
        name: 'کلرزن نمکی استار', 
        category: 'کلرزن', 
        price: 32500000, 
        image: chlorinatorImg, 
        description: 'دیجیتال با نمایشگر', 
        specs: '40 گرم/ساعت', 
        minVolume: 100, 
        maxVolume: 999,
        sizes: [
          { size: '40 گرم/ساعت', price: 32500000 },
          { size: '60 گرم/ساعت', price: 45500000 },
        ]
      },
    ],
    pipes: [
      { 
        id: 'pipe1', 
        name: 'لوله PVC پلیمرتوس', 
        category: 'لوله', 
        price: 450000, 
        image: pipeImg1, 
        description: 'فشار PN10 - شاخه 6 متری', 
        specs: 'قیمت هر شاخه',
        sizes: [
          { size: '50mm (2")', price: 450000 },
          { size: '63mm (2.5")', price: 680000 },
          { size: '75mm (3")', price: 920000 },
          { size: '90mm (3.5")', price: 1250000 },
          { size: '110mm (4")', price: 1750000 },
        ]
      },
      { 
        id: 'pipe2', 
        name: 'لوله PVC پیمتاش', 
        category: 'لوله', 
        price: 520000, 
        image: pipeImg2, 
        description: 'فشار PN16 - شاخه 6 متری', 
        specs: 'کیفیت برتر',
        sizes: [
          { size: '50mm (2")', price: 520000 },
          { size: '63mm (2.5")', price: 780000 },
          { size: '75mm (3")', price: 1050000 },
          { size: '90mm (3.5")', price: 1420000 },
          { size: '110mm (4")', price: 1980000 },
        ]
      },
      { 
        id: 'pipe3', 
        name: 'سه راه PVC', 
        category: 'اتصالات', 
        price: 85000, 
        image: pipeImg3, 
        description: 'اتصال T شکل', 
        specs: 'قیمت هر عدد',
        sizes: [
          { size: '50mm (2")', price: 85000 },
          { size: '63mm (2.5")', price: 125000 },
          { size: '75mm (3")', price: 185000 },
          { size: '90mm (3.5")', price: 265000 },
        ]
      },
      { 
        id: 'pipe4', 
        name: 'زانو 90 درجه PVC', 
        category: 'اتصالات', 
        price: 65000, 
        image: pipeImg3, 
        description: 'اتصال زاویه‌دار', 
        specs: 'قیمت هر عدد',
        sizes: [
          { size: '50mm (2")', price: 65000 },
          { size: '63mm (2.5")', price: 95000 },
          { size: '75mm (3")', price: 145000 },
          { size: '90mm (3.5")', price: 205000 },
        ]
      },
      { 
        id: 'pipe5', 
        name: 'کوپلینگ PVC', 
        category: 'اتصالات', 
        price: 45000, 
        image: pipeImg3, 
        description: 'اتصال مستقیم', 
        specs: 'قیمت هر عدد',
        sizes: [
          { size: '50mm (2")', price: 45000 },
          { size: '63mm (2.5")', price: 68000 },
          { size: '75mm (3")', price: 98000 },
          { size: '90mm (3.5")', price: 145000 },
        ]
      },
    ],
    strainer: [
      { 
        id: 'strainer1', 
        name: 'موگیر استخر استاندارد', 
        category: 'موگیر', 
        price: 1850000, 
        image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=300', 
        description: 'سبد پلاستیکی', 
        specs: 'برای استخرهای کوچک',
        minVolume: 0,
        maxVolume: 60,
      },
      { 
        id: 'strainer2', 
        name: 'موگیر حرفه‌ای', 
        category: 'موگیر', 
        price: 3200000, 
        image: 'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?w=300', 
        description: 'سبد استیل', 
        specs: 'برای استخرهای متوسط و بزرگ',
        minVolume: 60,
        maxVolume: 999,
      },
    ],
    electrical: [
      { 
        id: 'elec1', 
        name: 'تابلو برق استخر پایه', 
        category: 'تابلو برق', 
        price: 4500000, 
        image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=300', 
        description: 'کنتاکتور و محافظ', 
        specs: 'تا 2 اسب',
        minVolume: 0,
        maxVolume: 100,
      },
      { 
        id: 'elec2', 
        name: 'تابلو برق استخر پیشرفته', 
        category: 'تابلو برق', 
        price: 7800000, 
        image: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=300', 
        description: 'با قابلیت کنترل چندگانه', 
        specs: 'تا 3 اسب',
        minVolume: 100,
        maxVolume: 999,
      },
    ],
    timer: [
      { 
        id: 'timer1', 
        name: 'تایمر مکانیکی', 
        category: 'تایمر', 
        price: 850000, 
        image: 'https://images.unsplash.com/photo-1495364141860-b0d03eccd065?w=300', 
        description: 'برنامه‌ریزی 24 ساعته', 
        specs: 'تایمر ساده',
      },
      { 
        id: 'timer2', 
        name: 'تایمر دیجیتال', 
        category: 'تایمر', 
        price: 2100000, 
        image: 'https://images.unsplash.com/photo-1495364141860-b0d03eccd065?w=300', 
        description: 'برنامه‌ریزی هفتگی', 
        specs: 'نمایشگر LCD',
      },
      { 
        id: 'timer3', 
        name: 'کنترل هوشمند WiFi', 
        category: 'کنترل هوشمند', 
        price: 5500000, 
        image: 'https://images.unsplash.com/photo-1558346490-a72e53ae2d4f?w=300', 
        description: 'کنترل از راه دور', 
        specs: 'اپلیکیشن موبایل',
      },
    ],
    heating: [
      { 
        id: 'heat1', 
        name: 'هیتر برقی 3kW', 
        category: 'گرمایش', 
        price: 8500000, 
        image: 'https://images.unsplash.com/photo-1745570295714-cb18cd15ff64?w=300', 
        description: 'برای استخرهای کوچک', 
        specs: 'توان 3 کیلووات',
        minVolume: 0,
        maxVolume: 40,
      },
      { 
        id: 'heat2', 
        name: 'هیتر برقی 6kW', 
        category: 'گرمایش', 
        price: 14500000, 
        image: 'https://images.unsplash.com/photo-1594233078955-e1f73a02ebb2?w=300', 
        description: 'برای استخرهای متوسط', 
        specs: 'توان 6 کیلووات',
        minVolume: 40,
        maxVolume: 80,
      },
      { 
        id: 'heat3', 
        name: 'پمپ حرارتی', 
        category: 'گرمایش', 
        price: 32500000, 
        image: 'https://images.unsplash.com/photo-1760886810583-dbb87686d08c?w=300', 
        description: 'کم‌مصرف و کارآمد', 
        specs: 'COP بالا',
        minVolume: 50,
        maxVolume: 999,
      },
    ],
    safety: [
      { 
        id: 'safe1', 
        name: 'نرده استخر آلومینیومی', 
        category: 'ایمنی', 
        price: 3500000, 
        image: 'https://images.unsplash.com/photo-1587502537147-2ba64a62e3d3?w=300', 
        description: 'نصب آسان', 
        specs: 'ضد زنگ',
        sizes: [
          { size: '1 متری', price: 3500000 },
          { size: '1.5 متری', price: 4800000 },
        ]
      },
      { 
        id: 'safe2', 
        name: 'نرده استخر استیل', 
        category: 'ایمنی', 
        price: 5200000, 
        image: 'https://images.unsplash.com/photo-1587502537147-2ba64a62e3d3?w=300', 
        description: 'مقاوم و زیبا', 
        specs: 'استیل 304',
        sizes: [
          { size: '1 متری', price: 5200000 },
          { size: '1.5 متری', price: 7200000 },
        ]
      },
      { 
        id: 'safe3', 
        name: 'نردبان استخر', 
        category: 'ایمنی', 
        price: 2800000, 
        image: 'https://images.unsplash.com/photo-1587502537147-2ba64a62e3d3?w=300', 
        description: 'ضد لغزش', 
        specs: '3 پله',
        sizes: [
          { size: '3 پله', price: 2800000 },
          { size: '4 پله', price: 3500000 },
          { size: '5 پله', price: 4200000 },
        ]
      },
    ],
    lighting: [
      { 
        id: 'light1', 
        name: 'چراغ LED استخر', 
        category: 'روشنایی', 
        price: 1850000, 
        image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=300', 
        description: 'تک رنگ سفید', 
        specs: '12V - 18W',
      },
      { 
        id: 'light2', 
        name: 'چراغ RGB استخر', 
        category: 'روشنایی', 
        price: 3200000, 
        image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=300', 
        description: '16 میلیون رنگ', 
        specs: '12V - 24W',
      },
      { 
        id: 'light3', 
        name: 'نورپردازی هوشمند', 
        category: 'روشنایی', 
        price: 5800000, 
        image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=300', 
        description: 'کنترل از موبایل', 
        specs: 'RGB + کنترلر',
      },
    ],
  };

  const sections = [
    { id: 'pump', title: 'پمپ', icon: Zap, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'filter', title: 'فیلتر', icon: Filter, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'chlorinator', title: 'کلرزن', icon: Droplets, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'pipes', title: 'لوله و اتصالات', icon: Waves, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'strainer', title: 'موگیر', icon: Filter, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'electrical', title: 'تابلو برق', icon: Cable, color: 'from-[#156394] to-[#1a7bb3]', required: true },
    { id: 'timer', title: 'تایمر و کنترل', icon: Clock, color: 'from-[#156394] to-[#1a7bb3]', required: false },
    { id: 'heating', title: 'تجهیزات گرمایشی', icon: Flame, color: 'from-[#156394] to-[#1a7bb3]', required: false },
    { id: 'safety', title: 'ایمنی و دسترسی', icon: Shield, color: 'from-[#156394] to-[#1a7bb3]', required: false },
    { id: 'lighting', title: 'روشنایی', icon: Lightbulb, color: 'from-[#156394] to-[#1a7bb3]', required: false },
  ];

  const calculateRecommendations = (vol: number) => {
    const recs: Recommendation[] = [];

    // پیشنهاد پمپ
    let pumpRec = '';
    let pumpIds: string[] = [];
    if (vol <= 40) {
      pumpRec = 'برای استخر شما یک پمپ 0.5 اسب کافی است.';
      pumpIds = ['pump1'];
    } else if (vol <= 70) {
      pumpRec = 'برای استخر شما یک پمپ 0.75 اسب توصیه می‌شود.';
      pumpIds = ['pump2'];
    } else if (vol <= 100) {
      pumpRec = 'برای استخر شما یک پمپ 1 اسب مناسب است.';
      pumpIds = ['pump3'];
    } else if (vol <= 150) {
      pumpRec = 'برای استخر شما یک پمپ 1.5 اسب توصیه می‌شود.';
      pumpIds = ['pump4'];
    } else {
      pumpRec = 'برای استخر بزرگ شما یک پمپ 2 اسب یا بالاتر لازم است.';
      pumpIds = ['pump5'];
    }
    recs.push({ sectionId: 'pump', message: pumpRec, quantity: 1, suggestedProducts: pumpIds });

    // پیشنهاد فیلتر
    let filterRec = '';
    let filterIds: string[] = [];
    if (vol <= 40) {
      filterRec = 'یک فیلتر 400mm (16 اینچ) با 25 کیلو شن برای استخر شما کافی است.';
      filterIds = ['filter1'];
    } else if (vol <= 75) {
      filterRec = 'یک فیلتر 500mm (20 اینچ) با 50 کیلو شن توصیه می‌شود.';
      filterIds = ['filter2'];
    } else if (vol <= 120) {
      filterRec = 'یک فیلتر 600mm (24 اینچ) با 100 کیلو شن مناسب است.';
      filterIds = ['filter3'];
    } else {
      filterRec = 'یک فیلتر 750mm (30 اینچ) یا بزرگتر با 175 کیلو شن لازم است.';
      filterIds = ['filter4'];
    }
    recs.push({ sectionId: 'filter', message: filterRec, quantity: 1, suggestedProducts: filterIds });

    // پیشنهاد کلرزن
    let chlorRec = '';
    let chlorIds: string[] = [];
    if (vol <= 50) {
      chlorRec = 'یک کلرزن نمکی 16 گرم در ساعت برای استخر شما کافی است.';
      chlorIds = ['chlor1'];
    } else if (vol <= 100) {
      chlorRec = 'یک کلرزن نمکی 25 گرم در ساعت توصیه می‌شود.';
      chlorIds = ['chlor2'];
    } else {
      chlorRec = 'یک کلرزن نمکی 40 گرم در ساعت یا بالاتر لازم است.';
      chlorIds = ['chlor3'];
    }
    recs.push({ sectionId: 'chlorinator', message: chlorRec, quantity: 1, suggestedProducts: chlorIds });

    // پیشنهاد لوله و اتصالات
    const pipeLength = Math.ceil(vol / 5); // تقریباً 1 شاخه به ازای هر 5 متر مکعب
    const pipeSize = vol <= 60 ? '50mm (2")' : vol <= 100 ? '63mm (2.5")' : '75mm (3")';
    const fittingsCount = Math.ceil(pipeLength * 1.5); // تعداد اتصالات
    
    let pipeRec = `حدود ${pipeLength} شاخه لوله ${pipeSize} و ${fittingsCount} عدد اتصالات (زانو، سه راه، کوپلینگ) نیاز دارید.`;
    recs.push({ sectionId: 'pipes', message: pipeRec, quantity: pipeLength, suggestedProducts: ['pipe1', 'pipe2', 'pipe3', 'pipe4', 'pipe5'] });

    // پیشنهاد موگیر
    if (vol <= 60) {
      recs.push({ sectionId: 'strainer', message: 'یک موگیر استاندارد برای استخر شما کافی است.', quantity: 1, suggestedProducts: ['strainer1'] });
    } else {
      recs.push({ sectionId: 'strainer', message: 'موگیر حرفه‌ای با سبد استیل توصیه می‌شود.', quantity: 1, suggestedProducts: ['strainer2'] });
    }

    // پیشنهاد تابلو برق
    if (vol <= 100) {
      recs.push({ sectionId: 'electrical', message: 'یک تابلو برق پایه برای کنترل تجهیزات لازم است.', quantity: 1, suggestedProducts: ['elec1'] });
    } else {
      recs.push({ sectionId: 'electrical', message: 'تابلو برق پیشرفته با قابلیت کنترل چندگانه توصیه می‌شود.', quantity: 1, suggestedProducts: ['elec2'] });
    }

    // پیشنهاد تایمر (اختیاری)
    recs.push({ sectionId: 'timer', message: 'برای صرفه‌جویی در مصرف برق، استفاده از تایمر یا کنترل هوشمند پیشنهاد می‌شود.', quantity: 1, suggestedProducts: ['timer2', 'timer3'] });

    // پیشنهاد گرمایش (اختیاری)
    if (vol <= 40) {
      recs.push({ sectionId: 'heating', message: 'برای استفاده در فصول سرد، هیتر 3kW مناسب است.', quantity: 1, suggestedProducts: ['heat1'] });
    } else if (vol <= 80) {
      recs.push({ sectionId: 'heating', message: 'برای استفاده در فصول سرد، هیتر 6kW توصیه می‌شود.', quantity: 1, suggestedProducts: ['heat2'] });
    } else {
      recs.push({ sectionId: 'heating', message: 'پمپ حرارتی برای استخرهای بزرگ کم‌مصرف‌ترین گزینه است.', quantity: 1, suggestedProducts: ['heat3'] });
    }

    // پیشنهاد ایمنی (اختیاری)
    recs.push({ sectionId: 'safety', message: 'برای ایمنی، نصب نرده و نردبان ضروری است.', quantity: 1, suggestedProducts: ['safe1', 'safe2', 'safe3'] });

    // پیشنهاد روشنایی (اختیاری)
    const lightCount = Math.max(2, Math.ceil(vol / 50)); // حداقل 2 چراغ
    recs.push({ sectionId: 'lighting', message: `برای روشنایی مناسب، حداقل ${lightCount} عدد چراغ LED نیاز دارید.`, quantity: lightCount, suggestedProducts: ['light1', 'light2'] });

    return recs;
  };

  const calculatePool = () => {
    const l = parseFloat(dimensions.length);
    const w = parseFloat(dimensions.width);
    const d = parseFloat(dimensions.depth);

    if (isNaN(l) || isNaN(w) || isNaN(d) || l <= 0 || w <= 0 || d <= 0) {
      toast.error('لطفاً ابعاد استخر را به درستی وارد کنید');
      return;
    }

    const vol = l * w * d;
    setVolume(vol);
    
    // محاسبه پیشنهادات
    const recs = calculateRecommendations(vol);
    setRecommendations(recs);
    
    setStep('results');
  };

  const isRecommended = (sectionId: string, productId: string) => {
    const rec = recommendations.find(r => r.sectionId === sectionId);
    return rec?.suggestedProducts.includes(productId) || false;
  };

  const getRecommendationForSection = (sectionId: string) => {
    return recommendations.find(r => r.sectionId === sectionId);
  };

  const handleProductSelect = (sectionId: string, product: Product, size?: string) => {
    // بررسی محصول تکراری با همان سایز
    const existingIndex = selectedProducts.findIndex(
      p => p.id === product.id && p.sectionId === sectionId && p.selectedSize === size
    );

    if (existingIndex >= 0) {
      // اگر محصول با همان سایز وجود داره، تعداد رو اضافه کن
      const updated = [...selectedProducts];
      updated[existingIndex].quantity += 1;
      setSelectedProducts(updated);
      toast.success('تعداد محصول افزایش یافت');
    } else {
      // محصول جدید اضافه کن
      const selectedPrice = size && product.sizes 
        ? product.sizes.find(s => s.size === size)?.price || product.price 
        : product.price;
      
      setSelectedProducts([
        ...selectedProducts, 
        { 
          ...product, 
          price: selectedPrice,
          quantity: 1, 
          sectionId,
          selectedSize: size 
        }
      ]);
      toast.success('محصول اضافه شد');
    }
  };

  const handleRemoveProduct = (index: number) => {
    const updated = selectedProducts.filter((_, i) => i !== index);
    setSelectedProducts(updated);
    toast.success('محصول حذف شد');
  };

  const handleQuantityChange = (index: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    const updated = [...selectedProducts];
    updated[index].quantity = newQuantity;
    setSelectedProducts(updated);
  };

  const addAllToCart = () => {
    if (selectedProducts.length === 0) {
      toast.error('لطفاً حداقل یک محصول را انتخاب کنید');
      return;
    }

    let addedCount = 0;
    selectedProducts.forEach(product => {
      // اضافه کردن به تعداد quantity
      for (let i = 0; i < product.quantity; i++) {
        addToCart({
          productId: Date.now() + Math.random(), // ID کاملاً یکتا برای هر آیتم
          productName: product.name,
          productCategory: product.category,
          productImage: product.image,
          size: product.selectedSize || 'استاندارد',
          price: product.price,
        });
        addedCount++;
      }
    });
    
    // خالی کردن ماشین حساب بعد از افزودن به پیش‌فاکتور
    setSelectedProducts([]);
    
    toast.success(`${addedCount} قلم محصول به پیش‌فاکتور اضافه شد`);
  };

  const getTotalPrice = () => {
    return selectedProducts.reduce((total, product) => {
      return total + (product.price * product.quantity);
    }, 0);
  };

  // محاسبه تخفیف بر اساس مجموع قیمت (شامل سبد خرید)
  // سقف تخفیف: حداکثر 100 میلیون تومان
  const MAX_DISCOUNT_AMOUNT = 125000000; // 125 میلیون تومان

  const getDiscountInfo = () => {
    const calculatorTotal = getTotalPrice();
    const cartTotal = getCartTotal();
    const total = calculatorTotal + cartTotal;
    
    const discountTiers = [
      { minPrice: 0, maxPrice: 20000000, discount: 0, label: 'تا ۲۰ میلیون', color: '#9ca3af' },
      { minPrice: 20000000, maxPrice: 50000000, discount: 5, label: '۲۰ میلیون', color: '#10b981' },
      { minPrice: 50000000, maxPrice: 100000000, discount: 10, label: '۵۰ میلیون', color: '#10b981' },
      { minPrice: 100000000, maxPrice: 200000000, discount: 15, label: '۱۰۰ میلیون', color: '#10b981' },
      { minPrice: 200000000, maxPrice: 500000000, discount: 20, label: '۲۰۰ میلیون', color: '#10b981' },
      { minPrice: 500000000, maxPrice: Infinity, discount: 25, label: '۵۰۰ میلیون', color: '#f59e0b' },
    ];

    const currentTier = discountTiers.find(tier => total >= tier.minPrice && total < tier.maxPrice);
    const nextTier = discountTiers.find(tier => tier.minPrice > total);

    // محاسبه مبلغ تخفیف با سقف 125 میلیون
    const calculatedDiscount = (total * (currentTier?.discount || 0)) / 100;
    const actualDiscountAmount = Math.min(calculatedDiscount, MAX_DISCOUNT_AMOUNT);

    return {
      currentDiscount: currentTier?.discount || 0,
      currentTier,
      nextTier,
      allTiers: discountTiers,
      total,
      calculatorTotal,
      cartTotal,
      discountAmount: actualDiscountAmount,
      isCapped: calculatedDiscount > MAX_DISCOUNT_AMOUNT
    };
  };

  const getTotalPriceWithDiscount = () => {
    const discountInfo = getDiscountInfo();
    // مجموع کل (ماشین حساب + سبد خرید) منهای تخفیف
    return discountInfo.total - discountInfo.discountAmount;
  };

  const filterProducts = (sectionId: string) => {
    const searchTerm = searchTerms[sectionId]?.toLowerCase() || '';
    const products = allProducts[sectionId].filter(product =>
      product.name.toLowerCase().includes(searchTerm) ||
      product.description.toLowerCase().includes(searchTerm) ||
      product.specs.toLowerCase().includes(searchTerm)
    );
    
    // مرتب کردن: محصولات پیشنهادی اول، بقیه بعد
    return products.sort((a, b) => {
      const aRecommended = isRecommended(sectionId, a.id);
      const bRecommended = isRecommended(sectionId, b.id);
      
      if (aRecommended && !bRecommended) return -1;
      if (!aRecommended && bRecommended) return 1;
      return 0;
    });
  };

  return (
    <section className="py-12 bg-gradient-to-br from-gray-50 via-blue-50/30 to-gray-50">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white px-4 py-2 rounded-full mb-4 text-sm">
            <Calculator className="w-4 h-4" />
            <span>ماشین حساب استخر</span>
          </div>
          <h2 className="text-3xl md:text-4xl mb-3 bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
            محاسبه تجهیزات استخر
          </h2>
          <p className="text-gray-600 text-sm max-w-2xl mx-auto">
            ابعاد استخر را وارد کنید و تجهیزات مورد نیاز را دریافت کنید
          </p>
        </motion.div>

        <AnimatePresence mode="wait">
          {step === 'input' ? (
            <motion.div
              key="input"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-xl mx-auto"
            >
              <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-5 flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-lg flex items-center justify-center">
                    <Droplets className="w-4 h-4 text-white" />
                  </div>
                  ابعاد استخر
                </h3>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">طول استخر (متر)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={dimensions.length}
                      onChange={(e) => setDimensions({ ...dimensions, length: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#156394] focus:border-transparent transition-all"
                      placeholder="مثال: 10"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">عرض استخر (متر)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={dimensions.width}
                      onChange={(e) => setDimensions({ ...dimensions, width: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#156394] focus:border-transparent transition-all"
                      placeholder="مثال: 5"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-gray-700 mb-1.5">عمق استخر (متر)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={dimensions.depth}
                      onChange={(e) => setDimensions({ ...dimensions, depth: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#156394] focus:border-transparent transition-all"
                      placeholder="مثال: 1.5"
                    />
                  </div>
                </div>

                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={calculatePool}
                  className="w-full mt-5 bg-gradient-to-r from-[#156394] to-[#1a7bb3] text-white py-2.5 rounded-lg text-sm font-medium flex items-center justify-center gap-2 hover:shadow-lg transition-shadow"
                >
                  <Calculator className="w-4 h-4" />
                  محاسبه و مشاهده پیشنهاات
                  <ChevronRight className="w-4 h-4" />
                </motion.button>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              {/* Pool Info */}
              <div className="bg-white rounded-2xl shadow-md border border-gray-200 p-6 mb-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
                    <div className="w-7 h-7 bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-lg flex items-center justify-center">
                      <Droplets className="w-3.5 h-3.5 text-white" />
                    </div>
                    مشخصات استخر
                  </h3>
                  <button
                    onClick={() => setStep('input')}
                    className="text-[#156394] text-xs font-medium hover:text-[#1a7bb3] transition-colors flex items-center gap-1"
                  >
                    ویرایش ابعاد
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                    <p className="text-gray-500 text-xs mb-1.5">طول</p>
                    <p className="text-2xl font-bold text-gray-900">{dimensions.length}</p>
                    <p className="text-gray-400 text-xs mt-0.5">متر</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                    <p className="text-gray-500 text-xs mb-1.5">عرض</p>
                    <p className="text-2xl font-bold text-gray-900">{dimensions.width}</p>
                    <p className="text-gray-400 text-xs mt-0.5">متر</p>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4 text-center border border-gray-100">
                    <p className="text-gray-500 text-xs mb-1.5">عمق</p>
                    <p className="text-2xl font-bold text-gray-900">{dimensions.depth}</p>
                    <p className="text-gray-400 text-xs mt-0.5">متر</p>
                  </div>
                  <div className="bg-gradient-to-br from-[#156394] to-[#1a7bb3] rounded-xl p-4 text-center border border-[#156394] shadow-sm">
                    <p className="text-blue-100 text-xs mb-1.5">حجم کل</p>
                    <p className="text-2xl font-bold text-white">{volume.toFixed(1)}</p>
                    <p className="text-blue-100 text-xs mt-0.5">متر مکعب</p>
                  </div>
                </div>
              </div>

              {/* Discount Progress Bar */}
              {(() => {
                const discountInfo = getDiscountInfo();
                
                // محاسبه درصد پیشرفت کل (از 0 تا 500 میلیون به عنوان 100%)
                const maxPrice = 500000000; // حداکثر قیمت برای نوار (milestone ها تا 400م + فضای بافر)
                const progressPercentage = Math.min((discountInfo.total / maxPrice) * 100, 100);

                return (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl shadow-md border-2 border-emerald-200 p-6 mb-6 relative overflow-hidden"
                  >
                    {/* Background Pattern */}
                    <div className="absolute inset-0 opacity-5">
                      <div className="absolute inset-0" style={{ 
                        backgroundImage: 'radial-gradient(circle, #10b981 1px, transparent 1px)',
                        backgroundSize: '20px 20px'
                      }}></div>
                    </div>

                    <div className="relative z-10">
                      {/* Header */}
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                            <span className="text-white text-lg">🎁</span>
                          </div>
                          <div>
                            <h3 className="font-bold text-gray-900">تخفیف ویژه بر اساس مبلغ خرید</h3>
                            <p className="text-xs text-gray-600">سقف تخفیف: ۱۲۵ میلیون تومان</p>
                          </div>
                        </div>
                        {discountInfo.currentDiscount > 0 && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className={`text-white px-4 py-2 rounded-full font-bold shadow-lg ${
                              discountInfo.isCapped 
                                ? 'bg-gradient-to-r from-amber-500 to-orange-600' 
                                : 'bg-gradient-to-r from-emerald-500 to-green-600'
                            }`}
                          >
                            {discountInfo.currentDiscount}٪ {discountInfo.isCapped ? '(سقف)' : 'تخفیف'}
                          </motion.div>
                        )}
                      </div>

                      {/* Progress Bar Container */}
                      <div className="relative mb-6">
                        {/* Background Track */}
                        <div className="h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner relative">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${progressPercentage}%` }}
                            transition={{ duration: 1, ease: "easeOut" }}
                            className="h-full bg-gradient-to-l from-emerald-400 via-emerald-500 to-green-500 rounded-full absolute right-0"
                          >
                            {/* Shine Effect */}
                            <div className="absolute inset-0 bg-gradient-to-l from-transparent via-white/30 to-transparent animate-pulse"></div>
                          </motion.div>
                        </div>

                        {/* Milestone Points */}
                        <div className="relative mt-4">
                          <div className="relative">
                            {/* All milestones positioned absolutely based on their price - RTL */}
                            {[
                              { price: 0, discount: 0, label: 'شروع' },
                              { price: 20000000, discount: 5, label: '۲۰م' },
                              { price: 50000000, discount: 10, label: '۵۰م' },
                              { price: 100000000, discount: 15, label: '۱۰۰م' },
                              { price: 200000000, discount: 20, label: '۲۰۰م' },
                              { price: 500000000, discount: 25, label: '۵۰۰م' },
                            ].map((milestone, index) => {
                              const isActive = discountInfo.total >= milestone.price;
                              const milestonesPrices = [0, 20000000, 50000000, 100000000, 200000000, 500000000, Infinity];
                              const isCurrent = discountInfo.total >= milestone.price && 
                                               (index === 5 || discountInfo.total < milestonesPrices[index + 1]);
                              // موقعیت بر اساس نسبت واقعی قیمت در نمودار 500 میلیون تومانی
                              const positionPercent = (milestone.price / maxPrice) * 100;
                              
                              return (
                                <div 
                                  key={index} 
                                  className="absolute flex flex-col items-center" 
                                  style={{ 
                                    right: `${positionPercent}%`,
                                    transform: 'translateX(50%)',
                                  }}
                                >
                                  {/* Milestone Dot */}
                                  <motion.div
                                    initial={{ scale: 0 }}
                                    animate={{ scale: 1 }}
                                    transition={{ delay: index * 0.1 }}
                                    className={`w-5 h-5 rounded-full border-4 shadow-lg transition-all ${
                                      isActive 
                                        ? 'bg-emerald-500 border-white' 
                                        : 'bg-gray-300 border-white'
                                    } ${isCurrent ? 'ring-4 ring-emerald-200' : ''}`}
                                  >
                                    {isActive && milestone.price > 0 && (
                                      <span className="flex items-center justify-center text-white text-[8px]">✓</span>
                                    )}
                                  </motion.div>
                                  
                                  {/* Label */}
                                  <div className="mt-2 text-center whitespace-nowrap">
                                    <p className={`text-xs font-bold ${isActive ? 'text-emerald-600' : 'text-gray-500'}`}>
                                      {milestone.discount}٪
                                    </p>
                                    <p className="text-[10px] text-gray-500 mt-0.5">
                                      {milestone.label}
                                    </p>
                                  </div>
                                </div>
                              );
                            })}
                            {/* Spacer for layout */}
                            <div className="h-20"></div>
                          </div>
                        </div>
                      </div>

                      {/* Current Status */}
                      <div className="bg-white rounded-xl p-4 shadow-sm">
                        {/* نمایش تفکیک مبالغ در صورت وجود سبد خرید */}
                        {discountInfo.cartTotal > 0 && (
                          <div className="mb-4 pb-4 border-b border-gray-200">
                            <div className="grid grid-cols-2 gap-3 text-sm">
                              <div className="text-center bg-blue-50 rounded-lg p-2">
                                <p className="text-xs text-gray-500 mb-1">🛒 سبد خرید</p>
                                <p className="font-bold text-blue-600">
                                  {discountInfo.cartTotal.toLocaleString('fa-IR')} تومان
                                </p>
                              </div>
                              <div className="text-center bg-purple-50 rounded-lg p-2">
                                <p className="text-xs text-gray-500 mb-1">🧮 ماشین حساب</p>
                                <p className="font-bold text-purple-600">
                                  {discountInfo.calculatorTotal.toLocaleString('fa-IR')} تومان
                                </p>
                              </div>
                            </div>
                          </div>
                        )}

                        {discountInfo.currentDiscount === 0 ? (
                          <div className="text-center">
                            <p className="text-gray-700 mb-2">
                              🎁 تا <span className="font-bold text-emerald-600">۱۰۰ میلیون تومان</span> تخفیف دریافت کنید!
                            </p>
                            {discountInfo.nextTier && (
                              <p className="text-emerald-600 font-bold">
                                تا تخفیف {discountInfo.nextTier.discount}٪ فقط{' '}
                                {(discountInfo.nextTier.minPrice - discountInfo.total).toLocaleString('fa-IR')} تومان{' '}
                                مانده!
                              </p>
                            )}
                          </div>
                        ) : (
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="text-center">
                              <p className="text-xs text-gray-500 mb-1">مبلغ کل</p>
                              <p className="font-bold text-gray-900">
                                {discountInfo.total.toLocaleString('fa-IR')} تومان
                              </p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500 mb-1">میزان تخفیف {discountInfo.isCapped && '(سقف)'}</p>
                              <p className={`font-bold ${discountInfo.isCapped ? 'text-amber-600' : 'text-emerald-600'}`}>
                                {discountInfo.discountAmount.toLocaleString('fa-IR')} تومان
                              </p>
                            </div>
                            <div className="text-center">
                              <p className="text-xs text-gray-500 mb-1">قابل پرداخت</p>
                              <p className="font-bold text-green-600">
                                {getTotalPriceWithDiscount().toLocaleString('fa-IR')} تومان
                              </p>
                            </div>
                          </div>
                        )}
                        
                        {discountInfo.nextTier && discountInfo.currentDiscount > 0 && (
                          <div className="mt-4 pt-4 border-t border-gray-200 text-center">
                            <p className="text-sm text-gray-600">
                              با افزودن{' '}
                              <span className="font-bold text-emerald-600">
                                {(discountInfo.nextTier.minPrice - discountInfo.total).toLocaleString('fa-IR')} تومان
                              </span>
                              {' '}دیگر، به تخفیف{' '}
                              <span className="font-bold text-emerald-600">{discountInfo.nextTier.discount}٪</span>
                              {' '}برسید!
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })()}

              {/* Product Columns */}
              <div className="mb-6">
                {/* Required Equipment */}
                <div className="mb-4">
                  <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                    <div className="w-6 h-6 bg-red-500 rounded-lg flex items-center justify-center">
                      <Star className="w-3.5 h-3.5 text-white fill-white" />
                    </div>
                    تجهیزات الزامی
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {sections.filter(s => s.required).map((section, index) => {
                      const filteredProducts = filterProducts(section.id);
                      const recommendation = getRecommendationForSection(section.id);
                  
                  return (
                    <motion.div
                      key={section.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden"
                    >
                      {/* Header */}
                      <div className={`bg-gradient-to-r ${section.color} p-3 text-white`}>
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                            <section.icon className="w-4 h-4" />
                          </div>
                          <h3 className="text-sm font-bold">{section.title}</h3>
                        </div>
                        
                        {/* Recommendation */}
                        {recommendation && (
                          <div className="bg-white/95 rounded-lg p-2.5 mb-2 shadow-sm">
                            <p className="text-xs text-gray-800 font-medium leading-relaxed">{recommendation.message}</p>
                          </div>
                        )}
                        
                        {/* Search */}
                        <div className="relative">
                          <Search className="absolute right-2.5 top-2 w-3.5 h-3.5 text-white/60" />
                          <input
                            type="text"
                            value={searchTerms[section.id] || ''}
                            onChange={(e) => setSearchTerms({ ...searchTerms, [section.id]: e.target.value })}
                            placeholder="جستجو..."
                            className="w-full bg-white/20 backdrop-blur-sm text-white placeholder-white/60 px-2 py-1.5 pr-8 rounded-lg text-xs focus:bg-white/30 transition-all"
                          />
                        </div>
                      </div>

                      {/* Products List */}
                      <div className="p-2 max-h-[500px] overflow-y-auto">
                        {filteredProducts.length > 0 ? (
                          <div className="space-y-2">
                            {filteredProducts.map(product => {
                              const recommended = isRecommended(section.id, product.id);
                              
                              return (
                                <div key={product.id} className="space-y-2">
                                  <div
                                    className={`rounded-lg border-2 p-2 transition-all ${
                                      recommended 
                                        ? 'border-[#F2B524] bg-amber-50/50' 
                                        : 'border-gray-200'
                                    }`}
                                  >
                                    <div className="flex items-start gap-2 mb-2">
                                      <ImageWithFallback
                                        src={product.image}
                                        alt={product.name}
                                        className="w-16 h-16 object-cover rounded-md"
                                      />
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-start gap-1">
                                          <h4 className="font-medium text-gray-900 text-xs line-clamp-1 flex-1">{product.name}</h4>
                                          {recommended && (
                                            <Star className="w-3.5 h-3.5 text-[#F2B524] fill-[#F2B524] flex-shrink-0" />
                                          )}
                                        </div>
                                        <p className="text-xs text-gray-600 line-clamp-1">{product.description}</p>
                                        <p className="text-xs text-gray-500">{product.specs}</p>
                                      </div>
                                    </div>
                                    
                                    {/* Sizes */}
                                    {product.sizes && product.sizes.length > 0 && (
                                      <div className="space-y-1">
                                        {product.sizes.map(size => (
                                          <motion.button
                                            key={size.size}
                                            whileHover={{ scale: 1.02 }}
                                            onClick={() => handleProductSelect(section.id, product, size.size)}
                                            className="w-full flex items-center justify-between bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-[#156394] rounded-md p-2 transition-all group"
                                          >
                                            <span className="text-xs font-medium text-gray-700">{size.size}</span>
                                            <div className="flex items-center gap-2">
                                              <span className="text-[#F2B524] font-bold text-xs">{size.price.toLocaleString('fa-IR')} ت</span>
                                              <ShoppingCart className="w-3 h-3 text-gray-400 group-hover:text-[#156394] transition-colors" />
                                            </div>
                                          </motion.button>
                                        ))}
                                      </div>
                                    )}
                                    
                                    {/* No sizes - direct add */}
                                    {(!product.sizes || product.sizes.length === 0) && (
                                      <motion.button
                                        whileHover={{ scale: 1.02 }}
                                        onClick={() => handleProductSelect(section.id, product)}
                                        className="w-full flex items-center justify-between bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-[#156394] rounded-md p-2 transition-all group"
                                      >
                                        <span className="text-xs font-medium text-gray-700">افزون</span>
                                        <div className="flex items-center gap-2">
                                          <span className="text-[#F2B524] font-bold text-xs">{product.price.toLocaleString('fa-IR')} ت</span>
                                          <ShoppingCart className="w-3 h-3 text-gray-400 group-hover:text-[#156394] transition-colors" />
                                        </div>
                                      </motion.button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-center text-gray-500 text-xs py-8">محصولی یافت نشد</p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
                  </div>
                </div>

                {/* Optional Equipment */}
                <div>
                  <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                    <div className="w-6 h-6 bg-gray-400 rounded-lg flex items-center justify-center">
                      <Settings2 className="w-3.5 h-3.5 text-white" />
                    </div>
                    تجهیزات اختیاری (پیشنهادی)
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {sections.filter(s => !s.required).map((section, index) => {
                      const filteredProducts = filterProducts(section.id);
                      const recommendation = getRecommendationForSection(section.id);
                  
                  return (
                    <motion.div
                      key={section.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden"
                    >
                      {/* Header */}
                      <div className={`bg-gradient-to-r ${section.color} p-3 text-white`}>
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-8 h-8 bg-white/20 backdrop-blur-sm rounded-lg flex items-center justify-center">
                            <section.icon className="w-4 h-4" />
                          </div>
                          <h3 className="text-sm font-bold">{section.title}</h3>
                        </div>
                        
                        {/* Recommendation */}
                        {recommendation && (
                          <div className="bg-white/95 rounded-lg p-2.5 mb-2 shadow-sm">
                            <p className="text-xs text-gray-800 font-medium leading-relaxed">{recommendation.message}</p>
                          </div>
                        )}
                        
                        {/* Search */}
                        <div className="relative">
                          <Search className="absolute right-2.5 top-2 w-3.5 h-3.5 text-white/60" />
                          <input
                            type="text"
                            value={searchTerms[section.id] || ''}
                            onChange={(e) => setSearchTerms({ ...searchTerms, [section.id]: e.target.value })}
                            placeholder="جستجو..."
                            className="w-full bg-white/20 backdrop-blur-sm text-white placeholder-white/60 px-2 py-1.5 pr-8 rounded-lg text-xs focus:bg-white/30 transition-all"
                          />
                        </div>
                      </div>

                      {/* Products List */}
                      <div className="p-2 max-h-[500px] overflow-y-auto">
                        {filteredProducts.length > 0 ? (
                          <div className="space-y-2">
                            {filteredProducts.map(product => {
                              const recommended = isRecommended(section.id, product.id);
                              
                              return (
                                <div key={product.id} className="space-y-2">
                                  <div
                                    className={`rounded-lg border-2 p-2 transition-all ${
                                      recommended 
                                        ? 'border-[#F2B524] bg-amber-50/50' 
                                        : 'border-gray-200'
                                    }`}
                                  >
                                    <div className="flex items-start gap-2 mb-2">
                                      <ImageWithFallback
                                        src={product.image}
                                        alt={product.name}
                                        className="w-16 h-16 object-cover rounded-md"
                                      />
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-start gap-1">
                                          <h4 className="font-medium text-gray-900 text-xs line-clamp-1 flex-1">{product.name}</h4>
                                          {recommended && (
                                            <Star className="w-3.5 h-3.5 text-[#F2B524] fill-[#F2B524] flex-shrink-0" />
                                          )}
                                        </div>
                                        <p className="text-xs text-gray-600 line-clamp-1">{product.description}</p>
                                        <p className="text-xs text-gray-500">{product.specs}</p>
                                      </div>
                                    </div>
                                    
                                    {/* Sizes */}
                                    {product.sizes && product.sizes.length > 0 && (
                                      <div className="space-y-1">
                                        {product.sizes.map(size => (
                                          <motion.button
                                            key={size.size}
                                            whileHover={{ scale: 1.02 }}
                                            onClick={() => handleProductSelect(section.id, product, size.size)}
                                            className="w-full flex items-center justify-between bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-[#156394] rounded-md p-2 transition-all group"
                                          >
                                            <span className="text-xs font-medium text-gray-700">{size.size}</span>
                                            <div className="flex items-center gap-2">
                                              <span className="text-[#F2B524] font-bold text-xs">{size.price.toLocaleString('fa-IR')} ت</span>
                                              <ShoppingCart className="w-3 h-3 text-gray-400 group-hover:text-[#156394] transition-colors" />
                                            </div>
                                          </motion.button>
                                        ))}
                                      </div>
                                    )}
                                    
                                    {/* No sizes - direct add */}
                                    {(!product.sizes || product.sizes.length === 0) && (
                                      <motion.button
                                        whileHover={{ scale: 1.02 }}
                                        onClick={() => handleProductSelect(section.id, product)}
                                        className="w-full flex items-center justify-between bg-gray-50 hover:bg-blue-50 border border-gray-200 hover:border-[#156394] rounded-md p-2 transition-all group"
                                      >
                                        <span className="text-xs font-medium text-gray-700">افزودن</span>
                                        <div className="flex items-center gap-2">
                                          <span className="text-[#F2B524] font-bold text-xs">{product.price.toLocaleString('fa-IR')} ت</span>
                                          <ShoppingCart className="w-3 h-3 text-gray-400 group-hover:text-[#156394] transition-colors" />
                                        </div>
                                      </motion.button>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <p className="text-center text-gray-500 text-xs py-8">محصولی یافت نشد</p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
                  </div>
                </div>
              </div>

              {/* Selected Products List */}
              {selectedProducts.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-2xl shadow-lg border border-gray-100 p-5 mb-5"
                >
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-[#156394]" />
                    محصولات انتخاب شده ({selectedProducts.length})
                  </h3>
                  
                  <div className="space-y-3">
                    {selectedProducts.map((product, index) => (
                      <motion.div
                        key={`${product.id}-${product.selectedSize}-${index}`}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="flex items-center gap-3 p-3 border border-gray-200 rounded-xl hover:border-gray-300 transition-all"
                      >
                        <ImageWithFallback
                          src={product.image}
                          alt={product.name}
                          className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                        />
                        
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 text-sm mb-0.5">{product.name}</h4>
                          {product.selectedSize && (
                            <p className="text-xs text-[#156394] font-medium mb-0.5">سایز: {product.selectedSize}</p>
                          )}
                          <p className="text-xs text-gray-600">{product.description}</p>
                          <p className="text-[#F2B524] font-bold text-sm mt-1">{product.price.toLocaleString('fa-IR')} تومان</p>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button
                            onClick={() => handleQuantityChange(index, product.quantity - 1)}
                            className="w-7 h-7 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm flex items-center justify-center transition-colors"
                          >
                            -
                          </button>
                          <span className="w-10 text-center text-sm font-medium">{product.quantity}</span>
                          <button
                            onClick={() => handleQuantityChange(index, product.quantity + 1)}
                            className="w-7 h-7 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm flex items-center justify-center transition-colors"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => handleRemoveProduct(index)}
                          className="w-8 h-8 bg-red-50 hover:bg-red-100 text-red-500 rounded-lg flex items-center justify-center transition-colors flex-shrink-0"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Total & Add to Cart */}
              <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-5">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <div>
                    {(() => {
                      const discountInfo = getDiscountInfo();
                      return (
                        <>
                          {discountInfo.currentDiscount > 0 ? (
                            <div className="space-y-2">
                              <div>
                                <p className="text-gray-400 text-xs mb-1 line-through">مبلغ قبل از تخفیف:</p>
                                <p className="text-lg text-gray-400 line-through">
                                  {getTotalPrice().toLocaleString('fa-IR')} تومان
                                </p>
                              </div>
                              <div className="flex items-center gap-2">
                                <div className="bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-bold">
                                  {discountInfo.currentDiscount}٪ تخفیف
                                </div>
                                <span className="text-emerald-600 font-bold">
                                  {((getTotalPrice() * discountInfo.currentDiscount) / 100).toLocaleString('fa-IR')} تومان
                                </span>
                              </div>
                              <div>
                                <p className="text-gray-600 text-xs mb-1">قابل پرداخت:</p>
                                <p className="text-3xl font-bold bg-gradient-to-r from-emerald-500 to-green-600 bg-clip-text text-transparent">
                                  {getTotalPriceWithDiscount().toLocaleString('fa-IR')} تومان
                                </p>
                              </div>
                            </div>
                          ) : (
                            <>
                              <p className="text-gray-600 text-xs mb-1">جمع کل:</p>
                              <p className="text-2xl font-bold bg-gradient-to-r from-[#156394] to-[#1a7bb3] bg-clip-text text-transparent">
                                {getTotalPrice().toLocaleString('fa-IR')} تومان
                              </p>
                            </>
                          )}
                        </>
                      );
                    })()}
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={addAllToCart}
                    disabled={selectedProducts.length === 0}
                    className="bg-gradient-to-r from-[#F2B524] to-[#f5c451] text-gray-900 px-5 py-2.5 rounded-lg text-sm font-bold flex items-center gap-2 hover:shadow-lg transition-shadow disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    افزودن به پیش‌فاکتور ({selectedProducts.length})
                  </motion.button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}