import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, Eye, CheckCircle, Truck, Package, Clock, X } from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};
const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

type OrderStatus = 'processing' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';

interface Order {
  id: string; customer: string; phone: string; date: string;
  status: OrderStatus; items: { name: string; qty: number; price: number }[];
  total: number; address: string; note?: string;
}

const ORDERS: Order[] = [
  { id: 'ORD-۱۴۰۳-۱۲۸', customer: 'مهندس احمدی', phone: '09123456789', date: '۱۴۰۳/۰۹/۱۸', status: 'processing', address: 'تهران، خیابان ولیعصر، پلاک ۱۲', items: [{ name: 'شیر توپی برنجی ۱/۲"', qty: 5, price: 165000 }, { name: 'لوله PE100 25mm', qty: 50, price: 95000 }], total: 5575000, note: 'ارسال سریع' },
  { id: 'ORD-۱۴۰۳-۱۲۷', customer: 'شرکت ساختمانی پارس', phone: '02144445555', date: '۱۴۰۳/۰۹/۱۷', status: 'confirmed', address: 'تهران، شهرک صنعتی، واحد ۵', items: [{ name: 'فلنج گلودار DN100', qty: 8, price: 420000 }, { name: 'لرزه‌گیر DN80', qty: 4, price: 480000 }], total: 5280000 },
  { id: 'ORD-۱۴۰۳-۱۲۶', customer: 'استخر فروشی رضایی', phone: '09351234567', date: '۱۴۰۳/۰۹/۱۵', status: 'shipped', address: 'تهران، اتوبان همت، کیانمهر، پلاک ۳۴', items: [{ name: 'پمپ سیرکولاتور ۱HP', qty: 2, price: 8500000 }, { name: 'فیلتر شنی ۵۰۰mm', qty: 1, price: 18500000 }], total: 35500000 },
  { id: 'ORD-۱۴۰۳-۱۲۵', customer: 'علی محمدی', phone: '09209876543', date: '۱۴۰۳/۰۹/۱۴', status: 'delivered', address: 'تهران، نارمک، خیابان ۱۷۴', items: [{ name: 'شیر کشویی فلنجی DN80', qty: 1, price: 850000 }], total: 850000 },
  { id: 'ORD-۱۴۰۳-۱۲۴', customer: 'پروژه دماوند', phone: '02188889999', date: '۱۴۰۳/۰۹/۱۲', status: 'delivered', address: 'تهران، دماوند، شهرک صنعتی', items: [{ name: 'لوله PE100 50mm', qty: 200, price: 185000 }, { name: 'زانو PVC 50mm', qty: 50, price: 75000 }, { name: 'سه‌راه ۵۰mm', qty: 30, price: 88000 }], total: 43150000 },
  { id: 'ORD-۱۴۰۳-۱۲۳', customer: 'حسن محمدپور', phone: '09181234321', date: '۱۴۰۳/۰۹/۱۰', status: 'cancelled', address: 'تهران، پونک', items: [{ name: 'عایق ۲۸×۱۳mm', qty: 10, price: 95000 }], total: 950000, note: 'لغو توسط مشتری' },
];

const statusCfg: Record<OrderStatus, { label: string; icon: React.ElementType; color: string; bg: string }> = {
  processing: { label: 'در حال پردازش', icon: Clock,        color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  confirmed:  { label: 'تایید شده',      icon: CheckCircle,  color: 'text-blue-600',   bg: 'bg-blue-50 border-blue-200' },
  shipped:    { label: 'ارسال شده',      icon: Truck,        color: 'text-purple-600', bg: 'bg-purple-50 border-purple-200' },
  delivered:  { label: 'تحویل داده شد', icon: Package,      color: 'text-green-600',  bg: 'bg-green-50 border-green-200' },
  cancelled:  { label: 'لغو شده',       icon: X,            color: 'text-red-500',    bg: 'bg-red-50 border-red-200' },
};

const nextStatus: Partial<Record<OrderStatus, OrderStatus>> = {
  processing: 'confirmed',
  confirmed: 'shipped',
  shipped: 'delivered',
};

export function DashboardOrders() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');
  const [orders, setOrders] = useState(ORDERS);
  const [detailOrder, setDetailOrder] = useState<Order | null>(null);

  const filtered = orders.filter(o => {
    const q = !search || o.customer.includes(search) || o.id.includes(search);
    const s = statusFilter === 'all' || o.status === statusFilter;
    return q && s;
  });

  const advance = (id: string) => {
    setOrders(prev => prev.map(o => {
      if (o.id === id && nextStatus[o.status]) return { ...o, status: nextStatus[o.status]! };
      return o;
    }));
  };

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-xl text-gray-900">مدیریت سفارش‌ها</h1>
        <p className="text-sm text-gray-500 mt-0.5">پیگیری و به‌روزرسانی وضعیت سفارشات</p>
      </div>

      {/* Status counters */}
      <div className="flex gap-3 flex-wrap">
        {(['all', ...Object.keys(statusCfg)] as const).map(k => {
          const count = k === 'all' ? orders.length : orders.filter(o => o.status === k).length;
          const cfg = k !== 'all' ? statusCfg[k as OrderStatus] : null;
          return (
            <button key={k} onClick={() => setStatusFilter(k as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs border transition-all
                ${statusFilter === k ? 'bg-[#156394] text-white border-[#156394] shadow-md' : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394] hover:text-[#156394]'}`}>
              {cfg && (() => { const Icon = cfg.icon; return <Icon size={12} />; })()}
              {k === 'all' ? 'همه' : cfg?.label}
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] ${statusFilter === k ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-600'}`}>
                {toPersianNumber(count)}
              </span>
            </button>
          );
        })}
      </div>

      <div className="relative max-w-xs">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="جستجوی سفارش یا مشتری..."
          className="w-full pr-9 pl-4 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
        <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
      </div>

      <div className="space-y-3">
        {filtered.map((o, i) => {
          const st = statusCfg[o.status];
          const Icon = st.icon;
          const canAdvance = !!nextStatus[o.status];
          return (
            <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${st.bg}`}>
                <Icon size={18} className={st.color} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-mono text-gray-400">{o.id}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${st.bg} ${st.color}`}>{st.label}</span>
                </div>
                <p className="text-sm text-gray-800">{o.customer}</p>
                <p className="text-xs text-gray-400 mt-0.5">{o.date} · {toPersianNumber(o.items.length)} کالا</p>
              </div>
              <div className="text-left shrink-0">
                <p className="text-sm text-[#156394]">{formatPrice(o.total)} ت</p>
                {o.note && <p className="text-[10px] text-gray-400 mt-0.5">{o.note}</p>}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => setDetailOrder(o)}
                  className="p-2 rounded-xl text-gray-400 hover:text-[#156394] hover:bg-blue-50 transition-colors">
                  <Eye size={15} />
                </button>
                {canAdvance && (
                  <button onClick={() => advance(o.id)}
                    className="px-3 py-1.5 bg-[#156394] text-white rounded-xl text-xs hover:bg-[#0d4a6f] transition-colors">
                    {nextStatus[o.status] === 'confirmed' ? 'تأیید' : nextStatus[o.status] === 'shipped' ? 'ارسال' : 'تحویل'}
                  </button>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Detail modal */}
      {detailOrder && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDetailOrder(null)}>
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-gray-800">{detailOrder.id}</h2>
              <button onClick={() => setDetailOrder(null)} className="text-gray-400 hover:text-gray-600 text-xl leading-none">×</button>
            </div>
            <div className="space-y-4">
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-xs text-gray-500 mb-2">اطلاعات مشتری</p>
                <p className="text-sm text-gray-800">{detailOrder.customer}</p>
                <p className="text-xs text-gray-500 mt-1">{detailOrder.phone}</p>
                <p className="text-xs text-gray-400 mt-1">{detailOrder.address}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-2">کالاها</p>
                <div className="space-y-2">
                  {detailOrder.items.map((item, i) => (
                    <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50">
                      <p className="text-xs text-gray-700">{item.name}</p>
                      <div className="text-left">
                        <p className="text-xs text-gray-500">{toPersianNumber(item.qty)} × {formatPrice(item.price)}</p>
                        <p className="text-xs text-[#156394]">{formatPrice(item.qty * item.price)} ت</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between pt-3">
                  <p className="text-sm text-gray-700">جمع کل</p>
                  <p className="text-[#156394]">{formatPrice(detailOrder.total)} تومان</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
