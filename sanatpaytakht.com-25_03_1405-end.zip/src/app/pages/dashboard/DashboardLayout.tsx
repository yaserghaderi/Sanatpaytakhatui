import { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router';
import { motion, AnimatePresence } from 'motion/react';
import {
  LayoutDashboard, Package, FileText, ShoppingCart,
  Users, BarChart3, Settings, LogOut, Menu, X,
  Bell, ChevronDown, Zap, Database, Brain
} from 'lucide-react';
import logo from '../../../assets/e2bf7b3e45975301863221e28611d21b5c7fdd37.png';

const toPersianNumber = (num: number | string) => {
  const d = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return num.toString().replace(/\d/g, (n) => d[parseInt(n)]);
};

const navItems = [
  { path: '/dashboard', label: 'داشبورد مدیریتی', icon: LayoutDashboard, exact: true },
  { path: '/dashboard/products', label: 'مدیریت محصولات', icon: Package },
  { path: '/dashboard/quotations', label: 'پیش‌فاکتورهای هوشمند', icon: Brain },
  { path: '/dashboard/orders', label: 'سفارش‌ها', icon: ShoppingCart },
  { path: '/dashboard/customers', label: 'مشتریان (CRM)', icon: Users },
  { path: '/dashboard/analytics', label: 'تحلیل و گزارش‌ها', icon: BarChart3 },
  { path: '/dashboard/sync', label: 'اتصال حسابداری', icon: Database },
];

export function DashboardLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [notifOpen, setNotifOpen] = useState(false);

  const isActive = (item: typeof navItems[0]) => {
    if (item.exact) return location.pathname === item.path;
    return location.pathname.startsWith(item.path);
  };

  return (
    <div className="flex min-h-screen bg-gray-50" dir="rtl">
      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 256, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed top-0 right-0 h-full bg-[#0f2744] z-30 flex flex-col overflow-hidden"
            style={{ minWidth: 256 }}
          >
            {/* Logo */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-white/10">
              <img src={logo} alt="جهان موج" className="h-9 w-auto brightness-200" />
              <div>
                <p className="text-white text-xs">پنل مدیریت</p>
                <p className="text-[#F2B524] text-[10px]">صنعت پایتخت جهان موج</p>
              </div>
            </div>

            {/* Sync status badge */}
            <div className="mx-4 mt-3 mb-1 flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-xl px-3 py-2">
              <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 text-xs">اتصال حسابداری: فعال</span>
              <Zap size={11} className="text-green-400 mr-auto" />
            </div>

            {/* Nav */}
            <nav className="flex-1 py-3 overflow-y-auto">
              {navItems.map(item => {
                const Icon = item.icon;
                const active = isActive(item);
                return (
                  <button key={item.path} onClick={() => navigate(item.path)}
                    className={`flex items-center gap-3 w-full px-5 py-3 text-right transition-all text-sm
                      ${active
                        ? 'bg-[#156394] text-white'
                        : 'text-white/70 hover:bg-white/5 hover:text-white'}`}>
                    <Icon size={16} className={active ? 'text-white' : 'text-white/50'} />
                    <span className="flex-1">{item.label}</span>
                    {active && <span className="w-1.5 h-1.5 rounded-full bg-[#F2B524]" />}
                  </button>
                );
              })}
            </nav>

            {/* User + settings */}
            <div className="border-t border-white/10 p-4 space-y-1">
              <button onClick={() => navigate('/dashboard/settings')}
                className="flex items-center gap-3 w-full px-3 py-2.5 text-white/60 hover:text-white hover:bg-white/5 rounded-xl transition-all text-sm">
                <Settings size={15} />
                <span>تنظیمات</span>
              </button>
              <button onClick={() => navigate('/')}
                className="flex items-center gap-3 w-full px-3 py-2.5 text-white/60 hover:text-red-400 hover:bg-red-500/5 rounded-xl transition-all text-sm">
                <LogOut size={15} />
                <span>خروج از پنل</span>
              </button>
              <div className="flex items-center gap-3 px-3 pt-2 border-t border-white/10 mt-1">
                <div className="w-8 h-8 bg-[#156394] rounded-full flex items-center justify-center shrink-0">
                  <span className="text-white text-xs">م</span>
                </div>
                <div>
                  <p className="text-white text-xs">مدیریت سایت</p>
                  <p className="text-white/40 text-[10px]">admin@sanatpaytakhat.com</p>
                </div>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main */}
      <div className={`flex-1 flex flex-col transition-all duration-200 ${sidebarOpen ? 'mr-64' : 'mr-0'}`}>
        {/* Top bar */}
        <header className="sticky top-0 z-20 bg-white border-b border-gray-100 flex items-center gap-4 px-6 py-3.5 shadow-sm">
          <button onClick={() => setSidebarOpen(v => !v)}
            className="w-9 h-9 flex items-center justify-center rounded-xl border border-gray-200 text-gray-500 hover:bg-gray-50 transition-colors">
            {sidebarOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
          <div className="flex-1" />

          {/* Notifs */}
          <div className="relative">
            <button onClick={() => setNotifOpen(v => !v)}
              className="relative w-9 h-9 flex items-center justify-center rounded-xl border border-gray-200 text-gray-500 hover:bg-gray-50 transition-colors">
              <Bell size={16} />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
            </button>
            <AnimatePresence>
              {notifOpen && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                  className="absolute left-0 top-full mt-2 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden z-50">
                  <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                    <span className="text-sm text-gray-700">اعلان‌ها</span>
                    <span className="text-xs text-[#156394]">{toPersianNumber(3)} جدید</span>
                  </div>
                  {[
                    { text: 'موجودی شیر توپی برنجی به پایان رسید', time: '۵ دقیقه پیش', type: 'warn' },
                    { text: 'پیش‌فاکتور جدید از مشتری احمدی', time: '۲۰ دقیقه پیش', type: 'info' },
                    { text: 'خطا در اتصال به حسابداری رفع شد', time: '۱ ساعت پیش', type: 'success' },
                  ].map((n, i) => (
                    <div key={i} className="px-4 py-3 border-b border-gray-50 hover:bg-gray-50 cursor-pointer">
                      <p className="text-xs text-gray-700 mb-1">{n.text}</p>
                      <p className="text-[10px] text-gray-400">{n.time}</p>
                    </div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button onClick={() => navigate('/')}
            className="text-xs text-[#156394] hover:underline flex items-center gap-1">
            بازگشت به سایت
            <ChevronDown size={11} className="rotate-90" />
          </button>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
