import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  RefreshCw, CheckCircle, XCircle, AlertCircle, Search,
  Edit2, Eye, EyeOff, Tag, ArrowUpDown, MoreVertical,
  Link, Zap, Clock, Package
} from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};

const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

type SyncStatus = 'synced' | 'pending' | 'error' | 'manual';

interface ManagedProduct {
  id: number;
  name: string;
  code: string;
  category: string;
  price: number;
  stock: number;
  syncStatus: SyncStatus;
  lastSync: string;
  active: boolean;
  hasSpecialPrice: boolean;
  accountingCode: string;
}

const PRODUCTS: ManagedProduct[] = [
  { id: 1, name: 'شیر توپی برنجی ۱/۲"', code: 'SHP-001', category: 'شیرآلات', price: 165000, stock: 3, syncStatus: 'synced', lastSync: '۱۵ دقیقه پیش', active: true, hasSpecialPrice: false, accountingCode: 'ACC-4421' },
  { id: 2, name: 'پمپ سیرکولاتور استخر ۱HP', code: 'PMP-012', category: 'استخر و جکوزی', price: 8500000, stock: 14, syncStatus: 'synced', lastSync: '۱۵ دقیقه پیش', active: true, hasSpecialPrice: true, accountingCode: 'ACC-8820' },
  { id: 3, name: 'لوله PE100 صنعتی ۵۰mm', code: 'LPE-031', category: 'اتصالات پلیمری', price: 185000, stock: 0, syncStatus: 'error', lastSync: '۳ ساعت پیش', active: false, hasSpecialPrice: false, accountingCode: 'ACC-2210' },
  { id: 4, name: 'فلنج گلودار PN16 DN100', code: 'FLJ-045', category: 'لرزه‌گیر و فلنج', price: 420000, stock: 28, syncStatus: 'pending', lastSync: '۴۵ دقیقه پیش', active: true, hasSpecialPrice: false, accountingCode: 'ACC-3340' },
  { id: 5, name: 'شیلنگ فشار قوی ۳/۴"', code: 'SHL-022', category: 'عایق و شیلنگ', price: 160000, stock: 65, syncStatus: 'synced', lastSync: '۱۵ دقیقه پیش', active: true, hasSpecialPrice: true, accountingCode: 'ACC-5512' },
  { id: 6, name: 'چسب PVC فوری ۵۰۰گرم', code: 'CHB-008', category: 'چسب و مواد شیمیایی', price: 1400000, stock: 42, syncStatus: 'synced', lastSync: '۱۵ دقیقه پیش', active: true, hasSpecialPrice: false, accountingCode: 'ACC-9901' },
  { id: 7, name: 'لرزه‌گیر لاستیکی DN80', code: 'LRZ-019', category: 'لرزه‌گیر و فلنج', price: 480000, stock: 0, syncStatus: 'manual', lastSync: '۲ روز پیش', active: false, hasSpecialPrice: false, accountingCode: '—' },
  { id: 8, name: 'فیلتر شنی استخر ۵۰۰mm', code: 'FSH-003', category: 'استخر و جکوزی', price: 18500000, stock: 6, syncStatus: 'synced', lastSync: '۱۵ دقیقه پیش', active: true, hasSpecialPrice: true, accountingCode: 'ACC-7701' },
];

const syncBadge: Record<SyncStatus, { label: string; icon: React.ElementType; cls: string }> = {
  synced:  { label: 'سینک شده',  icon: CheckCircle, cls: 'bg-green-50 text-green-600 border-green-200' },
  pending: { label: 'در انتظار',  icon: Clock,       cls: 'bg-yellow-50 text-yellow-700 border-yellow-200' },
  error:   { label: 'خطا',       icon: XCircle,     cls: 'bg-red-50 text-red-600 border-red-200' },
  manual:  { label: 'دستی',      icon: AlertCircle, cls: 'bg-gray-50 text-gray-500 border-gray-200' },
};

export function DashboardProducts() {
  const [search, setSearch] = useState('');
  const [products, setProducts] = useState(PRODUCTS);
  const [syncing, setSyncing] = useState(false);
  const [specialPriceModal, setSpecialPriceModal] = useState<ManagedProduct | null>(null);

  const filtered = products.filter(p =>
    p.name.includes(search) || p.code.includes(search) || p.category.includes(search)
  );

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => {
      setProducts(prev => prev.map(p => ({
        ...p,
        syncStatus: p.syncStatus === 'error' ? 'error' : 'synced',
        lastSync: '۱ دقیقه پیش'
      })));
      setSyncing(false);
    }, 2000);
  };

  const toggleActive = (id: number) =>
    setProducts(prev => prev.map(p => p.id === id ? { ...p, active: !p.active } : p));

  const syncCount = products.filter(p => p.syncStatus === 'synced').length;
  const errorCount = products.filter(p => p.syncStatus === 'error').length;
  const outOfStock = products.filter(p => p.stock === 0).length;

  return (
    <div className="p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl text-gray-900">مدیریت محصولات</h1>
          <p className="text-sm text-gray-500 mt-0.5">وضعیت سینک با نرم‌افزار حسابداری</p>
        </div>
        <button onClick={handleSync} disabled={syncing}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-all
            ${syncing ? 'bg-gray-100 text-gray-400 cursor-wait' : 'bg-[#156394] text-white hover:bg-[#0d4a6f] shadow-md'}`}>
          <RefreshCw size={15} className={syncing ? 'animate-spin' : ''} />
          {syncing ? 'در حال سینک...' : 'سینک با حسابداری'}
        </button>
      </div>

      {/* Status cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'سینک شده', value: syncCount, icon: CheckCircle, color: '#10b981' },
          { label: 'در انتظار سینک', value: products.filter(p => p.syncStatus === 'pending').length, icon: Clock, color: '#F2B524' },
          { label: 'خطا در سینک', value: errorCount, icon: XCircle, color: '#ef4444' },
          { label: 'ناموجود', value: outOfStock, icon: Package, color: '#8b5cf6' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: s.color + '18' }}>
                <Icon size={18} style={{ color: s.color }} />
              </div>
              <div>
                <p className="text-xs text-gray-500">{s.label}</p>
                <p className="text-xl text-gray-900">{toPersianNumber(s.value)}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sync info bar */}
      <div className="bg-[#f0f7ff] border border-[#156394]/20 rounded-2xl px-5 py-3 flex items-center gap-3">
        <Zap size={16} className="text-[#156394] shrink-0" />
        <p className="text-sm text-[#156394]">آخرین همگام‌سازی با حسابداری: ۱۵ دقیقه پیش</p>
        <span className="mr-auto text-xs text-gray-500">کد اتصال: <span className="font-mono">ACC-PROD-v2.1</span></span>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
          <div className="relative flex-1 max-w-xs">
            <input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="جستجوی محصول یا کد..."
              className="w-full pr-9 pl-4 py-2.5 bg-gray-50 rounded-xl text-sm border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
            <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <span className="text-xs text-gray-400">{toPersianNumber(filtered.length)} محصول</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50/70 border-b border-gray-100 text-xs text-gray-500">
                {['محصول', 'کد کالا', 'کد حسابداری', 'قیمت', 'موجودی', 'وضعیت سینک', 'آخرین سینک', 'عملیات'].map(h => (
                  <th key={h} className="px-4 py-3 text-right">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((p, i) => {
                const sync = syncBadge[p.syncStatus];
                const SyncIcon = sync.icon;
                return (
                  <motion.tr key={p.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.04 }}
                    className={`border-b border-gray-50 hover:bg-gray-50/50 transition-colors text-sm ${!p.active ? 'opacity-50' : ''}`}>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full shrink-0 ${p.stock === 0 ? 'bg-red-400' : p.stock < 5 ? 'bg-yellow-400' : 'bg-green-400'}`} />
                        <span className="text-gray-800 text-xs">{p.name}</span>
                        {p.hasSpecialPrice && (
                          <span className="bg-[#F2B524]/10 text-[#d49a0e] text-[10px] px-1.5 py-0.5 rounded-full border border-[#F2B524]/20">قیمت ویژه</span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-gray-500 font-mono">{p.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Link size={11} />
                        <span className="font-mono">{p.accountingCode}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-[#156394]">{formatPrice(p.price)} ت</td>
                    <td className="px-4 py-3.5 text-xs">
                      <span className={p.stock === 0 ? 'text-red-500' : p.stock < 5 ? 'text-yellow-600' : 'text-green-600'}>
                        {p.stock === 0 ? 'ناموجود' : toPersianNumber(p.stock) + ' عدد'}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] border ${sync.cls}`}>
                        <SyncIcon size={10} />
                        {sync.label}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-gray-400">{p.lastSync}</td>
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-1.5">
                        <button onClick={() => toggleActive(p.id)}
                          className={`p-1.5 rounded-lg transition-colors ${p.active ? 'text-green-500 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-100'}`}
                          title={p.active ? 'غیرفعال کردن' : 'فعال کردن'}>
                          {p.active ? <Eye size={13} /> : <EyeOff size={13} />}
                        </button>
                        <button onClick={() => setSpecialPriceModal(p)}
                          className="p-1.5 rounded-lg text-gray-400 hover:text-[#F2B524] hover:bg-yellow-50 transition-colors"
                          title="قیمت ویژه">
                          <Tag size={13} />
                        </button>
                        <button className="p-1.5 rounded-lg text-gray-400 hover:text-[#156394] hover:bg-blue-50 transition-colors">
                          <Edit2 size={13} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Special price modal */}
      <AnimatePresence>
        {specialPriceModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
            onClick={() => setSpecialPriceModal(null)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6"
              onClick={e => e.stopPropagation()}>
              <h3 className="text-gray-800 mb-1">تعریف قیمت ویژه</h3>
              <p className="text-sm text-gray-500 mb-5">{specialPriceModal.name}</p>
              <div className="space-y-4">
                <div>
                  <label className="block text-xs text-gray-600 mb-1.5">مشتری یا پروژه</label>
                  <input type="text" placeholder="نام مشتری یا کد پروژه..."
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
                </div>
                <div>
                  <label className="block text-xs text-gray-600 mb-1.5">قیمت ویژه (تومان)</label>
                  <input type="text" placeholder={formatPrice(specialPriceModal.price)}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
                </div>
                <div>
                  <label className="block text-xs text-gray-600 mb-1.5">تاریخ انقضا</label>
                  <input type="date"
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setSpecialPriceModal(null)}
                    className="flex-1 py-2.5 bg-[#156394] text-white rounded-xl text-sm hover:bg-[#0d4a6f] transition-colors">
                    ذخیره قیمت ویژه
                  </button>
                  <button onClick={() => setSpecialPriceModal(null)}
                    className="flex-1 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm hover:bg-gray-50 transition-colors">
                    انصراف
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
