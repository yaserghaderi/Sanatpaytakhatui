import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Brain, CheckCircle, XCircle, Edit2, Send, Eye,
  FileText, Image, AlertCircle, ChevronDown, Plus, Trash2, Download
} from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};

const formatPrice = (n: number) => toPersianNumber(n.toLocaleString('fa-IR'));

type QStatus = 'pending_review' | 'sent' | 'converted' | 'rejected';

interface QuotationItem { name: string; qty: number; unit: string; price: number; confidence: number; approved: boolean; }
interface Quotation {
  id: string; customer: string; phone: string; date: string;
  status: QStatus; imageUrl: string; extractedText: string;
  items: QuotationItem[]; total: number; note: string;
}

const QUOTATIONS: Quotation[] = [
  {
    id: 'QT-۱۴۰۳-۰۴۵', customer: 'مهندس احمدی', phone: '09123456789', date: '۱۴۰۳/۰۹/۱۸', status: 'pending_review',
    imageUrl: 'https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?w=400&q=80',
    extractedText: 'شیر توپی ۱/۲ - ۵ عدد\nلوله PE100 20mm - 100 متر\nزانو PVC - 10 عدد',
    items: [
      { name: 'شیر توپی برنجی ۱/۲"', qty: 5, unit: 'عدد', price: 165000, confidence: 94, approved: true },
      { name: 'لوله PE100 20mm', qty: 100, unit: 'متر', price: 95000, confidence: 87, approved: true },
      { name: 'زانو PVC 20mm', qty: 10, unit: 'عدد', price: 18000, confidence: 71, approved: false },
    ],
    total: 10405000, note: 'برای پروژه ساختمانی'
  },
  {
    id: 'QT-۱۴۰۳-۰۴۴', customer: 'استخر فروشی رضایی', phone: '09351234567', date: '۱۴۰۳/۰۹/۱۷', status: 'sent',
    imageUrl: 'https://images.unsplash.com/photo-1561222504-1c2e7d7952e4?w=400&q=80',
    extractedText: 'پمپ استخر ۱HP - ۲ دستگاه\nفیلتر شنی ۵۰۰ - ۱ عدد',
    items: [
      { name: 'پمپ سیرکولاتور استخر ۱HP', qty: 2, unit: 'دستگاه', price: 8500000, confidence: 96, approved: true },
      { name: 'فیلتر شنی ۵۰۰mm', qty: 1, unit: 'عدد', price: 18500000, confidence: 92, approved: true },
    ],
    total: 35500000, note: 'استخر هتل'
  },
  {
    id: 'QT-۱۴۰۳-۰۴۳', customer: 'شرکت پارس ساخت', phone: '02144445555', date: '۱۴۰۳/۰۹/۱۵', status: 'converted',
    imageUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=400&q=80',
    extractedText: 'فلنج DN100 - ۸ عدد\nلرزه گیر ۱۰۰ - ۴ عدد',
    items: [
      { name: 'فلنج گلودار PN16 DN100', qty: 8, unit: 'عدد', price: 420000, confidence: 89, approved: true },
      { name: 'لرزه‌گیر لاستیکی DN100', qty: 4, unit: 'عدد', price: 620000, confidence: 83, approved: true },
    ],
    total: 5840000, note: ''
  },
  {
    id: 'QT-۱۴۰۳-۰۴۲', customer: 'محمد علی‌زاده', phone: '09209876543', date: '۱۴۰۳/۰۹/۱۴', status: 'rejected',
    imageUrl: 'https://images.unsplash.com/photo-1630077318421-5ceace7f0676?w=400&q=80',
    extractedText: 'چسب PVC ۵۰۰گرم - ۳ عدد',
    items: [
      { name: 'چسب PVC فوری ۵۰۰گرم', qty: 3, unit: 'عدد', price: 1400000, confidence: 98, approved: true },
    ],
    total: 4200000, note: 'مشتری کنسل کرد'
  },
];

const statusCfg: Record<QStatus, { label: string; color: string; bg: string }> = {
  pending_review: { label: 'نیاز به بررسی', color: 'text-yellow-700', bg: 'bg-yellow-50 border-yellow-200' },
  sent:           { label: 'ارسال شده',     color: 'text-blue-600',   bg: 'bg-blue-50 border-blue-200' },
  converted:      { label: 'تبدیل به سفارش', color: 'text-green-600', bg: 'bg-green-50 border-green-200' },
  rejected:       { label: 'رد شده',        color: 'text-red-500',    bg: 'bg-red-50 border-red-200' },
};

export function DashboardQuotations() {
  const [selected, setSelected] = useState<Quotation | null>(null);
  const [items, setItems] = useState<QuotationItem[]>([]);
  const [filter, setFilter] = useState<QStatus | 'all'>('all');

  const openQuotation = (q: Quotation) => {
    setSelected(q);
    setItems([...q.items]);
  };

  const filtered = QUOTATIONS.filter(q => filter === 'all' || q.status === filter);

  const toggleApprove = (idx: number) =>
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, approved: !it.approved } : it));

  const updateQty = (idx: number, qty: number) =>
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, qty } : it));

  const deleteItem = (idx: number) =>
    setItems(prev => prev.filter((_, i) => i !== idx));

  const approvedTotal = items.filter(i => i.approved).reduce((s, i) => s + i.qty * i.price, 0);

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-xl text-gray-900">پیش‌فاکتورهای هوشمند</h1>
        <p className="text-sm text-gray-500 mt-0.5">مدیریت درخواست‌های پیش‌فاکتور از تصویر</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'نیاز به بررسی', count: QUOTATIONS.filter(q => q.status === 'pending_review').length, color: '#F2B524' },
          { label: 'ارسال شده', count: QUOTATIONS.filter(q => q.status === 'sent').length, color: '#156394' },
          { label: 'تبدیل به سفارش', count: QUOTATIONS.filter(q => q.status === 'converted').length, color: '#10b981' },
          { label: 'رد شده', count: QUOTATIONS.filter(q => q.status === 'rejected').length, color: '#ef4444' },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-3">
            <span className="w-2 h-10 rounded-full shrink-0" style={{ background: s.color }} />
            <div>
              <p className="text-2xl text-gray-900">{toPersianNumber(s.count)}</p>
              <p className="text-xs text-gray-500">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {[['all', 'همه'], ['pending_review', 'نیاز به بررسی'], ['sent', 'ارسال شده'], ['converted', 'تبدیل به سفارش']].map(([k, l]) => (
          <button key={k} onClick={() => setFilter(k as any)}
            className={`px-4 py-2 rounded-full text-xs transition-all border
              ${filter === k ? 'bg-[#156394] text-white border-[#156394] shadow-md' : 'bg-white text-gray-600 border-gray-200 hover:border-[#156394] hover:text-[#156394]'}`}>
            {l}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {filtered.map(q => {
          const st = statusCfg[q.status];
          return (
            <div key={q.id} className="bg-white rounded-2xl border border-gray-100 p-4 flex items-center gap-4 hover:shadow-md transition-shadow">
              {/* Image thumb */}
              <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-gray-100">
                <img src={q.imageUrl} alt="" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm text-gray-800">{q.customer}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${st.bg} ${st.color}`}>{st.label}</span>
                </div>
                <p className="text-xs text-gray-500 mb-1">{q.phone} · {q.date}</p>
                <p className="text-xs text-gray-400 line-clamp-1">{q.extractedText}</p>
              </div>
              <div className="text-left shrink-0">
                <p className="text-sm text-[#156394]">{formatPrice(q.total)} ت</p>
                <p className="text-xs text-gray-400 mt-0.5">{toPersianNumber(q.items.length)} کالا</p>
              </div>
              <button onClick={() => openQuotation(q)}
                className="flex items-center gap-1.5 px-4 py-2 bg-[#156394] text-white rounded-xl text-xs hover:bg-[#0d4a6f] transition-colors shrink-0">
                <Eye size={13} /> بررسی
              </button>
            </div>
          );
        })}
      </div>

      {/* Detail modal */}
      <AnimatePresence>
        {selected && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 overflow-y-auto"
            onClick={() => setSelected(null)}>
            <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl shadow-2xl w-full max-w-3xl my-4"
              onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-[#0f2744] to-[#156394] rounded-t-3xl">
                <div className="flex items-center gap-2">
                  <Brain size={18} className="text-white" />
                  <h2 className="text-white">{selected.id}</h2>
                </div>
                <button onClick={() => setSelected(null)} className="text-white/60 hover:text-white text-xl leading-none">×</button>
              </div>

              <div className="p-6 space-y-5">
                {/* Customer + image */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-2xl p-4">
                    <p className="text-xs text-gray-500 mb-3">اطلاعات مشتری</p>
                    <p className="text-sm text-gray-800 mb-1">{selected.customer}</p>
                    <p className="text-xs text-gray-500">{selected.phone}</p>
                    <p className="text-xs text-gray-400 mt-1">{selected.date}</p>
                  </div>
                  <div className="bg-gray-50 rounded-2xl p-3">
                    <p className="text-xs text-gray-500 mb-2">تصویر ارسالی مشتری</p>
                    <img src={selected.imageUrl} alt="" className="w-full h-24 object-cover rounded-xl" />
                  </div>
                </div>

                {/* Extracted text */}
                <div className="bg-[#f8fafc] border border-gray-100 rounded-2xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Brain size={14} className="text-[#156394]" />
                    <span className="text-xs text-gray-600">متن استخراج‌شده توسط هوش مصنوعی</span>
                  </div>
                  <pre className="text-xs text-gray-500 whitespace-pre-wrap font-sans leading-relaxed">{selected.extractedText}</pre>
                </div>

                {/* Items */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-sm text-gray-700">کالاهای شناسایی‌شده</p>
                    <button className="flex items-center gap-1 text-xs text-[#156394] hover:underline">
                      <Plus size={12} /> افزودن کالا
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {items.map((item, idx) => (
                      <div key={idx} className={`flex items-center gap-3 p-3 rounded-xl border transition-all
                        ${item.approved ? 'border-green-200 bg-green-50/40' : 'border-gray-200 bg-gray-50 opacity-60'}`}>
                        <button onClick={() => toggleApprove(idx)}
                          className={`shrink-0 ${item.approved ? 'text-green-500' : 'text-gray-300'}`}>
                          <CheckCircle size={18} />
                        </button>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs text-gray-800">{item.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${item.confidence >= 90 ? 'bg-green-100 text-green-600' : item.confidence >= 75 ? 'bg-yellow-100 text-yellow-600' : 'bg-red-100 text-red-500'}`}>
                              اطمینان: {toPersianNumber(item.confidence)}٪
                            </span>
                            {item.confidence < 80 && <AlertCircle size={11} className="text-yellow-500" />}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <input type="number" value={item.qty} onChange={e => updateQty(idx, +e.target.value)}
                            className="w-14 text-center py-1 border border-gray-200 rounded-lg text-xs focus:outline-none bg-white" />
                          <span className="text-xs text-gray-400">{item.unit}</span>
                        </div>
                        <p className="text-xs text-[#156394] shrink-0">{formatPrice(item.price * item.qty)} ت</p>
                        <button onClick={() => deleteItem(idx)} className="text-gray-300 hover:text-red-400 transition-colors shrink-0">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Total + actions */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div>
                    <p className="text-xs text-gray-500">جمع کل تأیید‌شده</p>
                    <p className="text-xl text-[#156394]">{formatPrice(approvedTotal)} تومان</p>
                  </div>
                  <div className="flex gap-2">
                    <button className="flex items-center gap-1.5 px-4 py-2.5 border border-gray-200 rounded-xl text-xs text-gray-600 hover:bg-gray-50 transition-colors">
                      <Download size={13} /> دانلود PDF
                    </button>
                    <button className="flex items-center gap-1.5 px-4 py-2.5 bg-[#F2B524] text-gray-900 rounded-xl text-xs hover:bg-[#d9a31e] transition-colors font-bold">
                      <FileText size={13} /> تبدیل به سفارش
                    </button>
                    <button className="flex items-center gap-1.5 px-4 py-2.5 bg-[#156394] text-white rounded-xl text-xs hover:bg-[#0d4a6f] transition-colors">
                      <Send size={13} /> ارسال به مشتری
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
