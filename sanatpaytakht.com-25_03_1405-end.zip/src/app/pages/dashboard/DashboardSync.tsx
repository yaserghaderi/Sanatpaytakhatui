import { useState } from 'react';
import { Database, CheckCircle, XCircle, RefreshCw, Zap, Settings, Clock } from 'lucide-react';

const toPersianNumber = (n: number | string) => {
  const d = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
  return n.toString().replace(/\d/g, c => d[+c]);
};

const syncLog = [
  { time: '۱۵ دقیقه پیش', event: 'همگام‌سازی موفق — ۱۲ محصول به‌روز شد', status: 'success' },
  { time: '۱ ساعت پیش', event: 'همگام‌سازی موفق — قیمت ۳ محصول تغییر کرد', status: 'success' },
  { time: '۳ ساعت پیش', event: 'خطا در اتصال: timeout — تلاش مجدد موفق بود', status: 'warn' },
  { time: '۵ ساعت پیش', event: 'همگام‌سازی موفق — موجودی ۸ محصول به‌روز شد', status: 'success' },
  { time: 'دیروز ۱۴:۳۰', event: 'خطا: کد کالا ACC-2210 یافت نشد', status: 'error' },
];

export function DashboardSync() {
  const [syncing, setSyncing] = useState(false);
  const [syncInterval, setSyncInterval] = useState('15');

  const handleSync = () => {
    setSyncing(true);
    setTimeout(() => setSyncing(false), 2500);
  };

  return (
    <div className="p-6 space-y-5">
      <div>
        <h1 className="text-xl text-gray-900">اتصال به نرم‌افزار حسابداری</h1>
        <p className="text-sm text-gray-500 mt-0.5">مدیریت سینک محصولات، قیمت‌ها و موجودی</p>
      </div>

      {/* Status */}
      <div className="bg-green-50 border border-green-200 rounded-2xl p-5 flex items-center gap-4">
        <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center shrink-0">
          <CheckCircle size={22} className="text-green-500" />
        </div>
        <div className="flex-1">
          <p className="text-green-700">اتصال فعال</p>
          <p className="text-sm text-green-600">سرور حسابداری: accounting.company.local:8080</p>
          <p className="text-xs text-green-500 mt-0.5">آخرین سینک: ۱۵ دقیقه پیش · بعدی: ۱۵ دقیقه دیگر</p>
        </div>
        <button onClick={handleSync} disabled={syncing}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-all shrink-0
            ${syncing ? 'bg-gray-100 text-gray-400' : 'bg-green-500 text-white hover:bg-green-600'}`}>
          <RefreshCw size={15} className={syncing ? 'animate-spin' : ''} />
          {syncing ? 'در حال سینک...' : 'سینک فوری'}
        </button>
      </div>

      {/* Config */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6">
        <div className="flex items-center gap-2 mb-5">
          <Settings size={16} className="text-[#156394]" />
          <h2 className="text-sm text-gray-700">تنظیمات اتصال</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[
            { label: 'آدرس سرور حسابداری', value: 'accounting.company.local:8080', type: 'text' },
            { label: 'نام کاربری', value: 'api_user', type: 'text' },
            { label: 'رمز عبور', value: '••••••••', type: 'password' },
            { label: 'کد شرکت', value: 'COMP-001', type: 'text' },
          ].map((f, i) => (
            <div key={i}>
              <label className="block text-xs text-gray-500 mb-1.5">{f.label}</label>
              <input type={f.type} defaultValue={f.value}
                className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#156394]/20" />
            </div>
          ))}
          <div>
            <label className="block text-xs text-gray-500 mb-1.5">فاصله سینک خودکار (دقیقه)</label>
            <select value={syncInterval} onChange={e => setSyncInterval(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none">
              {['5', '10', '15', '30', '60'].map(v => (
                <option key={v} value={v}>{toPersianNumber(v)} دقیقه</option>
              ))}
            </select>
          </div>
        </div>
        <div className="flex gap-3 mt-5">
          <button className="px-6 py-2.5 bg-[#156394] text-white rounded-xl text-sm hover:bg-[#0d4a6f] transition-colors">
            ذخیره تنظیمات
          </button>
          <button className="px-6 py-2.5 border border-gray-200 text-gray-600 rounded-xl text-sm hover:bg-gray-50 transition-colors">
            تست اتصال
          </button>
        </div>
      </div>

      {/* Sync log */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-4 border-b border-gray-100">
          <Clock size={15} className="text-gray-400" />
          <h2 className="text-sm text-gray-700">لاگ همگام‌سازی</h2>
        </div>
        <div className="divide-y divide-gray-50">
          {syncLog.map((log, i) => (
            <div key={i} className="flex items-center gap-3 px-5 py-3">
              {log.status === 'success' ? <CheckCircle size={14} className="text-green-500 shrink-0" />
                : log.status === 'error' ? <XCircle size={14} className="text-red-400 shrink-0" />
                : <Zap size={14} className="text-yellow-500 shrink-0" />}
              <p className="text-xs text-gray-700 flex-1">{log.event}</p>
              <span className="text-[10px] text-gray-400">{log.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
